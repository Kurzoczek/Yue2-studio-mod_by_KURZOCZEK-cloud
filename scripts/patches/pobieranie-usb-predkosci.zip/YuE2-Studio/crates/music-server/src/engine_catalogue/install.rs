pub(crate) mod inventory;
pub(crate) mod rollback;
pub(crate) mod updates;

use std::io::Write;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result, ensure};
use axum::{
    Json,
    extract::{Path as RoutePath, State},
    http::StatusCode,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use tokio::io::AsyncWriteExt;

use super::{Catalogue, EnginePackage, Failure, ModelPackage, PackageFile, parse, portable_name};
use crate::{AppState, api_error, component_catalogue as channel, net, update_data_root};

trait Package: Serialize + Sized {
    const FOLDER: &'static str;
    fn select(catalog: Catalogue, id: &str) -> Result<Self>;
    fn id(&self) -> &str;
    fn files(&self) -> &[PackageFile];
    fn executable(&self) -> Option<&str> {
        None
    }
}

impl Package for EnginePackage {
    const FOLDER: &'static str = "music-engines";
    fn select(catalog: Catalogue, id: &str) -> Result<Self> {
        let platform = host_platform();
        catalog
            .engines
            .into_iter()
            .find(|p| p.id == id && p.platform == platform)
            .context("engine is absent for this platform")
    }
    fn id(&self) -> &str {
        &self.id
    }
    fn files(&self) -> &[PackageFile] {
        &self.files
    }
    fn executable(&self) -> Option<&str> {
        Some(&self.executable)
    }
}

impl Package for ModelPackage {
    const FOLDER: &'static str = "music-models";
    fn select(catalog: Catalogue, id: &str) -> Result<Self> {
        catalog
            .models
            .into_iter()
            .find(|model| model.id == id)
            .context("model is absent from the signed catalogue")
    }
    fn id(&self) -> &str {
        &self.id
    }
    fn files(&self) -> &[PackageFile] {
        &self.files
    }
}

#[derive(Default, Deserialize, Serialize)]
pub(crate) struct Selection {
    active: String,
    previous: Option<String>,
    #[serde(default)]
    automatic_updates_paused: bool,
}

pub(super) fn host_platform() -> String {
    format!("{}-{}", std::env::consts::OS, std::env::consts::ARCH)
}

fn read_selection(root: &Path) -> Result<Selection> {
    match std::fs::read(root.join("active.json")) {
        Ok(bytes) => {
            let selection: Selection = serde_json::from_slice(&bytes)?;
            for id in std::iter::once(&selection.active).chain(selection.previous.iter()) {
                ensure!(
                    id.starts_with("generation-") && portable_name(id),
                    "invalid installed generation"
                );
            }
            Ok(selection)
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Selection::default()),
        Err(error) => Err(error.into()),
    }
}

async fn verified(path: PathBuf, file: &PackageFile) -> Result<bool> {
    let expected = file.sha256.clone();
    let size = file.bytes;
    tokio::task::spawn_blocking(move || {
        if !std::fs::symlink_metadata(&path).is_ok_and(|m| m.is_file() && m.len() == size) {
            return Ok(false);
        }
        Ok(crate::install_record::sha256_of(&path)? == expected)
    })
    .await?
}

async fn only_signed_files(directory: &Path, package: &impl Package) -> Result<bool> {
    if !tokio::fs::symlink_metadata(directory).await?.is_dir() {
        return Ok(false);
    }
    let mut expected = std::collections::HashMap::new();
    for file in package.files() {
        let path = file.relative_path();
        if let Some(variant) = file.cuda_variant {
            expected.insert(PathBuf::from(variant.folder()), true);
        }
        expected.insert(path, false);
    }
    let mut dirs = vec![PathBuf::new()];
    while let Some(relative) = dirs.pop() {
        let mut entries = tokio::fs::read_dir(directory.join(&relative)).await?;
        while let Some(entry) = entries.next_entry().await? {
            let path = relative.join(entry.file_name());
            let kind = entry.file_type().await?;
            match expected.remove(&path) {
                Some(true) if kind.is_dir() => {
                    #[cfg(windows)]
                    {
                        use std::os::windows::fs::MetadataExt;
                        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x400;
                        if entry.metadata().await?.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
                            return Ok(false);
                        }
                    }
                    dirs.push(path);
                }
                Some(false) if kind.is_file() => {}
                _ => return Ok(false),
            }
        }
    }
    Ok(expected.is_empty())
}
async fn download(
    file: &PackageFile,
    path: &Path,
    client: &reqwest::Client,
    transfer: &super::progress::Transfer,
) -> Result<()> {
    transfer.stage("downloading", Some(&file.name));
    let primary = net::model_url(&file.url);
    let initial_bytes = transfer.downloaded_bytes();
    let mut source = primary.clone();
    let mut mirrors = None;
    loop {
        let scratch = tempfile::tempdir_in(path.parent().context("missing package directory")?)?;
        let staged = scratch.path().join("part");
        let mut result = download_from(file, &source, &staged, client, transfer, initial_bytes).await;
        // A dropped line (a slow USB disk keeps it idle while the system writes out, and the server gives up) goes on
        // from the byte it came to, a few times, before another mirror starts the file over.
        let mut again = 0u32;
        while again < RESUMES && result.as_ref().is_err_and(|error| error.downcast_ref::<reqwest::Error>().is_some()) {
            again += 1;
            tokio::time::sleep(std::time::Duration::from_secs(2u64 << again.min(5))).await;
            result = download_from(file, &source, &staged, client, transfer, initial_bytes).await;
        }
        match result {
            Ok(()) => {
                tokio::fs::rename(&staged, path).await?;
                return Ok(());
            }
            Err(error) => {
                // Local write errors, including a full disk, affect every mirror.
                if error.downcast_ref::<reqwest::Error>().is_none()
                    && error.downcast_ref::<std::io::Error>().is_some()
                {
                    return Err(error);
                }
                drop(scratch);
                transfer.set_downloaded_bytes(initial_bytes);
                if mirrors.is_none() {
                    let mut urls = crate::downloads::mirror_sources(client, &file.sha256).await;
                    urls.retain(|url| url != &primary);
                    mirrors = Some(urls.into_iter());
                }
                match mirrors.as_mut().and_then(Iterator::next) {
                    Some(next) => source = next,
                    None => {
                        return Err(error)
                            .with_context(|| format!("no verified download for {}", file.name));
                    }
                }
            }
        }
    }
}

/// Tries on one source after a dropped line, each going on from where the file came to.
const RESUMES: u32 = 6;

/// Written out to the disk this often: a slow disk (USB) otherwise gathers gigabytes in memory and then holds every
/// write for minutes while it catches up - long enough for the server to drop the idle line.
const FLUSH_EVERY: u64 = 32 * 1024 * 1024;

async fn download_from(
    file: &PackageFile,
    source: &str,
    path: &Path,
    client: &reqwest::Client,
    transfer: &super::progress::Transfer,
    base: u64,
) -> Result<()> {
    // what an earlier try left is kept, hashed again, and only the rest asked for
    let have = tokio::fs::metadata(path).await.map(|meta| meta.len()).unwrap_or(0).min(file.bytes);
    let mut request = client.get(source);
    if have > 0 {
        request = request.header(reqwest::header::RANGE, format!("bytes={have}-"));
    }
    let mut response = request.send().await?.error_for_status()?;
    let resumed = have > 0 && response.status() == reqwest::StatusCode::PARTIAL_CONTENT;
    let mut hash = Sha256::new();
    let mut bytes = 0u64;
    let mut writer = if resumed {
        let mut existing = tokio::fs::File::open(path).await?;
        let mut buffer = vec![0u8; 1 << 20];
        loop {
            let count = tokio::io::AsyncReadExt::read(&mut existing, &mut buffer).await?;
            if count == 0 || bytes >= have {
                break;
            }
            let count = count.min((have - bytes) as usize);
            hash.update(&buffer[..count]);
            bytes += count as u64;
        }
        ensure!(bytes == have, "the part already downloaded could not be read again");
        let writer = tokio::fs::OpenOptions::new().write(true).open(path).await?;
        writer.set_len(have).await?;
        let mut writer = writer;
        tokio::io::AsyncSeekExt::seek(&mut writer, std::io::SeekFrom::Start(have)).await?;
        writer
    } else {
        // from the start: a server that does not serve ranges, or nothing there yet
        tokio::fs::File::create(path).await?
    };
    transfer.set_downloaded_bytes(base + bytes);
    let mut unflushed = 0u64;
    while let Some(chunk) = response.chunk().await? {
        ensure!(
            chunk.len() as u64 <= file.bytes - bytes,
            "component exceeds its signed size"
        );
        bytes += chunk.len() as u64;
        hash.update(&chunk);
        writer.write_all(&chunk).await?;
        crate::activity::received(chunk.len() as u64);
        transfer.downloaded(chunk.len() as u64);
        unflushed += chunk.len() as u64;
        if unflushed >= FLUSH_EVERY {
            writer.sync_data().await?;
            unflushed = 0;
        }
    }
    ensure!(
        bytes == file.bytes
            && hash
                .finalize()
                .iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>()
                == file.sha256,
        "component integrity check failed for {}",
        file.name
    );
    writer.sync_all().await?;
    Ok(())
}

/// Models from different publishers can refer to the same pinned weight. An
/// object becomes reusable only after verification; concurrent installs share
/// the per-digest lock even when their model ids differ.
async fn materialize_model_file(
    store: &Path,
    file: &PackageFile,
    to: &Path,
    client: &reqwest::Client,
    transfer: &super::progress::Transfer,
) -> Result<bool> {
    tokio::fs::create_dir_all(store).await?;
    let object = store.join(&file.sha256);
    let lock_path = store.join(format!("{}.lock", file.sha256));
    let _lock = tokio::task::spawn_blocking(move || -> Result<std::fs::File> {
        let lock = std::fs::File::options()
            .create(true)
            .truncate(false)
            .write(true)
            .open(lock_path)?;
        fs2::FileExt::lock_exclusive(&lock)?;
        Ok(lock)
    })
    .await??;
    let reused = verified(object.clone(), file).await?;
    if !reused {
        let staged = tempfile::tempdir_in(store)?;
        let fresh = staged.path().join("weight");
        download(file, &fresh, client, transfer).await?;
        tempfile::TempPath::try_from_path(fresh)?.persist(&object)?;
    }
    if tokio::fs::hard_link(&object, to).await.is_err() {
        tokio::fs::copy(&object, to).await?;
    }
    Ok(reused)
}

async fn install<P: Package>(
    state: &AppState,
    package: &P,
    automatic: bool,
) -> Result<serde_json::Value> {
    let total = package
        .files()
        .iter()
        .try_fold(0u64, |sum, f| sum.checked_add(f.bytes))
        .context("package size overflow")?;
    let (job, mut cancelled) =
        super::progress::Installation::begin(P::FOLDER, package.id(), total)?;
    if cfg!(windows)
        && package.files().iter().any(|file| file.cuda_variant.is_some())
        && let Some(cuda) = crate::native_music_runtime::cuda_build()
    {
        let downloader = state.engine_runtime.downloader();
        let missing: Vec<_> = crate::engine_runtime::cuda_assets(cuda)
            .into_iter()
            .filter(|asset| !downloader.is_installed(asset))
            .collect();
        if !missing.is_empty() {
            job.transfer.stage("downloading", Some("CUDA runtime"));
            let scope = format!("signed-native-{}", package.id());
            let dependency_signal = cancelled.clone();
            let dependency_cancelled = || *dependency_signal.borrow();
            let dependencies = downloader.install_all_with_cancel(
                &scope, &missing, Some(&dependency_cancelled)
            );
            tokio::pin!(dependencies);
            tokio::select! {
                biased;
                _ = cancelled.changed() => {
                    downloader.cancel_for(&scope).await;
                    let _ = dependencies.await;
                    anyhow::bail!("Package installation cancelled");
                }
                result = &mut dependencies => result.context("Install shared CUDA runtime")?,
            }
        }
    }
    tokio::select! {
        biased;
        _ = cancelled.changed() => anyhow::bail!("Package installation cancelled"),
        result = stage_package(state, package, &job.transfer, automatic) => result,
    }
}

async fn stage_package<P: Package>(
    state: &AppState,
    package: &P,
    transfer: &super::progress::Transfer,
    automatic: bool,
) -> Result<serde_json::Value> {
    // wherever the person keeps these download folders (Debian build); the shared weights go with the models, so the
    // models' files stay hard links to them on one disk
    let root = crate::model_storage::folder(update_data_root(state), P::FOLDER);
    let objects = crate::model_storage::folder(update_data_root(state), crate::model_storage::MODEL_OBJECTS);
    let root = root.join(package.id());
    tokio::fs::create_dir_all(&root).await?;
    let lock = std::fs::File::options()
        .write(true)
        .create(true)
        .truncate(false)
        .open(root.join("install.lock"))?;
    fs2::FileExt::try_lock_exclusive(&lock)
        .context("an installation is already running for this engine")?;
    let selected = read_selection(&root)?;
    if automatic {
        ensure!(
            !selected.active.is_empty() && !selected.automatic_updates_paused,
            "automatic updates paused for this package"
        );
    }
    let prior = root.join(&selected.active);
    let manifest = serde_json::to_vec(package)?;
    let same_manifest = !selected.active.is_empty()
        && tokio::fs::read(prior.join("manifest.json"))
            .await
            .ok()
            .as_deref()
            == Some(&manifest);
    let stage = tempfile::Builder::new()
        .prefix("generation-")
        .tempdir_in(&root)?;
    let proof = channel::save_engine_proof(&stage.path().join("proof")).await?;
    let trusted = P::select(parse(&proof)?, package.id())?;
    ensure!(
        serde_json::to_vec(&trusted)? == manifest,
        "catalogue changed before installation"
    );
    let directory = stage.path().join("files");
    tokio::fs::create_dir(&directory).await?;
    for variant in package.files().iter().filter_map(|file| file.cuda_variant) {
        tokio::fs::create_dir(directory.join(variant.folder())).await?;
    }
    let client = net::download_client();
    let mut downloaded = 0u64;
    let mut reused = 0u64;
    for file in package.files() {
        transfer.stage("verifying", Some(&file.name));
        let path = file.relative_path();
        let to = directory.join(&path);
        let from = prior.join("files").join(path);
        if !selected.active.is_empty() && verified(from.clone(), file).await? {
            if Some(file.name.as_str()) == package.executable()
                || tokio::fs::hard_link(&from, &to).await.is_err()
            {
                tokio::fs::copy(&from, &to).await?;
            }
            transfer.reused(file.bytes);
            reused = reused
                .checked_add(file.bytes)
                .context("package size overflow")?;
        } else {
            if P::FOLDER == ModelPackage::FOLDER {
                if materialize_model_file(&objects, file, &to, &client, transfer).await? {
                    transfer.reused(file.bytes);
                    reused = reused
                        .checked_add(file.bytes)
                        .context("package size overflow")?;
                    continue;
                }
            } else {
                download(file, &to, &client, transfer).await?;
            }
            downloaded = downloaded
                .checked_add(file.bytes)
                .context("package size overflow")?;
        }
    }
    if same_manifest
        && downloaded == 0
        && only_signed_files(&prior.join("files"), package)
            .await
            .unwrap_or(false)
        && channel::verify_engine_proof(&prior.join("proof"))
            .await
            .is_ok_and(|proof| {
                parse(&proof)
                    .and_then(|catalog| P::select(catalog, package.id()))
                    .is_ok_and(|signed| {
                        serde_json::to_vec(&signed).ok().as_deref() == Some(manifest.as_slice())
                    })
            })
    {
        return Ok(
            serde_json::json!({"generation":selected.active,"downloaded_bytes":0,"reused_bytes":reused}),
        );
    }
    #[cfg(unix)]
    if let Some(name) = package.executable() {
        use std::os::unix::fs::PermissionsExt;
        let executable = directory.join(name);
        tokio::fs::set_permissions(executable, std::fs::Permissions::from_mode(0o755)).await?;
    }
    let mut record = std::fs::File::create(stage.path().join("manifest.json"))?;
    record.write_all(&manifest)?;
    record.sync_all()?;
    let generation = stage
        .path()
        .file_name()
        .and_then(|name| name.to_str())
        .context("invalid generation directory")?
        .to_owned();
    let selection = Selection {
        active: generation.clone(),
        previous: (!selected.active.is_empty()).then_some(selected.active),
        automatic_updates_paused: false,
    };
    let mut next = tempfile::NamedTempFile::new_in(&root)?;
    serde_json::to_writer(next.as_file_mut(), &selection)?;
    next.as_file().sync_all()?;
    // A first signed install can replace a running built-in native runtime.
    // The device lease orders every activation against generation admission.
    let _activation = wait_for_activation(state, transfer).await;
    transfer.stage("activating", None);
    next.persist(root.join("active.json"))?;
    let _generation_path = stage.keep();
    Ok(
        serde_json::json!({"generation":generation,"downloaded_bytes":downloaded,"reused_bytes":reused}),
    )
}

async fn wait_for_activation(
    state: &AppState,
    transfer: &super::progress::Transfer,
) -> tokio::sync::OwnedRwLockWriteGuard<()> {
    loop {
        let lease = match state.engine_use.clone().try_write_owned() {
            Ok(lease) => lease,
            Err(_) => {
                transfer.stage("waiting_for_idle", None);
                state.engine_use.clone().write_owned().await
            }
        };
        // A native queue or a trainer can still be working after releasing
        // its admission lease. Let it finish without holding up its cleanup.
        if !local_work_pending(state).await {
            return lease;
        }
        transfer.stage("waiting_for_idle", None);
        drop(lease);
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;
    }
}

async fn local_work_pending(state: &AppState) -> bool {
    let songs_running = state.jobs.read().await.values().any(crate::song_in_engine);
    songs_running || state.training.active_run().await.is_some()
}

pub(crate) struct InstalledEngine {
    pub(crate) executable: PathBuf,
    pub(crate) generation: String,
    pub(crate) version: String,
    pub(crate) protocol: String,
}

#[derive(Clone, Copy, Default, Deserialize, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Probe {
    #[default]
    Sha256,
    Presence,
}

#[derive(Default, Deserialize)]
pub(crate) struct StatusQuery {
    #[serde(default)]
    probe: Probe,
}

async fn resolve_package<P: Package>(
    data_root: &Path,
    id: &str,
    generation: Option<&str>,
    probe: Probe,
) -> Result<(P, PathBuf, String)> {
    let (package, files, generation) = read_package::<P>(data_root, id, generation).await?;
    verify_package_files(&package, &files, probe).await?;
    Ok((package, files, generation))
}

async fn read_package<P: Package>(
    data_root: &Path,
    id: &str,
    generation: Option<&str>,
) -> Result<(P, PathBuf, String)> {
    ensure!(portable_name(id), "invalid engine id");
    let root = crate::model_storage::folder(data_root, P::FOLDER).join(id);
    let selected = match generation {
        Some(value) => value.to_owned(),
        None => read_selection(&root)?.active,
    };
    ensure!(
        selected.starts_with("generation-") && portable_name(&selected),
        "no valid installed generation selected"
    );
    let dir = root.join(&selected);
    let proof = channel::verify_engine_proof(&dir.join("proof")).await?;
    let package = P::select(parse(&proof)?, id)?;
    // Resolve the actual files from the signed catalogue. Editable local
    // manifest fields must never decide which binary runs for a saved song.
    let files = dir.join("files");
    Ok((package, files, selected))
}

async fn verify_package_files<P: Package>(package: &P, files: &Path, probe: Probe) -> Result<()> {
    ensure!(
        only_signed_files(files, package).await?,
        "engine directory contains missing or undeclared files"
    );
    for item in package.files() {
        let path = files.join(item.relative_path());
        let valid = match probe {
            Probe::Sha256 => verified(path, item).await?,
            Probe::Presence => tokio::fs::symlink_metadata(path)
                .await
                .is_ok_and(|meta| meta.is_file() && meta.len() == item.bytes),
        };
        ensure!(
            valid,
            "installed engine file failed verification: {}",
            item.name
        );
    }
    Ok(())
}

pub(crate) async fn require_pair_presence(
    data_root: &Path,
    engine: &str,
    model: &str,
    generation: Option<&str>,
    model_generation: Option<&str>,
) -> Result<()> {
    inspect_engine(data_root, engine, generation, Probe::Presence).await?;
    inspect_model(data_root, engine, model, model_generation, Probe::Presence).await?;
    Ok(())
}

pub(crate) async fn resolve_generation(
    data_root: &Path,
    id: &str,
    generation: Option<&str>,
) -> Result<InstalledEngine> {
    inspect_engine(data_root, id, generation, Probe::Sha256).await
}

#[derive(Deserialize, Serialize)]
pub(crate) struct NativeIdentity {
    engine: String,
    generation: String,
    version: String,
}

pub(crate) async fn resolve_native(
    data_root: &Path,
    id: &str,
    explicit_override: bool,
    replay: Option<&serde_json::Value>,
    probe: Probe,
) -> Result<Option<(PathBuf, NativeIdentity)>> {
    let saved: Option<NativeIdentity> = replay
        .filter(|value| !value.is_null())
        .map(|value| serde_json::from_value(value.clone()))
        .transpose()
        .context("Invalid saved native runtime identity")?;
    // Old native songs have no signed identity and replay with the legacy resolver.
    if saved.is_none() && (explicit_override || replay.is_some()) {
        return Ok(None);
    }
    ensure!(
        matches!(id, crate::ace::ENGINE_ID | crate::native_minimax::ENGINE_ID),
        "unknown first-party native runtime"
    );
    let selection = match &saved {
        Some(saved) => {
            ensure!(
                saved.engine == id,
                "saved native runtime belongs to another engine"
            );
            saved.generation.clone()
        }
        None => {
            let selection = read_selection(&crate::model_storage::folder(data_root, EnginePackage::FOLDER).join(id))?;
            if selection.active.is_empty() {
                return Ok(None);
            }
            selection.active
        }
    };
    let (package, files, generation) =
        read_package::<EnginePackage>(data_root, id, Some(&selection))
            .await
            .context("Verify native music runtime package")?;
    let Some(native) = package.compatible_native() else {
        ensure!(
            saved.is_none(),
            "saved package has no compatible native runtime"
        );
        return Ok(None);
    };
    if let Some(saved) = saved {
        ensure!(
            saved.version == package.version,
            "saved native runtime version does not match the signed package"
        );
    }
    verify_package_files(&package, &files, probe).await?;
    Ok(Some((
        files.join(&native.executable),
        NativeIdentity {
            engine: id.into(),
            generation,
            version: package.version,
        },
    )))
}

pub(crate) const YUE2_TRAINER_PROTOCOL: &str = "yue2-train-v1";

#[cfg(test)]
#[tokio::test]
async fn signed_native_universal_layout_verifies_only_the_two_fixed_cuda_plugins() {
    use serde_json::json;
    let pin = |name: &str, bytes: &[u8]| {
        json!({"name":name,"bytes":bytes.len(),
            "sha256":Sha256::digest(bytes).iter().map(|byte| format!("{byte:02x}")).collect::<String>(),
            "url":format!("https://example.org/{name}")})
    };
    for (engine, exe) in [(crate::ace::ENGINE_ID, "ace-server.exe"), (crate::native_minimax::ENGINE_ID, "mm-server.exe")] {
        let mut cuda12 = pin("ggml-cuda12.dll", b"cuda12");
        cuda12["cuda_variant"] = json!("cuda12");
        let mut cuda13 = pin("ggml-cuda13.dll", b"cuda13");
        cuda13["cuda_variant"] = json!("cuda13");
        let mut raw = json!({"id":engine,"name":engine,"version":"2","platform":"windows-x86_64",
            "protocol":super::NATIVE_WINDOWS_PROTOCOL,"executable":exe,
            "native_runtime":{"api_version":2,"executable":exe},
            "files":[pin(exe, b"native"),cuda12,cuda13]});
        let read = |item: &serde_json::Value| parse(&serde_json::to_vec(
            &json!({"schema":1,"engines":[item]})).unwrap());
        let pkg = read(&raw).unwrap().engines.pop().unwrap();
        assert!(pkg.installable());
        assert!(!supported_protocol(&pkg.protocol));
        let root = tempfile::tempdir().unwrap();
        for (file, bytes) in pkg.files.iter().zip([b"native", b"cuda12", b"cuda13"]) {
            let target = root.path().join(file.relative_path());
            std::fs::create_dir_all(target.parent().unwrap()).unwrap();
            std::fs::write(target, bytes).unwrap();
        }
        assert!(root.path().join("cuda12/ggml-cuda.dll").is_file());
        assert!(root.path().join("cuda13/ggml-cuda.dll").is_file());
        verify_package_files(&pkg, root.path(), Probe::Sha256).await.unwrap();
        std::fs::write(root.path().join("cuda12/other.dll"), b"extra").unwrap();
        assert!(!only_signed_files(root.path(), &pkg).await.unwrap());
        std::fs::remove_file(root.path().join("cuda12/other.dll")).unwrap();
        std::fs::write(root.path().join("cuda12/ggml-cuda.dll"), b"cuda13").unwrap();
        assert!(verify_package_files(&pkg, root.path(), Probe::Sha256).await.is_err());
        raw["files"].as_array_mut().unwrap().push(pin("ggml-cuda-extra.dll", b"extra"));
        assert!(read(&raw).is_err());
        raw["files"].as_array_mut().unwrap().pop();
        raw["files"].as_array_mut().unwrap().pop();
        assert!(read(&raw).is_err());
    }
}

#[cfg(test)]
#[tokio::test]
async fn native_resolution_keeps_legacy_replay_and_overrides_separate_from_signed_replay() {
    use serde_json::json;
    let root = tempfile::tempdir().unwrap();
    for engine in [crate::ace::ENGINE_ID, crate::native_minimax::ENGINE_ID] {
        let saved = json!({"engine":engine,"generation":"generation-retained","version":"1"});
        let resolve =
            |explicit, replay| resolve_native(root.path(), engine, explicit, replay, Probe::Sha256);
        assert!(resolve(false, None).await.unwrap().is_none());
        let directory = root.path().join(EnginePackage::FOLDER).join(engine);
        std::fs::create_dir_all(&directory).unwrap();
        std::fs::write(
            directory.join("active.json"),
            r#"{"active":"generation-current","previous":"generation-retained"}"#,
        )
        .unwrap();
        assert!(resolve(true, None).await.unwrap().is_none());
        assert!(
            resolve(false, Some(&serde_json::Value::Null))
                .await
                .unwrap()
                .is_none()
        );
        assert!(
            resolve(true, Some(&saved)).await.is_err(),
            "a missing signed replay generation must not use the external executable"
        );
        assert!(
            resolve(false, None).await.is_err(),
            "an installed selection without proof must fail verification"
        );
    }
}

pub(super) fn supported_protocol(protocol: &str) -> bool {
    matches!(protocol, "music-http-v1" | YUE2_TRAINER_PROTOCOL)
}

async fn inspect_engine(
    data_root: &Path,
    id: &str,
    generation: Option<&str>,
    probe: Probe,
) -> Result<InstalledEngine> {
    let engine = inspect_component(data_root, id, generation, probe).await?;
    ensure!(engine.protocol == "music-http-v1", "incompatible engine protocol");
    Ok(engine)
}

pub(crate) async fn resolve_trainer(
    data_root: &Path,
    id: &str,
    generation: Option<&str>,
) -> Result<InstalledEngine> {
    let trainer = inspect_component(data_root, id, generation, Probe::Sha256).await?;
    ensure!(trainer.protocol == YUE2_TRAINER_PROTOCOL, "incompatible YuE2 trainer protocol");
    Ok(trainer)
}

async fn inspect_component(
    data_root: &Path,
    id: &str,
    generation: Option<&str>,
    probe: Probe,
) -> Result<InstalledEngine> {
    let (package, files, selected) =
        resolve_package::<EnginePackage>(data_root, id, generation, probe).await?;
    ensure!(package.installable(), "incompatible component protocol");
    Ok(InstalledEngine {
        executable: files.join(package.executable),
        generation: selected,
        version: package.version,
        protocol: package.protocol,
    })
}

pub(crate) async fn status(
    State(state): State<AppState>,
    RoutePath(id): RoutePath<String>,
    axum::extract::Query(query): axum::extract::Query<StatusQuery>,
) -> Result<Json<serde_json::Value>, Failure> {
    let current = inspect_component(update_data_root(&state), &id, None, query.probe)
        .await
        .map_err(|error| api_error(StatusCode::CONFLICT, format!("{error:#}")))?;
    let selection = read_selection(
        &crate::model_storage::folder(update_data_root(&state), EnginePackage::FOLDER)
            .join(&id),
    )
    .map_err(|e| api_error(StatusCode::CONFLICT, format!("{e:#}")))?;
    Ok(Json(
        serde_json::json!({"id": id,"previous_generation":selection.previous.filter(|_| selection.active == current.generation),"generation":current.generation,"version":current.version,
        "verification":query.probe,"protocol":current.protocol,"executable":current.executable.file_name().and_then(|name| name.to_str())}),
    ))
}
pub(crate) async fn install_selected(
    State(state): State<AppState>,
    RoutePath(id): RoutePath<String>,
) -> Result<Json<serde_json::Value>, Failure> {
    update_engine(&state, &id, false).await
}

async fn update_engine(
    state: &AppState,
    id: &str,
    automatic: bool,
) -> Result<Json<serde_json::Value>, Failure> {
    let catalog = current_catalogue().await?;
    let platform = host_platform();
    let package = catalog
        .engines
        .iter()
        .find(|p| p.id == id && p.platform == platform)
        .ok_or_else(|| {
            api_error(
                StatusCode::NOT_FOUND,
                "No signed engine package for this platform.".into(),
            )
        })?;
    if !package.installable() {
        return Err(api_error(
            StatusCode::UNPROCESSABLE_ENTITY,
            "This engine needs a different Studio protocol.".into(),
        ));
    }
    install(state, package, automatic)
        .await
        .map(Json)
        .map_err(|e| api_error(StatusCode::CONFLICT, format!("{e:#}")))
}

pub(crate) struct InstalledModel {
    pub(crate) files: PathBuf,
    pub(crate) generation: String,
    pub(crate) version: String,
}

pub(crate) async fn resolve_model_generation(
    data_root: &Path,
    engine_id: &str,
    model_id: &str,
    generation: Option<&str>,
) -> Result<InstalledModel> {
    inspect_model(data_root, engine_id, model_id, generation, Probe::Sha256).await
}

async fn inspect_model(
    data_root: &Path,
    engine_id: &str,
    model_id: &str,
    generation: Option<&str>,
    probe: Probe,
) -> Result<InstalledModel> {
    let (model, files, generation) =
        resolve_package::<ModelPackage>(data_root, model_id, generation, probe).await?;
    ensure!(
        model.engines.iter().any(|id| id == engine_id),
        "model is incompatible with the selected engine"
    );
    Ok(InstalledModel {
        files,
        generation,
        version: model.version,
    })
}

pub(crate) async fn install_model(
    State(state): State<AppState>,
    RoutePath(id): RoutePath<String>,
) -> Result<Json<serde_json::Value>, Failure> {
    update_model(&state, &id, false).await
}

async fn update_model(
    state: &AppState,
    id: &str,
    automatic: bool,
) -> Result<Json<serde_json::Value>, Failure> {
    let catalog = current_catalogue().await?;
    let model = ModelPackage::select(catalog, &id)
        .map_err(|e| api_error(StatusCode::NOT_FOUND, e.to_string()))?;
    install(state, &model, automatic)
    .await
    .map(Json)
    .map_err(|e| api_error(StatusCode::CONFLICT, format!("{e:#}")))
}

pub(crate) async fn trainer_choices(data_root: &Path) -> Vec<serde_json::Value> {
    let Ok(catalog) = current_catalogue().await else { return Vec::new(); };
    let platform = host_platform();
    let mut choices = Vec::new();
    for package in catalog.engines.into_iter().filter(|p| p.platform == platform && p.protocol == YUE2_TRAINER_PROTOCOL) {
        let current = inspect_component(data_root, &package.id, None, Probe::Presence).await.ok()
            .filter(|installed| installed.protocol == YUE2_TRAINER_PROTOCOL);
        choices.push(serde_json::json!({
            "id": package.id,
            "label": package.name,
            "version": package.version,
            "installed": current.is_some(),
            "installed_version": current.as_ref().map(|installed| &installed.version),
            "bytes": package.files.iter().map(|file| file.bytes).sum::<u64>(),
        }));
    }
    choices
}

async fn current_catalogue() -> Result<Catalogue, Failure> {
    let bytes = channel::cached_catalogue(channel::ENGINES)
        .await
        .map_err(|e| api_error(StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
        .ok_or_else(|| {
            api_error(
                StatusCode::NOT_FOUND,
                "Refresh the signed engine catalogue first.".into(),
            )
        })?;
    parse(&bytes).map_err(|e| api_error(StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))
}

pub(crate) async fn model_status(
    State(state): State<AppState>,
    RoutePath((engine, id)): RoutePath<(String, String)>,
    axum::extract::Query(query): axum::extract::Query<StatusQuery>,
) -> Result<Json<serde_json::Value>, Failure> {
    let model = inspect_model(update_data_root(&state), &engine, &id, None, query.probe)
        .await
        .map_err(|e| api_error(StatusCode::CONFLICT, format!("{e:#}")))?;
    let selection = read_selection(
        &crate::model_storage::folder(update_data_root(&state), ModelPackage::FOLDER)
            .join(&id),
    )
    .map_err(|e| api_error(StatusCode::CONFLICT, format!("{e:#}")))?;
    Ok(Json(
        serde_json::json!({"id":id,"previous_generation":selection.previous.filter(|_| selection.active == model.generation),"engine":engine,"generation":model.generation,"version":model.version,"verification":query.probe}),
    ))
}
