# YuE2 Studio 5.0.0 (Debian) – cztery zmiany w jednym archiwum

Zawiera:
1. Zapamiętywanie miejsc zapisu (autozapis ustawień, ostatni folder dla każdego rodzaju pliku).
2. Przycisk „Przeglądaj…” w Ustawienia → Miejsca zapisu.
3. Osobne foldery dla silników i ich modeli (Ustawienia → Modele → „Każdy folder osobno”).
4. Przewijany pasek sekcji w oknie ustawień.

Poprawki z przeglądu kodu:
- pliki ustawień zapisywane w całości (plik tymczasowy + zmiana nazwy) – przerwany zapis nie kasuje już ustawień,
- tylko jedno okno wyboru folderu naraz,
- przenoszenie folderów i instalacja pakietów nie mogą wystartować jednocześnie,
- kopie „.part” przy autokopiowaniu mają unikalne nazwy i nie zostają po błędzie,
- lista sekcji ustawień nie przeskakuje do wybranej pozycji przy odświeżeniu,
- „Przeglądaj…” nie nadpisuje zmian zrobionych w trakcie otwartego okna,
- testy integracyjne dostały klucz lokalnego API (wcześniej 13 z nich padało z 401) oraz nowy test zabezpieczeń.

Jak nałożyć (wybierz jedno):
A) Katalog YuE2-Studio/ – skopiuj jego zawartość do katalogu ze źródłami (całe pliki, nadpisz).
B) YuE2-Studio-5.0.0-debian.patch – pełna łatka na CZYSTE źródła v5.0.0 (wszystkie dotychczasowe zmiany Debiana + te cztery):
   cd YuE2-Studio && git apply YuE2-Studio-5.0.0-debian.patch

Potem: sudo scripts/build-debian.sh
