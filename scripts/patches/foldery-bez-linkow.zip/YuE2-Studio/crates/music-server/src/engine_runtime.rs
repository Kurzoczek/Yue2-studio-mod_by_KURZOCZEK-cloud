//! The CUDA libraries the music engine is linked against.
//!
//! The engine loads one of two CUDA backends at run time, `cuda13\ggml-cuda.dll`
//! or `cuda12\ggml-cuda.dll`, whichever the card and its driver run (see
//! `hardware::CudaBuild`). Each imports its own cuBLAS, `cublas64_13.dll` or
//! `cublas64_12.dll`, which imports `cublasLt64_1x.dll`. The loader resolves
//! them from the executable's folder, so they go beside `yue-server.exe`, and
//! the two majors never clash by name. A missing cuBLAS fails the backend
//! load, and the engine stops on it.
//!
//! The two libraries are 512 MB unpacked, which is four times the rest of the
//! installer, so they are not shipped - they are fetched from NVIDIA's own
//! redistributable archive the first time the engine is asked to start, the
//! same way the models are. The build machine has them on PATH through the CUDA
//! Toolkit, which is exactly why this was invisible until someone without the
//! Toolkit ran the release.

use std::path::{Path, PathBuf};

use anyhow::{bail, Context, Result};

use crate::downloads::{Asset, AssetKind, Downloader};
use crate::hardware::CudaBuild;

/// The libraries of each build, by file name, exactly as its ggml-cuda.dll
/// imports them. The CUDA major is part of the name, so a rebuild on another
/// major is a change here, and the dependency check below catches it.
pub const CUDA13_LIBRARIES: [&str; 2] = ["cublas64_13.dll", "cublasLt64_13.dll"];
pub const CUDA12_LIBRARIES: [&str; 2] = ["cublas64_12.dll", "cublasLt64_12.dll"];

/// The Visual C++ runtime the engine, ggml and the ONNX Runtime the studio
/// loads are compiled against, by the names in their import tables:
/// onnxruntime.dll imports msvcp140_1.dll.
pub const VC_RUNTIME_LIBRARIES: [&str; 5] =
    ["vcruntime140.dll", "vcruntime140_1.dll", "msvcp140.dll", "msvcp140_1.dll", "vcomp140.dll"];


#[cfg(not(target_os = "linux"))]
pub const ASSETS: &[Asset] = &[CUBLAS13, CUBLAS12];
#[cfg(target_os = "linux")]
pub const ASSETS: &[Asset] = &[LINUX_CUDA13[0], LINUX_CUDA13[1], LINUX_CUDA12[0], LINUX_CUDA12[1]];

const CUBLAS13: Asset = Asset {
    id: "engine-cuda-cublas",
    label: "NVIDIA cuBLAS 13.5",
    kind: AssetKind::Runtime,
    // NVIDIA's redistributable archive, the same one every CUDA application
    // ships from. The size and the digest are published in
    // redist/redistrib_13.3.0.json; the size below was confirmed against a
    // live HEAD request, which also confirmed range support.
    url: "https://developer.download.nvidia.com/compute/cuda/redist/libcublas/windows-x86_64/libcublas-windows-x86_64-13.5.1.27-archive.zip",
    relative_path: "cuda-cublas.zip",
    bytes: 391_055_517,
    // No sub-directory: the libraries go straight in beside yue-server.exe,
    // which is where the Windows loader looks first and what NVIDIA's own
    // deployment guide recommends.
    unzip_into: None,
    marker: "cublasLt64_13.dll",
    pick: &CUDA13_LIBRARIES,
    vram_gb: None,
    note: "The linear algebra the engine's CUDA backend is linked against. Without it the engine cannot start at all.",
};

const CUBLAS12: Asset = Asset {
    id: "engine-cuda12-cublas",
    label: "NVIDIA cuBLAS 12.9",
    kind: AssetKind::Runtime,
    // The cuBLAS of the CUDA 12.9 toolkit the CUDA 12 backend is built with.
    // Size from redist/redistrib_12.9.1.json, confirmed by a HEAD request.
    url: "https://developer.download.nvidia.com/compute/cuda/redist/libcublas/windows-x86_64/libcublas-windows-x86_64-12.9.1.4-archive.zip",
    relative_path: "cuda12-cublas.zip",
    bytes: 549_755_186,
    unzip_into: None,
    marker: "cublasLt64_12.dll",
    pick: &CUDA12_LIBRARIES,
    vram_gb: None,
    note: "The linear algebra of the engine's CUDA 12 backend, for cards CUDA 13 dropped and older drivers.",
};

pub(crate) fn is_shared_windows_cublas(asset: &Asset) -> bool {
    asset.url == CUBLAS12.url || asset.url == CUBLAS13.url
}

/// NVIDIA serves the same pinned Windows CUDA 12 archive from both domains.
pub(crate) fn archive_mirror(url: &str) -> Option<&'static str> {
    (url == CUBLAS12.url).then_some(
        "https://developer.download.nvidia.cn/compute/cuda/redist/libcublas/windows-x86_64/libcublas-windows-x86_64-12.9.1.4-archive.zip",
    )
}

/// The cuBLAS a CUDA build loads.
pub fn cublas_asset(build: CudaBuild) -> &'static Asset {
    match build {
        CudaBuild::Cuda13 => &CUBLAS13,
        CudaBuild::Cuda12 => &CUBLAS12,
    }
}

/// Linux: the CUDA runtime and cuBLAS of the engine's CUDA 13 backend, from NVIDIA's manylinux wheels, which the
/// audio.cpp server's CUDA 13 build loads too: one copy in `<data>/engine-runtime/cuda`, named in LD_LIBRARY_PATH.
pub const LINUX_CUDA13: [Asset; 2] = [
    Asset {
        id: "engine-cuda-cudart-linux",
        label: "NVIDIA CUDA runtime 13.4",
        kind: AssetKind::Runtime,
        url: "https://files.pythonhosted.org/packages/98/8a/3431271f6344874b8f1ac03f16b3d679c91493f8da63f716160403e6d0a0/nvidia_cuda_runtime-13.4.92-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl",
        relative_path: "cuda13-cudart.whl",
        bytes: 2_494_438,
        unzip_into: None,
        marker: "libcudart.so.13",
        pick: &["libcudart.so.13"],
        vram_gb: None,
        note: "The CUDA runtime of the engine's CUDA 13 backend and of the audio.cpp server.",
    },
    Asset {
        id: "engine-cuda-cublas-linux",
        label: "NVIDIA cuBLAS 13.8",
        kind: AssetKind::Runtime,
        url: "https://files.pythonhosted.org/packages/7a/38/bdd540bf511d2c9b6f9efc71a81c60cb88e295be0b9312b61d19bbed2212/nvidia_cublas-13.8.0.4-py3-none-manylinux_2_27_x86_64.whl",
        relative_path: "cuda13-cublas.whl",
        bytes: 439_317_144,
        unzip_into: None,
        marker: "libcublasLt.so.13",
        pick: &["libcublas.so.13", "libcublasLt.so.13"],
        vram_gb: None,
        note: "The linear algebra of the engine's CUDA 13 backend and of the audio.cpp server.",
    },
];

/// Linux: the CUDA runtime and cuBLAS of the engine's CUDA 12 backend, the CUDA 12.9 wheels the audio.cpp server's
/// CUDA 12 build loads too; their names carry the major, so they share the folder with the CUDA 13 ones.
pub const LINUX_CUDA12: [Asset; 2] = [
    Asset {
        id: "engine-cuda12-cudart-linux",
        label: "NVIDIA CUDA runtime 12.9",
        kind: AssetKind::Runtime,
        url: "https://files.pythonhosted.org/packages/bc/46/a92db19b8309581092a3add7e6fceb4c301a3fd233969856a8cbf042cd3c/nvidia_cuda_runtime_cu12-12.9.79-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl",
        relative_path: "cuda12-cudart.whl",
        bytes: 3_493_179,
        unzip_into: None,
        marker: "libcudart.so.12",
        pick: &["libcudart.so.12"],
        vram_gb: None,
        note: "The CUDA runtime of the engine's CUDA 12 backend and of the audio.cpp server.",
    },
    Asset {
        id: "engine-cuda12-cublas-linux",
        label: "NVIDIA cuBLAS 12.9",
        kind: AssetKind::Runtime,
        url: "https://files.pythonhosted.org/packages/cb/c0/0a517bfe63ccd3b92eb254d264e28fca3c7cab75d07daea315250fb1bf73/nvidia_cublas_cu12-12.9.2.10-py3-none-manylinux_2_27_x86_64.whl",
        relative_path: "cuda12-cublas.whl",
        bytes: 581_240_110,
        unzip_into: None,
        marker: "libcublasLt.so.12",
        pick: &["libcublas.so.12", "libcublasLt.so.12"],
        vram_gb: None,
        note: "The linear algebra of the engine's CUDA 12 backend and of the audio.cpp server.",
    },
];

/// The downloads a CUDA build of the engine needs on this platform: cuBLAS beside the engine on Windows; on Linux the
/// CUDA runtime and cuBLAS of either build, in one folder the audio.cpp server shares.
pub fn cuda_assets(build: CudaBuild) -> Vec<&'static Asset> {
    if cfg!(target_os = "linux") {
        return match build {
            CudaBuild::Cuda13 => LINUX_CUDA13.iter().collect(),
            CudaBuild::Cuda12 => LINUX_CUDA12.iter().collect(),
        };
    }
    vec![cublas_asset(build)]
}

/// The engine's downloadable runtime.
pub struct EngineRuntime {
    downloader: Downloader,
    /// Where the engine and the Visual C++ runtime shipped with it live; read for the runtime on Windows alone.
    #[cfg_attr(not(windows), allow(dead_code))]
    bundle_root: std::path::PathBuf,
}

impl EngineRuntime {
    /// Takes the directory `yue-server.exe` lives in: the libraries belong
    /// beside the binary that imports them, not in a folder of their own.
    /// Where that directory cannot be written - an installation under Program
    /// Files - they go to the studio's data folder instead, which joins PATH:
    /// the engine inherits it, and Windows looks there for what its backend imports.
    /// On Linux they always go to `<data>/engine-runtime/cuda`, which joins LD_LIBRARY_PATH for the engine and the
    /// audio.cpp server alike: the package's own folder is read-only there.
    pub fn new(bundle_root: &Path, data_root: &Path) -> Self {
        if cfg!(target_os = "linux") {
            let folder = data_root.join("engine-runtime").join("cuda");
            let existing = std::env::var_os("LD_LIBRARY_PATH").unwrap_or_default();
            if let Ok(joined) = std::env::join_paths(std::iter::once(folder.clone()).chain(std::env::split_paths(&existing))) {
                unsafe { std::env::set_var("LD_LIBRARY_PATH", joined) };
            }
            return Self { downloader: Downloader::new(folder), bundle_root: bundle_root.to_path_buf() };
        }
        let root = if writable(bundle_root) {
            bundle_root.to_path_buf()
        } else {
            let elsewhere = data_root.join("engine-runtime");
            let existing = std::env::var_os("PATH").unwrap_or_default();
            if let Ok(joined) = std::env::join_paths(std::iter::once(elsewhere.clone()).chain(std::env::split_paths(&existing))) {
                unsafe { std::env::set_var("PATH", joined) };
            }
            elsewhere
        };
        Self { downloader: Downloader::new(root), bundle_root: bundle_root.to_path_buf() }
    }

    pub fn downloader(&self) -> &Downloader {
        &self.downloader
    }

    /// Where the libraries live once installed - beside the engine.
    pub fn library_dir(&self) -> PathBuf {
        self.downloader.root().to_path_buf()
    }

    /// Whether the engine will find every library it needs. cuBLAS counts only
    /// when the engine will compute on CUDA, and only the one of that build:
    /// the bundled engine loads its backends at run time, so on an AMD or
    /// Intel card, or with Vulkan chosen, no CUDA backend is ever loaded.
    ///
    /// The Visual C++ runtime counts always: a machine that already has cuBLAS
    /// but no redistributable has nothing to download and still cannot start
    /// the engine.
    pub fn is_ready(&self, cuda: Option<CudaBuild>) -> bool {
        self.missing(cuda).is_empty() && self.vc_runtime_missing().is_empty()
    }

    /// The Visual C++ runtime ships inside the engine bundle, app-local as
    /// Microsoft permits, so the studio never installs anything into the
    /// system. A machine that has it on its search path is fine either way.
    #[cfg(windows)]
    pub fn vc_runtime_missing(&self) -> Vec<&'static str> {
        VC_RUNTIME_LIBRARIES
            .iter()
            .copied()
            .filter(|library| !self.bundle_root.join(library).is_file() && !is_on_the_search_path(library))
            .collect()
    }

    /// Off Windows the engine is built against the platform's own runtime
    /// (libc++ and the system libraries), which is always present: nothing to
    /// check, nothing to fetch.
    #[cfg(not(windows))]
    pub fn vc_runtime_missing(&self) -> Vec<&'static str> {
        Vec::new()
    }

    /// What is still missing, so a caller can report the size before starting.
    ///
    /// A machine that already has the libraries on its search path - a CUDA
    /// Toolkit installation - downloads nothing: the engine inherits that path
    /// and finds them there.
    pub fn missing(&self, cuda: Option<CudaBuild>) -> Vec<&'static Asset> {
        let Some(build) = cuda else { return Vec::new() };
        cuda_assets(build)
            .into_iter()
            .filter(|asset| !self.downloader.is_installed(asset) && !asset.pick.iter().all(|library| is_on_the_search_path(library)))
            .collect()
    }

    /// Fetches whatever is missing and waits for it.
    pub async fn install_missing(&self, cuda: Option<CudaBuild>) -> Result<()> {
        self.install_missing_for(cuda, "engine").await
    }

    pub async fn install_missing_for(&self, cuda: Option<CudaBuild>, scope: &str) -> Result<()> {
        self.install_missing_with_cancel(cuda, scope, None).await
    }

    pub(crate) async fn install_missing_with_cancel(
        &self, cuda: Option<CudaBuild>, scope: &str, cancelled: Option<&(dyn Fn() -> bool + Sync)>,
    ) -> Result<()> {
        let absent = self.vc_runtime_missing();
        if !absent.is_empty() {
            bail!("the engine bundle is incomplete: {} missing beside yue-server.exe; reinstall the studio", absent.join(", "));
        }
        self.downloader.install_all_with_cancel(scope, &self.missing(cuda), cancelled).await
    }
}

/// Whether files can be written into `directory`, found by writing one.
fn writable(directory: &Path) -> bool {
    if std::fs::create_dir_all(directory).is_err() {
        return false;
    }
    let probe = directory.join(format!(".write-probe-{}", std::process::id()));
    let written = std::fs::write(&probe, b"").is_ok();
    let _ = std::fs::remove_file(&probe);
    written
}

/// Whether the loader would already find this library without help: the engine inherits this process's PATH (on
/// Linux its LD_LIBRARY_PATH), so a machine with the CUDA Toolkit there downloads nothing.
fn is_on_the_search_path(library: &str) -> bool {
    let variable = if cfg!(windows) { "PATH" } else { "LD_LIBRARY_PATH" };
    let Some(path) = std::env::var_os(variable) else { return false };
    std::env::split_paths(&path).any(|directory| directory.join(library).is_file())
}

/// The DLLs a Windows binary names in its import table and its delay-load table.
///
/// NVIDIA's deployment guide says to read this with `dumpbin /IMPORTS` and
/// redistribute exactly what it lists, because the binary compatibility
/// version is part of the file name - `cublas64_13.dll`, not `cublas.dll`.
/// Reading it here means the release can check itself instead of trusting
/// that whoever built it remembered.
pub fn imported_libraries(binary: &Path) -> Result<Vec<String>> {
    let data = std::fs::read(binary)?;
    let at = |offset: usize| -> Result<u32> {
        let bytes = data.get(offset..offset + 4).context("truncated PE header")?;
        Ok(u32::from_le_bytes(bytes.try_into().expect("four bytes")))
    };
    let short = |offset: usize| -> Result<u16> {
        let bytes = data.get(offset..offset + 2).context("truncated PE header")?;
        Ok(u16::from_le_bytes(bytes.try_into().expect("two bytes")))
    };

    let pe = at(0x3c)? as usize;
    if data.get(pe..pe + 4) != Some(b"PE\0\0") {
        bail!("{} is not a PE binary", binary.display());
    }
    let sections = short(pe + 6)? as usize;
    let optional_size = short(pe + 20)? as usize;
    let optional = pe + 24;
    // 0x20b is PE32+, whose data directories start 16 bytes further in.
    let directories = optional + if short(optional)? == 0x20b { 112 } else { 96 };

    let headers: Vec<(u32, u32, u32)> = (0..sections)
        .map(|index| {
            let base = optional + optional_size + index * 40;
            Ok((at(base + 12)?, at(base + 16)?, at(base + 20)?))
        })
        .collect::<Result<_>>()?;
    let offset_of = |rva: u32| -> Option<usize> {
        headers
            .iter()
            .find(|(virtual_address, size, _)| rva >= *virtual_address && rva < virtual_address + size)
            .map(|(virtual_address, _, raw)| (raw + (rva - virtual_address)) as usize)
    };

    let mut names = Vec::new();
    // (data directory, descriptor size, offset of the name's RVA in it): the import table (1) and the delay-load
    // table (13), where a library loaded on first use is named.
    for (directory, descriptor_size, name_field) in [(1usize, 20usize, 12usize), (13, 32, 4)] {
        let table_rva = at(directories + directory * 8)?;
        if table_rva == 0 {
            continue;
        }
        let mut entry = offset_of(table_rva).context("import table points outside the file")?;
        loop {
            let descriptor = data.get(entry..entry + descriptor_size).context("truncated import table")?;
            if descriptor.iter().all(|byte| *byte == 0) {
                break;
            }
            let name_rva = u32::from_le_bytes(descriptor[name_field..name_field + 4].try_into().expect("four bytes"));
            let start = offset_of(name_rva).context("an import name points outside the file")?;
            let end = data[start..].iter().position(|byte| *byte == 0).context("unterminated import name")? + start;
            names.push(String::from_utf8_lossy(&data[start..end]).into_owned());
            entry += descriptor_size;
        }
    }
    Ok(names)
}

/// Libraries every Windows machine has, or that arrive with the display
/// driver. Everything else has to be shipped or downloaded.
fn is_provided_by_the_system(name: &str) -> bool {
    let name = name.to_ascii_lowercase();
    name.starts_with("api-ms-win-")
        || name.starts_with("ext-ms-win-")
        // The display driver's own library: NVIDIA's guide is explicit that
        // this one is never redistributed - the user installs a driver.
        || name == "nvcuda.dll"
        // The Vulkan loader arrives with every display driver, AMD's and Intel's as NVIDIA's.
        || name == "vulkan-1.dll"
        || [
            "kernel32.dll",
            "kernelbase.dll",
            "user32.dll",
            "advapi32.dll",
            "shell32.dll",
            "ole32.dll",
            "oleaut32.dll",
            "ws2_32.dll",
            "crypt32.dll",
            "bcrypt.dll",
            "bcryptprimitives.dll",
            "ntdll.dll",
            "rpcrt4.dll",
            "setupapi.dll",
            "cfgmgr32.dll",
            "gdi32.dll",
            "version.dll",
            "dbghelp.dll",
            "powrprof.dll",
            "psapi.dll",
            "userenv.dll",
            "winmm.dll",
            "msvcrt.dll",
            "d3d12.dll",
            "dxgi.dll",
            "dxcore.dll",
            "shlwapi.dll",
            "imm32.dll",
            "pdh.dll",
            "iphlpapi.dll",
            "secur32.dll",
            "ncrypt.dll",
        ]
        .contains(&name.as_str())
}

/// What a binary needs that is neither beside it nor supplied by Windows.
///
/// Follows the chain: `yue-server.exe` imports `ggml.dll`, which imports
/// `ggml-cuda.dll`, which is where cuBLAS actually comes in. Checking only the
/// executable's own imports would have found nothing wrong with the release
/// that could not start.
#[cfg(test)]
pub fn unresolved_dependencies(directory: &Path, entry_point: &str) -> Result<Vec<String>> {
    unresolved_in(&[directory.to_path_buf()], &directory.join(entry_point))
}

/// What `entry_point` needs that none of `directories` holds and Windows does
/// not supply: a downloaded tool resolves beside itself first, then in the
/// engine's folder, which the studio puts on its PATH.
pub fn unresolved_in(directories: &[std::path::PathBuf], entry_point: &Path) -> Result<Vec<String>> {
    let mut seen: Vec<String> = Vec::new();
    let mut queue = vec![entry_point.to_path_buf()];
    let mut missing = Vec::new();
    while let Some(path) = queue.pop() {
        for import in imported_libraries(&path)? {
            let lowered = import.to_ascii_lowercase();
            if is_provided_by_the_system(&import) || seen.contains(&lowered) {
                continue;
            }
            seen.push(lowered);
            match directories.iter().map(|directory| directory.join(&import)).find(|candidate| candidate.is_file()) {
                Some(found) => queue.push(found),
                None => missing.push(import),
            }
        }
    }
    Ok(missing)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg(not(target_os = "linux"))]
    fn libraries_go_to_the_data_folder_when_the_engine_folder_cannot_be_written() {
        let data = std::env::temp_dir().join(format!("engine-runtime-{}", uuid::Uuid::now_v7()));
        std::fs::create_dir_all(&data).unwrap();
        std::fs::write(data.join("a-file"), b"").unwrap();
        // a folder inside a file can be neither made nor written, as Program Files cannot without elevation
        let runtime = EngineRuntime::new(&data.join("a-file").join("engine"), &data);
        assert_eq!(runtime.library_dir(), data.join("engine-runtime"));
        let writable = data.join("install");
        std::fs::create_dir_all(&writable).unwrap();
        assert_eq!(EngineRuntime::new(&writable, &data).library_dir(), writable);
        std::fs::remove_dir_all(&data).ok();
    }

    /// The file names are the contract with the engine binary: they are what
    /// the import table asks the loader for, and what `pick` takes out of the
    /// archive. A typo here is a download that finishes and changes nothing.
    #[test]
    fn every_imported_library_is_picked_out_of_the_archive() {
        for (build, libraries, major) in
            [(CudaBuild::Cuda13, CUDA13_LIBRARIES, "13"), (CudaBuild::Cuda12, CUDA12_LIBRARIES, "12")]
        {
            let asset = cublas_asset(build);
            for library in libraries {
                assert!(library.contains(major), "{library} does not name CUDA {major}");
                assert!(asset.pick.contains(&library), "{library} is imported by {build:?} but never taken out of its archive");
            }
            assert!(asset.url.contains(&format!("-{major}.")), "{} is not a CUDA {major} cuBLAS", asset.url);
        }
    }

    /// A runtime asset that unpacks nowhere would download and vanish.
    #[test]
    fn the_libraries_land_in_one_directory_the_engine_can_be_pointed_at() {
        for asset in ASSETS {
            // Straight into the bundle: a sub-directory would put them
            // somewhere the loader does not look.
            assert_eq!(asset.unzip_into, None);
            assert_eq!(asset.kind, AssetKind::Runtime);
            assert!(asset.bytes > 0, "{} has no size, so nothing can report progress", asset.id);
        }
    }

    /// The release that shipped without cuBLAS passed every test there was,
    /// because no test ever looked at what the engine binary asks the loader
    /// for. This one does: whatever the staged bundle imports is either beside
    /// it, supplied by Windows, or downloaded on first start - and nothing
    /// else is allowed.
    #[test]
    #[cfg(windows)]
    fn the_staged_engine_bundle_can_actually_be_loaded() {
        let bundle = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../desktop/src-tauri/resources/yue2-cpp")
            .canonicalize();
        let Ok(bundle) = bundle else {
            // No engine has been built into the bundle on this machine, which
            // is the normal state of a checkout that only touches the service.
            return;
        };
        if !bundle.join("yue-server.exe").is_file() {
            return;
        }
        // The backends load at run time - the CUDA ones from their folders, Vulkan and the processor generations
        // beside the executable - and resolve their imports from the executable's folder, so each is checked
        // from there, not only what the executable imports.
        let mut entry_points = vec!["yue-server.exe".to_string()];
        for build in [CudaBuild::Cuda13, CudaBuild::Cuda12] {
            let backend = format!("{}/ggml-cuda.dll", build.folder());
            if bundle.join(&backend).is_file() {
                entry_points.push(backend);
            }
        }
        let handled: Vec<&str> =
            CUDA13_LIBRARIES.iter().chain(CUDA12_LIBRARIES.iter()).chain(VC_RUNTIME_LIBRARIES.iter()).copied().collect();
        for entry in std::fs::read_dir(&bundle).expect("read the bundle").flatten() {
            let name = entry.file_name().to_string_lossy().into_owned();
            if name.to_ascii_lowercase().starts_with("ggml-") && name.to_ascii_lowercase().ends_with(".dll") {
                entry_points.push(name);
            }
        }
        for entry_point in entry_points {
            let missing = unresolved_dependencies(&bundle, &entry_point).expect("read the bundle's import tables");
            let unexpected: Vec<&String> = missing
                .iter()
                .filter(|name| !handled.iter().any(|library| library.eq_ignore_ascii_case(name)))
                .collect();
            assert!(
                unexpected.is_empty(),
                "{entry_point} imports libraries that are neither shipped nor installed on first start: {unexpected:?}. \
                 Ship them next to yue-server.exe, or add them to this module so the studio fetches them."
            );
        }
    }

    /// What the studio downloads after install - the HOT-Step tools, the MIDI
    /// transcriber, the trainer, the stem separator, karaoke and the assistant -
    /// imports nothing that is neither beside it, in the engine's folder on the
    /// studio's PATH, nor supplied by Windows and the display driver.
    #[test]
    #[cfg(windows)]
    #[ignore = "reads runtimes downloaded into a data folder: scripts/check-dll-imports.ps1"]
    fn downloaded_runtimes_can_be_loaded() {
        let data = std::path::PathBuf::from(std::env::var("YUE_DLL_DATA").expect("YUE_DLL_DATA names a studio data folder"));
        let engine = std::path::PathBuf::from(std::env::var("YUE_DLL_ENGINE").expect("YUE_DLL_ENGINE names the engine folder"));
        let mut checked = 0;
        let mut problems = Vec::new();
        for area in ["hotstep", "midi/runtime", "training/runtime", "separation/runtime", "karaoke/runtime", "karaoke/models", "assistant/runtime"] {
            let Ok(folders) = std::fs::read_dir(data.join(area)) else { continue };
            for folder in folders.flatten().map(|entry| entry.path()).filter(|path| path.is_dir()) {
                for binary in std::fs::read_dir(&folder).into_iter().flatten().flatten().map(|entry| entry.path()) {
                    let extension = binary.extension().map(|extension| extension.to_string_lossy().to_ascii_lowercase());
                    if !matches!(extension.as_deref(), Some("exe" | "dll")) {
                        continue;
                    }
                    // ONNX Runtime's archive carries its TensorRT provider, which the studio never registers
                    if binary.file_name().is_some_and(|name| name.eq_ignore_ascii_case("onnxruntime_providers_tensorrt.dll")) {
                        continue;
                    }
                    // a tool resolves beside itself, then in the engine's folder on the studio's PATH;
                    // the engine's cuBLAS 13 arrives with its first CUDA start, and a tool on the card finds it on PATH or gets a link beside it
                    let missing: Vec<String> = unresolved_in(&[folder.clone(), engine.clone()], &binary)
                        .expect("read the import tables")
                        .into_iter()
                        .filter(|name| !CUDA13_LIBRARIES.iter().any(|library| library.eq_ignore_ascii_case(name)))
                        .collect();
                    checked += 1;
                    if !missing.is_empty() {
                        problems.push(format!("{}: {missing:?}", binary.display()));
                    }
                }
            }
        }
        assert!(checked > 0, "no downloaded runtime under {}", data.display());
        assert!(problems.is_empty(), "downloaded runtimes import libraries nothing supplies:\n{}", problems.join("\n"));
    }

    /// The import table is the whole basis of the check above; if it cannot be
    /// read, the check silently passes on anything.
    #[test]
    #[cfg(windows)]
    fn imports_are_read_out_of_a_real_binary() {
        let system = Path::new("C:/Windows/System32/notepad.exe");
        if !system.is_file() {
            return;
        }
        let imports = imported_libraries(system).expect("notepad has an import table");
        assert!(!imports.is_empty(), "no imports were read at all");
        assert!(
            imports.iter().all(|name| [".dll", ".drv"].iter().any(|extension| name.to_ascii_lowercase().ends_with(extension))),
            "{imports:?}"
        );
    }

    #[test]
    #[cfg(target_os = "linux")]
    fn on_linux_the_libraries_go_to_one_folder_of_the_data_on_the_library_path() {
        let data = std::env::temp_dir().join(format!("engine-runtime-{}", uuid::Uuid::now_v7()));
        let runtime = EngineRuntime::new(&data.join("engine"), &data);
        let folder = data.join("engine-runtime").join("cuda");
        assert_eq!(runtime.library_dir(), folder);
        let path = std::env::var_os("LD_LIBRARY_PATH").expect("LD_LIBRARY_PATH is set");
        assert!(std::env::split_paths(&path).any(|dir| dir == folder), "{} is on LD_LIBRARY_PATH", folder.display());
        let asset = &LINUX_CUDA13[1];
        assert!(!runtime.downloader().is_installed(asset));
        std::fs::create_dir_all(&folder).unwrap();
        let unpacked: Vec<_> = asset.pick.iter().map(|library| folder.join(library)).collect();
        for library in &unpacked {
            std::fs::write(library, b"x").unwrap();
        }
        crate::install_record::write(&runtime.downloader().record_of(asset), asset.url, "", &unpacked, &runtime.downloader().root()).unwrap();
        assert!(runtime.downloader().is_installed(asset));
        assert!(!runtime.missing(Some(CudaBuild::Cuda13)).iter().any(|missing| missing.id == asset.id));
        std::fs::remove_dir_all(&data).ok();
    }

    /// The libraries count as installed only once they are beside the engine.
    ///
    /// This asserts on the downloader rather than on `is_ready`, because a
    /// machine with the CUDA Toolkit is ready without downloading anything -
    /// which is the point of the PATH check, and would make the test lie about
    /// what it proved.
    #[test]
    #[cfg(not(target_os = "linux"))]
    fn the_libraries_count_as_installed_only_beside_the_engine() {
        let root = std::env::temp_dir().join(format!("engine-runtime-{}", uuid::Uuid::now_v7()));
        let runtime = EngineRuntime::new(&root, &root);
        let asset = cublas_asset(CudaBuild::Cuda13);
        assert!(!runtime.downloader().is_installed(asset));
        assert_eq!(runtime.library_dir(), root);
        // Off CUDA the engine never loads cuBLAS, so nothing is missing.
        assert!(runtime.missing(None).is_empty());

        std::fs::create_dir_all(runtime.library_dir()).unwrap();
        for library in CUDA13_LIBRARIES {
            std::fs::write(runtime.library_dir().join(library), b"x").unwrap();
        }
        assert!(!runtime.downloader().is_installed(asset), "libraries without the record of their pin are not taken for it");
        let unpacked: Vec<_> = CUDA13_LIBRARIES.iter().map(|library| runtime.library_dir().join(library)).collect();
        let record = runtime.downloader().record_of(asset);
        crate::install_record::write(&record, asset.url, "", &unpacked, runtime.downloader().root()).unwrap();
        assert!(!runtime.downloader().is_installed(asset), "a size-only receipt needs member verification");
        let archive_sha = crate::pin_sha::sha256(asset.url).unwrap();
        crate::install_record::write(&record, asset.url, archive_sha, &unpacked, runtime.downloader().root()).unwrap();
        assert!(runtime.downloader().is_installed(asset));
        // The other build asks for its own cuBLAS, unless PATH has it.
        if !CUDA12_LIBRARIES.iter().all(|library| is_on_the_search_path(library)) {
            assert_eq!(runtime.missing(Some(CudaBuild::Cuda12)).len(), 1);
        }
        std::fs::remove_dir_all(&root).ok();
    }
}
