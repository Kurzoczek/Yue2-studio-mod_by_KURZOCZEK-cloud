//! What a download put on disk, and which pin it came from.
//!
//! Beside every archive or file a download fetched lies `<that path>.json`, the
//! record Dub Studio keeps too: the archive's SHA-256, the pinned URL it came
//! from and every file it put down with its size. An asset counts as installed
//! when its record names the URL of today's pin and every recorded file is
//! there at its recorded size, so a runtime of an earlier pin under the same
//! file names is found out instead of being taken for the new one.
//!
//! What was downloaded before records existed has none. A model counts by its
//! presence, as before; a runtime is taken over only when the one file the pin
//! names (`KEY_FILES`) has exactly the pinned size, and is otherwise fetched
//! again.

use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct InstallRecord {
    pub sha256: String,
    pub url: String,
    pub files: Vec<RecordedFile>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct RecordedFile {
    /// Relative to the root the record was written for, with `/`.
    pub path: String,
    pub size: u64,
}

/// For a runtime downloaded before records existed: the file of the pinned
/// archive that tells its version apart, relative to where the archive
/// unpacks or picks into, and that file's size in the archive of the pin.
const KEY_FILES: &[(&str, &str, u64)] = &[
    ("https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-cuda-13.5-x64.zip", "ggml-cuda.dll", 220_921_856),
    ("https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-cuda-12.4-x64.zip", "ggml-cuda.dll", 789_349_376),
    ("https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-vulkan-x64.zip", "ggml-vulkan.dll", 44_831_232),
    ("https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-cpu-x64.zip", "ggml-cpu-haswell.dll", 1_503_232),
    ("https://github.com/timoncool/onnxruntime/releases/download/v1.31.1/onnxruntime-win-x64-1.31.1.zip", "onnxruntime.dll", 17_253_728),
    ("https://github.com/timoncool/onnxruntime/releases/download/v1.32.0/onnxruntime-win-x64-1.32.0.zip", "onnxruntime.dll", 20_602_168),
    ("https://github.com/ggml-org/llama.cpp/releases/download/b12556/cudart-llama-bin-win-cuda-13.5-x64.zip", "cublasLt64_13.dll", 499_102_832),
    ("https://github.com/ggml-org/llama.cpp/releases/download/b11236/cudart-llama-bin-win-cuda-12.4-x64.zip", "cudart64_12.dll", 553_984),
    ("https://developer.download.nvidia.com/compute/cuda/redist/libcublas/windows-x86_64/libcublas-windows-x86_64-13.5.1.27-archive.zip", "cublasLt64_13.dll", 460_301_424),
    ("https://developer.download.nvidia.com/compute/cuda/redist/libcublas/windows-x86_64/libcublas-windows-x86_64-12.9.1.4-archive.zip", "cublasLt64_12.dll", 668_669_952),
    ("https://github.com/Purfview/whisper-standalone-win/releases/download/faster-whisper/Whisper-Faster_r192.3_windows.zip", "whisper-faster.exe", 88_436_526),
    ("https://developer.download.nvidia.com/compute/cuda/redist/libcublas/windows-x86_64/libcublas-windows-x86_64-11.11.3.6-archive.zip", "cublas64_11.dll", 88_668_160),
    ("https://developer.download.nvidia.com/compute/cudnn/redist/cudnn/windows-x86_64/cudnn-windows-x86_64-8.9.7.29_cuda11-archive.zip", "cudnn64_8.dll", 288_296),
    ("https://files.pythonhosted.org/packages/20/e2/fc9a0e985249d873150276d5afb02e39a66817fedbf1a385724393e505ed/nvidia_cublas_cu12-12.9.2.10-py3-none-win_amd64.whl", "cublasLt64_12.dll", 668_673_536),
    // BSRoformer.cpp and transcribe.cpp all-variants archives: the cli/library is one file across the builds, so a build's key is its GPU module (unique by build and version); the processor build, which has none, keeps the cli/library.
    ("https://github.com/timoncool/BSRoformer.cpp/releases/download/studio-0.1.1/BSRoformer-windows-cuda13-x64.zip", "ggml-cuda.dll", 129_091_584),
    ("https://github.com/timoncool/BSRoformer.cpp/releases/download/studio-0.1.1/BSRoformer-windows-cpu-x64.zip", "bs_roformer-cli.exe", 183_808),
    ("https://github.com/timoncool/transcribe.cpp/releases/download/engine-0.2.1/transcribe-windows-cuda13-x64.zip", "ggml-cuda.dll", 140_795_392),
    ("https://github.com/timoncool/transcribe.cpp/releases/download/engine-0.2.1/transcribe-windows-cuda12-x64.zip", "transcribe.dll", 2_052_096),
    ("https://github.com/timoncool/transcribe.cpp/releases/download/engine-0.2.1/transcribe-windows-vulkan-x64.zip", "ggml-vulkan.dll", 45_308_928),
    ("https://github.com/timoncool/transcribe.cpp/releases/download/engine-0.2.1/transcribe-windows-cpu-x64.zip", "transcribe.dll", 2_054_656),
    // Linux and macOS: the regular file a tar's links point to, under its own versioned name
    ("https://github.com/timoncool/BSRoformer.cpp/releases/download/studio-0.1.1/BSRoformer-linux-cuda13-x64.tar.gz", "libggml-cuda.so", 141_711_088),
    ("https://github.com/timoncool/BSRoformer.cpp/releases/download/studio-0.1.1/BSRoformer-linux-cpu-x64.tar.gz", "bs_roformer-cli", 295_632),
];

/// The record of the archive or file at `path`.
pub fn record_path(path: &Path) -> PathBuf {
    let mut name = path.as_os_str().to_owned();
    name.push(".json");
    PathBuf::from(name)
}

pub fn read(record: &Path) -> Option<InstallRecord> {
    let text = fs::read_to_string(record).ok()?;
    match serde_json::from_str(&text) {
        Ok(parsed) => Some(parsed),
        Err(error) => {
            eprintln!("[ERROR] the install record {} is unreadable ({error}); its download counts as not installed", record.display());
            None
        }
    }
}

fn legacy_ort_pin(record: &InstallRecord, url: &str) -> bool {
    let Some(asset) = url.strip_prefix("https://github.com/timoncool/onnxruntime/releases/download/") else { return false };
    record.url.strip_prefix("https://github.com/microsoft/onnxruntime/releases/download/") == Some(asset)
        && crate::pin_sha::sha256(url).is_some_and(|hash| hash == record.sha256)
}

/// The training and MIDI tools share a sibling directory named hotstep. Older
/// records stored its absolute path, which still points to the previous Studio
/// after moving or copying a portable installation.
fn shared_tools(root: &Path) -> Option<PathBuf> {
    // the studio's own Audio to MIDI folder may be kept elsewhere (Debian build), and so may HOT-Step's
    if let Some(data_root) = crate::studio_data_root() {
        for name in ["midi", "training"] {
            if root == crate::model_storage::folder(&data_root, name) {
                return Some(crate::model_storage::folder(&data_root, "hotstep"));
            }
        }
    }
    match root.file_name()?.to_str()? {
        "training" | "midi" => Some(root.parent()?.join("hotstep")),
        _ => None,
    }
}

fn recorded_path(root: &Path, stored: &str) -> Option<PathBuf> {
    use std::path::Component;
    let path = Path::new(stored);
    let plain = |path: &Path| !path.as_os_str().is_empty() && path.components().all(|part| matches!(part, Component::Normal(_)));
    if plain(path) { return Some(root.join(path)); }
    let shared = shared_tools(root)?;
    let suffix = if path.is_absolute() {
        let legacy = path.ancestors().find(|ancestor| ancestor.file_name().is_some_and(|name| name == "hotstep"))?;
        path.strip_prefix(legacy).ok()?
    } else {
        path.strip_prefix("../hotstep").ok()?
    };
    plain(suffix).then(|| shared.join(suffix))
}

/// Whether the record at `record` says `url` was installed and every file it
/// put under `root` is there at its size. None when there is no record; false
/// while an install is under way or was cut off (`begin`), record or not.
pub fn matches(record: &Path, url: &str, root: &Path) -> Option<bool> {
    if installing_mark(record).exists() {
        return Some(false);
    }
    let parsed = read(record)?;
    Some(
        (parsed.url == url || legacy_ort_pin(&parsed, url))
            && !parsed.files.is_empty()
            && parsed.files.iter().all(|file| recorded_path(root, &file.path).and_then(|path| fs::metadata(path).ok()).is_some_and(|meta| meta.is_file() && meta.len() == file.size)),
    )
}

/// The mark beside a record that its download is being installed.
fn installing_mark(record: &Path) -> PathBuf {
    record.with_extension("json.installing")
}

/// Whether the download recorded at `record` is being installed, or its install was cut off.
pub fn under_way(record: &Path) -> bool {
    installing_mark(record).exists()
}

/// Marks the download recorded at `record` as being installed, before any of
/// its files is put down: until `write` replaces the mark with the record, it
/// counts as not installed, and a download from before records is not taken
/// over from the files unpacked so far - also after a crash in between.
pub fn begin(record: &Path) -> Result<()> {
    let mark = installing_mark(record);
    if let Some(directory) = mark.parent() {
        fs::create_dir_all(directory).with_context(|| format!("create {}", directory.display()))?;
    }
    fs::write(&mark, b"").with_context(|| format!("write {}", mark.display()))
}

/// The key file of a pinned runtime archive and its size, when the pin names one.
pub fn key_file(url: &str) -> Option<(&'static str, u64)> {
    KEY_FILES.iter().find(|(pinned, _, _)| *pinned == url).map(|(_, file, size)| (*file, *size))
}

/// Writes the record of `url` at `record`: the archive's hash and the files it
/// put down, relative to `root`. The record lands whole (a temporary file
/// renamed over it), and then the mark of the install under way goes.
pub fn write(record: &Path, url: &str, sha256: &str, files: &[PathBuf], root: &Path) -> Result<()> {
    let files = files
        .iter()
        .map(|path| {
            let size = fs::metadata(path).with_context(|| format!("measure {}", path.display()))?.len();
            let relative = if let Ok(relative) = path.strip_prefix(root) {
                relative.to_path_buf()
            } else {
                let shared = shared_tools(root).context("installed file is outside its component directory")?;
                Path::new("../hotstep").join(path.strip_prefix(shared).context("installed file is outside shared HOT-Step tools")?)
            };
            let relative = relative.to_string_lossy().replace('\\', "/");
            Ok(RecordedFile { path: relative, size })
        })
        .collect::<Result<Vec<_>>>()?;
    let body = serde_json::to_vec_pretty(&InstallRecord { sha256: sha256.to_string(), url: url.to_string(), files })?;
    let partial = record.with_extension("json.tmp");
    fs::write(&partial, body).with_context(|| format!("write {}", partial.display()))?;
    fs::rename(&partial, record).with_context(|| format!("write {}", record.display()))?;
    remove_if_there(&installing_mark(record))
}

fn remove_if_there(path: &Path) -> Result<()> {
    match fs::remove_file(path) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error).with_context(|| format!("remove {}", path.display())),
    }
}

/// Deletes the files an earlier pin's record lists under `root` but `kept` (the file today's download replaced in
/// place), and that record; the mark of today's install stays. A file a running program holds is moved aside.
pub fn remove_earlier(record: &Path, root: &Path, kept: &Path) -> Result<()> {
    if let Some(parsed) = read(record) {
        for file in &parsed.files {
            let Some(path) = recorded_path(root, &file.path) else { continue };
            if path != kept {
                if let Err(error) = remove_if_there(&path) {
                    set_aside(&path).with_context(|| format!("{error:#}"))?;
                }
            }
        }
    }
    remove_if_there(record)
}

/// The mark in the name of a file moved aside by `set_aside`.
const ASIDE: &str = ".stale-";

/// Moves `path` aside under a name of its own beside it, for a file a running program holds, which Windows lets be
/// renamed but not removed or replaced; `sweep_aside` removes it at a later start.
pub fn set_aside(path: &Path) -> Result<PathBuf> {
    let name = path.file_name().map(|name| name.to_string_lossy().into_owned()).unwrap_or_default();
    let aside = path.with_file_name(format!("{name}{ASIDE}{}", uuid::Uuid::now_v7().simple()));
    // known before it exists, so a sweep running beside it never sees it unknown
    SET_ASIDE_NOW.lock().unwrap_or_else(|poisoned| poisoned.into_inner()).insert(aside.clone());
    if let Err(error) = fs::rename(path, &aside) {
        SET_ASIDE_NOW.lock().unwrap_or_else(|poisoned| poisoned.into_inner()).remove(&aside);
        return Err(error).with_context(|| format!("move {} aside", path.display()));
    }
    eprintln!("{} is held by a running program and was moved aside as {}; it is removed at the next start", path.display(), aside.display());
    Ok(aside)
}

/// What `set_aside` moved in this run: the sweep of this run's start leaves it, as a failed replace may put it back.
static SET_ASIDE_NOW: std::sync::Mutex<std::collections::BTreeSet<PathBuf>> = std::sync::Mutex::new(std::collections::BTreeSet::new());

/// Whether a file name is one `set_aside` gives: the name, `ASIDE`, then a UUID's 32 hex digits at the end.
fn set_aside_name(name: &str) -> bool {
    name.rsplit_once(ASIDE).is_some_and(|(before, id)| !before.is_empty() && id.len() == 32 && id.bytes().all(|byte| byte.is_ascii_hexdigit()))
}

/// Removes what `set_aside` left under `root` in an earlier run, passing by the folders of the person's work.
pub fn sweep_aside(root: &Path) {
    // midi and karaoke hold downloaded runtimes beside the person's work, so they are walked; their work is safe
    // because only set_aside's own names are removed
    const WORK: [&str; 6] = ["media", "processing", "videos", "skins", "logs", "adapters"];
    let Ok(entries) = fs::read_dir(root) else { return };
    for entry in entries.flatten() {
        let Ok(kind) = entry.file_type() else { continue };
        let path = entry.path();
        let name = entry.file_name().to_string_lossy().into_owned();
        if kind.is_dir() {
            if !WORK.contains(&name.as_str()) {
                sweep_aside(&path);
            }
        } else if kind.is_file() && set_aside_name(&name) && !SET_ASIDE_NOW.lock().unwrap_or_else(|poisoned| poisoned.into_inner()).contains(&path) {
            match fs::remove_file(&path) {
                Ok(()) => eprintln!("removed {}, moved aside by an earlier update", path.display()),
                Err(error) => eprintln!("[ERROR] {} was not removed: {error}", path.display()),
            }
        }
    }
}

/// The SHA-256 of a file, as lower-case hex.
pub fn sha256_of(path: &Path) -> Result<String> {
    use sha2::{Digest, Sha256};
    let mut file = fs::File::open(path).with_context(|| format!("open {}", path.display()))?;
    let mut hasher = Sha256::new();
    let mut buffer = vec![0u8; 1 << 20];
    loop {
        let read = file.read(&mut buffer).with_context(|| format!("read {}", path.display()))?;
        if read == 0 {
            break;
        }
        hasher.update(&buffer[..read]);
    }
    Ok(hasher.finalize().iter().map(|byte| format!("{byte:02x}")).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shared_tools_records_follow_the_portable_and_leave_the_original_alone() {
        let disk = tempfile::tempdir().unwrap();
        let old = disk.path().join("Studio 4");
        let new = disk.path().join("Studio 5");
        for base in [&old, &new] {
            fs::create_dir_all(base.join("training")).unwrap();
            fs::create_dir_all(base.join("hotstep/build")).unwrap();
            fs::write(base.join("hotstep/build/tool"), b"tool").unwrap();
        }
        let old_file = old.join("hotstep/build/tool");
        let record = new.join("training/package.json");
        let root = new.join("training");
        let new_file = new.join("hotstep/build/tool");
        write(&record, "url", "", std::slice::from_ref(&new_file), &root).unwrap();
        let mut saved = read(&record).unwrap();
        assert_eq!(saved.files[0].path, "../hotstep/build/tool");
        assert_eq!(matches(&record, "url", &root), Some(true));
        saved.files[0].path = old_file.to_string_lossy().to_string();
        fs::write(&record, serde_json::to_vec(&saved).unwrap()).unwrap();
        assert_eq!(matches(&record, "url", &root), Some(true));
        fs::write(&new_file, b"changed").unwrap();
        assert_eq!(matches(&record, "url", &root), Some(false));
        remove_earlier(&record, &root, &root.join("package.zip")).unwrap();
        assert!(!new_file.exists());
        assert_eq!(fs::read(old_file).unwrap(), b"tool");
    }

    fn scratch(name: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!("install-record-{name}-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[test]
    fn a_record_of_another_pin_or_a_changed_file_does_not_match() {
        let root = scratch("match");
        let library = root.join("runtime").join("lib.dll");
        fs::create_dir_all(library.parent().unwrap()).unwrap();
        fs::write(&library, b"twelve bytes").unwrap();
        let record = record_path(&root.join("runtime.zip"));
        assert_eq!(matches(&record, "https://x/v2.zip", &root), None);
        write(&record, "https://x/v2.zip", "ab", &[library.clone()], &root).unwrap();
        assert_eq!(matches(&record, "https://x/v2.zip", &root), Some(true));
        assert_eq!(matches(&record, "https://x/v3.zip", &root), Some(false));
        fs::write(&library, b"other").unwrap();
        assert_eq!(matches(&record, "https://x/v2.zip", &root), Some(false));
        remove_earlier(&record, &root, &root.join("today.dll")).unwrap();
        assert!(!library.exists() && !record.exists());
        let _ = fs::remove_dir_all(&root);
    }

    /// A matching record does not count while the mark of an install under way
    /// is beside it, and writing the record takes the mark away.
    #[test]
    fn an_install_under_way_does_not_match_until_its_record_is_written() {
        let root = scratch("under-way");
        let file = root.join("tool.dll");
        fs::write(&file, b"tool").unwrap();
        let record = record_path(&root.join("tool.zip"));
        write(&record, "https://example.invalid/tool.zip", "", &[file.clone()], &root).unwrap();
        assert_eq!(matches(&record, "https://example.invalid/tool.zip", &root), Some(true));
        begin(&record).unwrap();
        assert_eq!(matches(&record, "https://example.invalid/tool.zip", &root), Some(false));
        write(&record, "https://example.invalid/tool.zip", "abc", &[file], &root).unwrap();
        assert_eq!(matches(&record, "https://example.invalid/tool.zip", &root), Some(true));
        assert!(!installing_mark(&record).exists() && !record.with_extension("json.tmp").exists());
        // today's download replaced the file in place: the earlier record goes, the mark of today's install stays
        begin(&record).unwrap();
        remove_earlier(&record, &root, &root.join("tool.dll")).unwrap();
        assert!(installing_mark(&record).exists() && !record.exists() && root.join("tool.dll").exists());
        assert_eq!(matches(&record, "https://example.invalid/tool.zip", &root), Some(false));
        fs::remove_dir_all(&root).ok();
    }

    /// Every unpacked runtime the Windows studio pins names the file that tells
    /// its version apart: without it a runtime downloaded before records - every
    /// install of 3.7.0 - would be fetched again even at today's pin.
    #[cfg(windows)]
    #[test]
    fn every_pinned_windows_archive_names_its_key_file() {
        let archive = |url: &str| url.ends_with(".zip") || url.ends_with(".nupkg");
        let mut missing: Vec<&str> = Vec::new();
        let downloads = crate::lyrics_sync::ASSETS
            .iter()
            .chain(crate::engine_runtime::ASSETS)
            // the builds a studio downloaded before records: CUDA 13 and the processor
            .chain([crate::separation::RoformerBuild::Cuda13, crate::separation::RoformerBuild::Cpu].into_iter().filter_map(crate::separation::roformer_asset));
        for asset in downloads.filter(|asset| asset.kind == crate::downloads::AssetKind::Runtime && archive(asset.url)) {
            if key_file(asset.url).is_none() && crate::pin_sha::runtime_libraries(asset.url).is_empty() {
                missing.push(asset.url);
            }
        }
        for asset in crate::assistant_runtime::ASSETS.iter().filter(|asset| asset.kind == crate::assistant_runtime::AssetKind::Runtime && archive(asset.url)) {
            if key_file(asset.url).is_none() {
                missing.push(asset.url);
            }
        }
        assert!(missing.is_empty(), "pinned archives without a key file: {missing:#?}");
    }

    /// A Windows CUDA 13 install of b12248 cannot be adopted as b12556 without a record.
    #[test]
    fn the_previous_llama_runtime_without_a_record_is_not_taken_for_todays_pin() {
        let (file, size) = key_file("https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-cuda-13.5-x64.zip").unwrap();
        assert_eq!(file, "ggml-cuda.dll");
        assert_ne!(size, 160_740_864, "b12248's ggml-cuda.dll");
    }

    /// No two pinned archives share a key: a key file at its size names one build, so another build unpacked in its
    /// place is not taken for it.
    #[test]
    fn the_keys_of_different_archives_differ() {
        for (index, (url, file, size)) in KEY_FILES.iter().enumerate() {
            for (other, other_file, other_size) in &KEY_FILES[index + 1..] {
                assert!(url != other, "{url} is listed twice");
                assert!((file, size) != (other_file, other_size), "{url} and {other} share the key {file} of {size} bytes");
            }
        }
    }

    #[test]
    fn a_file_moved_aside_is_gone_at_the_next_start_and_the_work_is_left() {
        let root = scratch("aside");
        let runtime = root.join("karaoke").join("runtime");
        fs::create_dir_all(&runtime).unwrap();
        fs::create_dir_all(root.join("media")).unwrap();
        let held = runtime.join("engine.dll");
        fs::write(&held, b"old").unwrap();
        let aside = set_aside(&held).unwrap();
        assert!(!held.exists() && aside.exists() && aside.parent() == held.parent());
        sweep_aside(&root);
        assert!(aside.exists(), "what this run moved aside stays, a failed replace may put it back");
        // as a later start sees it
        SET_ASIDE_NOW.lock().unwrap().remove(&aside);
        let song = root.join("media").join(format!("song.flac{ASIDE}{}", uuid::Uuid::now_v7().simple()));
        fs::write(&song, b"song").unwrap();
        let dataset = root.join("hotstep").join("datasets").join("d1");
        fs::create_dir_all(&dataset).unwrap();
        let named_alike = dataset.join("0-My.stale-mix.wav");
        fs::write(&named_alike, b"song").unwrap();
        sweep_aside(&root);
        assert!(!aside.exists(), "removed at the next start");
        assert!(song.exists(), "the person's work is not swept, even under a name set_aside gives");
        assert!(named_alike.exists(), "only the names set_aside gives are swept");
        fs::remove_dir_all(&root).ok();
    }

    #[test]
    fn legacy_ort_record_requires_the_same_pinned_archive() {
        let root = scratch("ort-mirror-record");
        let file = root.join("lib.dll");
        fs::write(&file, b"lib").unwrap();
        let record = record_path(&root.join("runtime.zip"));
        let url = "https://github.com/timoncool/onnxruntime/releases/download/v1.31.1/onnxruntime-win-x64-1.31.1.zip";
        let old = url.replace("/timoncool/", "/microsoft/");
        for (source, hash, accepted) in [(old.clone(), crate::pin_sha::sha256(url).unwrap(), true), (old.clone(), "wrong", false), (old.replace("1.31.1", "1.28.2"), crate::pin_sha::sha256(url).unwrap(), false)] {
            write(&record, &source, hash, std::slice::from_ref(&file), &root).unwrap();
            assert_eq!(matches(&record, url, &root), Some(accepted));
        }
        fs::remove_dir_all(root).unwrap();
    }
}
