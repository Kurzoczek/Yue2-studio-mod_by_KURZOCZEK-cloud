//! Training adapters on the user's own songs, in a sidecar process.
//!
//! The trainer (`music-train`) and its weights are optional: nothing is
//! downloaded until the user asks on the training page. Datasets are engine
//! neutral - a folder of 48 kHz WAV files and a `dataset.json` with each song's
//! style and lyrics - so another studio of the family opens the same folder.
//! Runs are the engine's: the recipe, the stages and the checkpoints come from
//! the engine crate, and a finished checkpoint becomes an ordinary adapter.

use std::fs;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, OnceLock};

use anyhow::{bail, Context, Result};
use music_engine::yue_train::{self, TrainingStep};
use serde::{Deserialize, Serialize};
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::sync::RwLock;

use crate::downloads::{Asset, AssetKind, Downloader};
use crate::unix_millis;

/// The downloader scope the training page reads its progress under.
pub const SCOPE: &str = "training";
/// The optional listening pack downloads under a scope of its own.
pub const LISTEN_SCOPE: &str = "listen";

/// One song of a dataset.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DatasetItem {
    pub id: String,
    pub title: String,
    /// Who sings it, for finding its lyrics; from the file's tags or name.
    #[serde(default)]
    pub artist: String,
    /// Where the lyrics came from: a lyrics database's name, "recognised",
    /// or empty when they were written or came with the file.
    #[serde(default)]
    pub lyrics_source: String,
    /// The style sentence the model is prompted with.
    #[serde(default)]
    pub style: String,
    #[serde(default)]
    pub lyrics: String,
    #[serde(default)]
    pub instrumental: bool,
    /// The WAV file inside the dataset's `audio` folder.
    pub file: String,
    pub seconds: f64,
    /// Where it came from: a library song id or an imported file name.
    #[serde(default)]
    pub source: String,
    /// Where the lyrics stand in preparation; a stopped job picks up here.
    pub lyrics_state: LyricsState,
    /// Where the style stands in preparation.
    pub style_state: StyleState,
    /// What the listening model heard, kept until the style is written from it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub heard: Option<HeardNote>,
}

/// Where a song's lyrics stand.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LyricsState {
    /// To be looked up or recognised.
    Wanted,
    /// Found or recognised; still to be laid out in sections.
    Found,
    /// Laid out, written by hand, or an instrumental.
    Done,
}

/// Where a song's style stands.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum StyleState {
    /// To be listened to.
    Wanted,
    /// Heard; the style sentence is still to be written from it.
    Heard,
    /// Written, by the assistant or by hand.
    Done,
}

/// What the listening model heard in a song.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct HeardNote {
    pub genre: String,
    pub caption: String,
    pub bpm: u32,
}

/// A trigger word made from a dataset's name: the name in Latin letters,
/// each word's vowels after its first letter left out - "Нейромонах Феофан"
/// becomes "nrmnkhffn", a word no prompt has by chance.
pub fn trigger_from(name: &str) -> String {
    const CYRILLIC: [(char, &str); 33] = [
        ('а', "a"), ('б', "b"), ('в', "v"), ('г', "g"), ('д', "d"), ('е', "e"), ('ё', "e"), ('ж', "zh"), ('з', "z"), ('и', "i"), ('й', "y"),
        ('к', "k"), ('л', "l"), ('м', "m"), ('н', "n"), ('о', "o"), ('п', "p"), ('р', "r"), ('с', "s"), ('т', "t"), ('у', "u"), ('ф', "f"),
        ('х', "kh"), ('ц', "ts"), ('ч', "ch"), ('ш', "sh"), ('щ', "sch"), ('ъ', ""), ('ы', "y"), ('ь', ""), ('э', "e"), ('ю', "yu"), ('я', "ya"),
    ];
    let latin: String = name
        .to_lowercase()
        .chars()
        .map(|c| match CYRILLIC.iter().find(|(letter, _)| *letter == c) {
            Some((_, spelled)) => spelled.to_string(),
            None if c.is_ascii_alphanumeric() => c.to_string(),
            None => " ".to_string(),
        })
        .collect();
    let trigger: String = latin
        .split_whitespace()
        .map(|word| {
            let mut letters = word.chars();
            let first = letters.next().map(String::from).unwrap_or_default();
            first + &letters.filter(|c| !"aeiouy".contains(*c)).collect::<String>()
        })
        .collect::<String>()
        .chars()
        .take(12)
        .collect();
    if trigger.len() >= 3 {
        return trigger;
    }
    // a name in another script, or too short: a stable hash of it keeps the
    // word rare and different for every name
    let hash = name.bytes().fold(0x811c_9dc5u32, |hash, byte| (hash ^ u32::from(byte)).wrapping_mul(0x0100_0193));
    format!("lora{trigger}{:06x}", hash & 0x00ff_ffff)
}

/// Lyrics laid out in sections carry a heading line such as "[Verse 1]".
pub fn has_sections(lyrics: &str) -> bool {
    lyrics.lines().map(str::trim).any(|line| line.len() > 2 && line.starts_with('[') && line.ends_with(']'))
}

/// Where lyrics stand judged by the text alone, for a song that comes with
/// them or a dataset written before the states were kept.
pub fn lyrics_state_of(lyrics: &str, instrumental: bool) -> LyricsState {
    if instrumental || has_sections(lyrics) {
        LyricsState::Done
    } else if lyrics.trim().is_empty() {
        LyricsState::Wanted
    } else {
        LyricsState::Found
    }
}

pub fn style_state_of(style: &str) -> StyleState {
    if style.trim().is_empty() { StyleState::Wanted } else { StyleState::Done }
}

/// Fills in what a dataset written by an older studio lacks: its songs get
/// the states their text shows, and the dataset a trigger word from its name.
fn settle_states(dataset: &mut serde_json::Value) {
    let named = dataset.get("name").and_then(serde_json::Value::as_str).map(trigger_from);
    if let (Some(trigger), Some(fields)) = (named, dataset.as_object_mut()) {
        let chosen = fields.get("trigger_chosen").and_then(serde_json::Value::as_bool).unwrap_or(false);
        if !chosen && fields.get("trigger").and_then(serde_json::Value::as_str).is_none_or(|word| word.trim().is_empty()) {
            fields.insert("trigger".into(), trigger.into());
        }
    }
    let Some(items) = dataset.get_mut("items").and_then(serde_json::Value::as_array_mut) else { return };
    for item in items {
        let Some(item) = item.as_object_mut() else { continue };
        let text = |field: &str| item.get(field).and_then(serde_json::Value::as_str).unwrap_or_default().to_string();
        let (lyrics, style) = (text("lyrics"), text("style"));
        let instrumental = item.get("instrumental").and_then(serde_json::Value::as_bool).unwrap_or(false);
        if !item.contains_key("lyrics_state") {
            item.insert("lyrics_state".into(), serde_json::to_value(lyrics_state_of(&lyrics, instrumental)).expect("a state"));
        }
        if !item.contains_key("style_state") {
            item.insert("style_state".into(), serde_json::to_value(style_state_of(&style)).expect("a state"));
        }
    }
}

/// A dataset file, songs written before the states were kept given theirs.
fn read_dataset(path: &Path) -> Result<Dataset> {
    let mut dataset: serde_json::Value = serde_json::from_slice(&std::fs::read(path).with_context(|| format!("read {}", path.display()))?)
        .with_context(|| format!("{} is not JSON", path.display()))?;
    settle_states(&mut dataset);
    serde_json::from_value(dataset).with_context(|| format!("{} is not a dataset", path.display()))
}

/// A set of songs to train on, independent of any engine.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Dataset {
    #[serde(default = "dataset_format")]
    pub format: String,
    pub id: String,
    pub name: String,
    /// A rare word the adapter learns to answer to.
    #[serde(default)]
    pub trigger: String,
    /// The user set the trigger, an empty one included; a word made from the
    /// name fills it only while this is false.
    #[serde(default)]
    pub trigger_chosen: bool,
    pub created_at: String,
    #[serde(default)]
    pub items: Vec<DatasetItem>,
}

fn dataset_format() -> String {
    "music-dataset-v1".into()
}

pub use yue_train::Recipe;

/// Separates the vocals of a song for lyric timing; the studio's separator.
pub trait VocalSeparator: Send + Sync {
    /// Writes the vocals of `mix` to `out` as WAV.
    fn separate(&self, mix: &Path, out: &Path) -> Result<()>;
}

/// The studio-side stage that runs before the trainer's.
const VOCALS_STAGE: &str = "vocals";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RunStatus {
    Running,
    Done,
    Failed,
    Cancelled,
    /// The studio closed while it ran.
    Interrupted,
}

/// The device of the last "[Load] <part> backend: <device>" line a trainer
/// wrote. The "DiT" part is not one: the trainer keeps that copy of the base
/// in memory and computes on the card, and does not start without a card.
fn trainer_device(log: &str) -> Option<String> {
    log.lines().rev().find_map(|line| {
        let rest = line.trim().strip_prefix("[Load] ")?;
        let (part, device) = rest.split_once(" backend: ")?;
        if part == "DiT" {
            return None;
        }
        Some(device.split_whitespace().next()?.to_string())
    })
}

/// A training run as it is kept on disk and shown on the page.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Run {
    pub id: String,
    pub engine: String,
    pub dataset_id: String,
    pub dataset_name: String,
    pub name: String,
    pub trigger: String,
    pub recipe: Recipe,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub trainer: Option<TrainerIdentity>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub training_base: Option<TrainingBaseIdentity>,
    pub status: RunStatus,
    /// The stage working now, or the one that failed.
    pub stage: Option<String>,
    pub stages: Vec<String>,
    #[serde(default)]
    pub steps: Vec<TrainingStepRecord>,
    #[serde(default)]
    pub error: Option<String>,
    pub created_at: String,
    #[serde(default)]
    pub finished_at: Option<String>,
    /// Checkpoints already added to the adapter library, by step.
    #[serde(default)]
    pub installed: Vec<u32>,
    /// Each time the run was trained further, oldest first.
    #[serde(default)]
    pub continuations: Vec<Continuation>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub output_adapter: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hotstep_sa3_settings: Option<crate::hotstep_sa3_training::Settings>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hotstep_heartmula_settings: Option<crate::hotstep_sa3_training::Settings>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rvc_burn_settings: Option<crate::rvc_burn::Settings>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rvc_voice_id: Option<String>,
}

pub(super) const BUILTIN_TRAINER: &str = "music-train-bundled";
const YUE2_STATE_FORMAT: &str = "yue2-joint-state-v1";
const PREVIOUS_BUILTIN_VERSION: &str = "75923e70036e3f36653e4d9f4d4e8c5e23c73dfb";
const CURRENT_BUILTIN_VERSION: &str = "479cbeb8f5e7de98f85f2ac8c3da305cb73839e8";
const STOCK_BASE: &str = "stock";
const OWN_BASE_PREFIX: &str = "own:";
pub(super) const BASE_SCOPE: &str = "training-base";
const RUACH_TW_BASE: &str = "ruach-rs-tw-2.0x0.75";
const RUACH_FW_BASE: &str = "ruach-rs-fw-2.4x0.75";

static ALTERNATE_BASES: [(Asset, &str); 2] = [
    (Asset {
        id: RUACH_TW_BASE,
        label: "Ruach RS-TW 2.0×0.75",
        kind: AssetKind::Model,
        url: "https://huggingface.co/goldhub/YuE2-RS-Finetunes/resolve/8ba3e2ce05ef2d8b712a832a1c7eb016e39931dd/comfyui/yue2_3b_RS-TW-2.0x0.75_int8_convrot.safetensors",
        relative_path: "models/yue2_3b_RS-TW-2.0x0.75_int8_convrot.safetensors",
        bytes: 3_960_939_304,
        unzip_into: None,
        marker: "",
        pick: &[],
        vram_gb: None,
        note: "CC BY-NC-SA 4.0 · INT8 ConvRot",
    }, "df6fe26462320cae9378520f163b0ce73292252ac9059dc24a530d95ee1782ab"),
    (Asset {
        id: RUACH_FW_BASE,
        label: "Ruach RS-FW 2.4×0.75",
        kind: AssetKind::Model,
        url: "https://huggingface.co/goldhub/YuE2-RS-Finetunes/resolve/8ba3e2ce05ef2d8b712a832a1c7eb016e39931dd/comfyui/yue2_3b_RS-FW-2.4x0.75_int8_convrot.safetensors",
        relative_path: "models/yue2_3b_RS-FW-2.4x0.75_int8_convrot.safetensors",
        bytes: 3_960_939_152,
        unzip_into: None,
        marker: "",
        pick: &[],
        vram_gb: None,
        note: "CC BY-NC-SA 4.0 · INT8 ConvRot",
    }, "4dc75ef96b09cb14e652ebf8b0e2a4afb143ac5d60bec13ae2003d5ff43016c2"),
];

pub(super) fn base_asset_sha(url: &str) -> Option<&'static str> {
    ALTERNATE_BASES.iter().find(|(asset, _)| asset.url == url).map(|(_, sha)| *sha)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TrainingBaseIdentity {
    pub id: String,
    pub checkpoint_sha256: String,
    pub companion_sha256: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub own_backbone_sha256: Option<String>,
}

impl TrainingBaseIdentity {
    pub(super) fn matching_backbone(&self, sha: &str) -> bool {
        if let Some(own) = &self.own_backbone_sha256 {
            return own == sha;
        }
        match self.id.as_str() {
            STOCK_BASE => crate::model_manager::stock_backbone_sha(sha),
            RUACH_TW_BASE => matches!(sha,
                "1795d9efd601a43b87c30ca16f0d31f96e66d60b5a96dafb6d640819855b2d86" |
                "fed75c6ffe7c65e30e2a11b4002c7599d214cf514c9cd40db15456e8531da701" |
                "24d965f6f63656b55e5ff6f004627235b708293e2af9058feb162448197f83c4"),
            RUACH_FW_BASE => matches!(sha,
                "18d109738b7d1254481926ffc183f3af269ff521ee207347930421a7a94c70c1" |
                "a7fd39079bdbae1b0b3960c63f8684585d33da60d06b27c0110ec5608c155487" |
                "25793826e9f28c8894b4f7c7f6d3ed54256cf1fcc1966030ac7b1b6a5918baf3"),
            _ => false,
        }
    }
}

/// The active GGUF can be several GB. A stable selection is fingerprinted once.
pub(super) fn generation_model_sha(path: &Path) -> Result<String> {
    type Entry = (PathBuf, u64, std::time::SystemTime, String);
    static CACHE: OnceLock<Mutex<Vec<Entry>>> = OnceLock::new();
    let cache = CACHE.get_or_init(|| Mutex::new(Vec::new()));
    let metadata = fs::metadata(path)?;
    let modified = metadata.modified()?;
    {
        let entries = cache.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        if let Some((_, _, _, sha)) = entries.iter().find(|(file, len, time, _)| file == path && *len == metadata.len() && *time == modified) {
            return Ok(sha.clone());
        }
    }
    let sha = crate::install_record::sha256_of(path)?;
    let after = fs::metadata(path)?;
    if metadata.len() != after.len() || modified != after.modified()? {
        bail!("A selected YuE2 model changed while it was being checked.");
    }
    let mut entries = cache.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    entries.retain(|(file, ..)| file != path);
    if entries.len() >= 4 {
        entries.remove(0);
    }
    entries.push((path.to_owned(), metadata.len(), modified, sha.clone()));
    Ok(sha)
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrainerIdentity {
    id: String,
    version: String,
    generation: Option<String>,
    optimizer_format: String,
    weights_revision: String,
}

impl TrainerIdentity {
    fn can_resume(&self, saved: &Self) -> bool {
        if self.id != saved.id || self.generation != saved.generation {
            return false;
        }
        self.version == saved.version
            || (self.id == BUILTIN_TRAINER
                && self.generation.is_none()
                && saved.version == PREVIOUS_BUILTIN_VERSION
                && self.version == CURRENT_BUILTIN_VERSION)
    }
}

/// The run trained on from the checkpoint at `from` up to `to` steps.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Continuation {
    pub from: u32,
    pub to: u32,
    pub at: String,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct TrainingStepRecord {
    pub step: u32,
    pub loss: f64,
    #[serde(default)]
    pub ar_kl: Option<f64>,
    #[serde(default)]
    pub step_ms: Option<f64>,
}

impl From<TrainingStep> for TrainingStepRecord {
    fn from(step: TrainingStep) -> Self {
        Self { step: step.step, loss: step.loss, ar_kl: Some(step.ar_kl), step_ms: step.step_ms }
    }
}

/// What the studio does with the graphics card around a run: `take` frees it
/// once the run is accepted, before the first stage, and `give_back` runs when
/// the run has ended however it ended.
pub struct CardHooks {
    pub take: Box<dyn FnOnce() -> futures_util::future::BoxFuture<'static, ()> + Send>,
    pub give_back: Box<dyn FnOnce() -> futures_util::future::BoxFuture<'static, ()> + Send>,
}

pub struct Training {
    root: PathBuf,
    engine: String,
    downloader: Downloader,
    /// The run in progress, with its trainer process to stop.
    active: RwLock<Option<Active>>,
    /// Held over each read-change-write of a `run.json` or `dataset.json`, so
    /// two edits never write over each other.
    edits: std::sync::Mutex<()>,
    /// Told how each run ended: done, or the failure's reason and whether it was stopped.
    ended: std::sync::OnceLock<RunEnded>,
    /// The parts of the steps of the training stage going now.
    step_stages: std::sync::Mutex<yue_train::StepStages>,
    /// The trainer said its card has no BF16 for the ConvRot8 layers and took the F32 path, several times slower.
    f32_path: std::sync::atomic::AtomicBool,
}

/// How a training run ended, for whoever counts finished work: `Ok` done, `Err` the reason, and whether it was stopped.
pub type RunEnded = Box<dyn Fn(std::result::Result<(), String>, bool) + Send + Sync>;

struct Active {
    run_id: String,
    cancel: Arc<tokio::sync::Notify>,
}

/// The trainer build this studio uses, shared by every engine of the family.
#[derive(Deserialize)]
struct TrainerSource {
    commit: String,
    shipped_as: String,
    release_tag: String,
    asset: String,
    /// Size of the released archive.
    bytes: u64,
    /// The captioner's archive can have its own immutable filename.
    caption_asset: String,
    /// Size of the captioner's archive in the same release.
    caption_bytes: u64,
    cuda12_backend_tag: String,
    cuda12_backend_asset: String,
    cuda12_backend_bytes: u64,
}

fn trainer_source() -> &'static TrainerSource {
    static SOURCE: OnceLock<TrainerSource> = OnceLock::new();
    SOURCE.get_or_init(|| serde_json::from_str(include_str!("../../../engines/music-train-source.json")).expect("engines/music-train-source.json is valid"))
}

/// Where HOT-Step's tools unpack: the trainer, the captioner and the MIDI
/// transcriber are one build of one commit and share its ggml, so the training
/// pack and Audio to MIDI download it once into the same folder.
pub fn tools_root(data_root: &Path) -> PathBuf {
    crate::model_storage::folder(data_root, "hotstep")
}

/// The prefix of a tools release's folder.
pub const TOOLS_FOLDER_PREFIX: &str = "hotstep-tools";

/// Removes the tools folders of earlier releases from the shared root, and
/// the folders of before the tools were one build (`legacy_prefix` under the
/// capability's own `runtime`): nothing runs them any more. The folders of
/// today's release and the compatible retained trainer stay.
fn remove_older_tool_folders(downloader: &Downloader, current_folder: &str, retained: Option<&str>, legacy_prefix: &str) {
    let current = downloader.runtime_dir(current_folder);
    let keep = |name: &str| Some(name) == retained || name == current_folder || name.starts_with(&format!("{current_folder}-"));
    let sweep = |directory: &Path, prefix: &str| {
        let Ok(entries) = std::fs::read_dir(directory) else { return };
        for entry in entries.flatten() {
            let name = entry.file_name().to_string_lossy().to_string();
            let managed = if prefix == TOOLS_FOLDER_PREFIX {
                name.strip_prefix("hotstep-tools-")
                    .and_then(|suffix| suffix.split('-').next())
                    .is_some_and(|revision| revision.len() == 8 && revision.bytes().all(|byte| byte.is_ascii_hexdigit()))
            } else {
                name.starts_with(prefix)
            };
            if managed && !keep(&name) && entry.file_type().is_ok_and(|kind| kind.is_dir()) {
                if let Err(error) = std::fs::remove_dir_all(entry.path()) {
                    eprintln!("[ERROR] could not remove the older {} {}: {error}", prefix, entry.path().display());
                }
            }
        }
    };
    if let Some(shared) = current.parent() {
        sweep(shared, TOOLS_FOLDER_PREFIX);
    }
    sweep(&downloader.root().join("runtime"), legacy_prefix);
}

/// The folder the trainer archive unpacks into, named by its release: a
/// studio updated to a newer trainer must not find the older one's folder and
/// take it for installed, then call it with options it does not know.
fn trainer_folder() -> &'static str {
    static FOLDER: OnceLock<String> = OnceLock::new();
    FOLDER.get_or_init(|| trainer_source().release_tag.clone())
}

// Older signed generations are resolved separately. Keep this one compatible
// built-in archive's record and runtime independent during the current upgrade.
const PREVIOUS_TRAINER: Asset = Asset {
    id: "music-train",
    label: "Trainer (HOT-Step 75923e70)",
    kind: AssetKind::Runtime,
    url: "https://github.com/timoncool/YuE2-Studio/releases/download/hotstep-tools-75923e70-xcr0/hotstep-tools-xcr0-cuda-windows-x64.zip",
    relative_path: "hotstep-tools-xcr0-cuda-windows-x64.zip",
    bytes: 125_410_660,
    unzip_into: Some("hotstep-tools-75923e70-xcr0"),
    marker: "music-train.exe",
    pick: &[],
    vram_gb: None,
    note: "",
};

pub(super) fn cuda12_backend() -> &'static Asset {
    static BACKEND: OnceLock<Asset> = OnceLock::new();
    BACKEND.get_or_init(|| {
        let source = trainer_source();
        Asset {
            id: "music-train-cuda12",
            label: "HOT-Step CUDA 12",
            kind: AssetKind::Runtime,
            url: Box::leak(format!("https://github.com/timoncool/YuE2-Studio/releases/download/{}/{}", source.cuda12_backend_tag, source.cuda12_backend_asset).into_boxed_str()),
            relative_path: &source.cuda12_backend_asset,
            bytes: source.cuda12_backend_bytes,
            unzip_into: Some(&source.cuda12_backend_tag),
            marker: "ggml-cuda.dll",
            pick: &[],
            vram_gb: None,
            note: "",
        }
    })
}

fn stage_cuda12_trainer(base: &Path, backend: &Path, directory: &Path) -> Result<PathBuf> {
    let root = base.parent().context("HOT-Step runtime folder")?;
    let copy = |source: &Path, name: &std::ffi::OsStr| -> Result<()> {
        let destination = directory.join(name);
        if std::fs::hard_link(source, &destination).is_err() {
            std::fs::copy(source, destination)?;
        }
        Ok(())
    };
    let name = base.file_name().context("HOT-Step executable filename")?;
    copy(base, name)?;
    for entry in std::fs::read_dir(root)? {
        let entry = entry?;
        let name = entry.file_name();
        let dll = name.to_string_lossy();
        if entry.file_type()?.is_file() && (matches!(&*dll, "ggml.dll" | "ggml-base.dll") || (dll.starts_with("ggml-cpu-") && dll.ends_with(".dll"))) {
            copy(&entry.path(), &name)?;
        }
    }
    copy(backend, std::ffi::OsStr::new("ggml-cuda.dll"))?;
    Ok(directory.join(name))
}

/// Everything training needs: the trainer, released beside the studio, and
/// the engine's weights for it.
pub(crate) fn pack() -> &'static [Asset] {
    static PACK: OnceLock<Vec<Asset>> = OnceLock::new();
    PACK.get_or_init(|| {
        let leak = |text: String| -> &'static str { Box::leak(text.into_boxed_str()) };
        let source = trainer_source();
        let mut assets = vec![Asset {
            id: "music-train",
            label: leak(format!("Trainer (HOT-Step {})", &source.commit[..8])),
            kind: AssetKind::Runtime,
            url: leak(format!("https://github.com/timoncool/YuE2-Studio/releases/download/{}/{}", source.release_tag, source.asset)),
            relative_path: leak(source.asset.clone()),
            bytes: source.bytes,
            unzip_into: Some(trainer_folder()),
            marker: leak(source.shipped_as.clone()),
            pick: &[],
            vram_gb: None,
            note: "",
        }];
        assets.extend(yue_train::TRAINING_FILES.iter().map(|file| Asset {
            id: file.id,
            label: file.label,
            kind: AssetKind::Model,
            url: leak(yue_train::training_file_url(file)),
            relative_path: leak(format!("models/{}", file.file)),
            bytes: file.bytes,
            unzip_into: None,
            marker: "",
            pick: &[],
            vram_gb: None,
            note: "",
        }));
        assets
    })
}

/// The captioner, beside the trainer whose ggml it shares. Picked out of its
/// archive by name, so removing it never takes the trainer's folder along.
const CAPTIONER: &str = "ace-caption.exe";
/// The captioner with the ggml it was built with, processor builds included:
/// it runs where the training pack, which carries the CUDA build, is not
/// installed - a machine without an NVIDIA card is not offered that pack.
const CAPTIONER_PICK: [&str; 12] = [
    CAPTIONER,
    "ggml.dll",
    "ggml-base.dll",
    "ggml-cpu-alderlake.dll",
    "ggml-cpu-cannonlake.dll",
    "ggml-cpu-cascadelake.dll",
    "ggml-cpu-haswell.dll",
    "ggml-cpu-icelake.dll",
    "ggml-cpu-sandybridge.dll",
    "ggml-cpu-skylakex.dll",
    "ggml-cpu-sse42.dll",
    "ggml-cpu-x64.dll",
];

/// The captioner the macOS app bundle and the Linux packages carry in
/// `resources/music-midi`, built with the MIDI transcriber from the same
/// HOT-Step; the downloadable archive is a Windows build.
fn bundled_captioner() -> Option<PathBuf> {
    if cfg!(windows) {
        return None;
    }
    let tool = crate::engine_bundle_root().parent()?.join("music-midi").join("music-caption");
    tool.is_file().then_some(tool)
}

/// Describing dataset songs by ear, optional: HOT-Step's `ace-caption` beside
/// the trainer, MOSS-Music-8B-Instruct (OpenMOSS, Apache-2.0; GGUF by
/// scragnog) for what it hears and Beat This! (CPJKU, MIT; ONNX by
/// mosynthkey) for the beat.
pub(crate) fn listen_pack() -> &'static [Asset] {
    static PACK: OnceLock<Vec<Asset>> = OnceLock::new();
    PACK.get_or_init(|| {
        let leak = |text: String| -> &'static str { Box::leak(text.into_boxed_str()) };
        let source = trainer_source();
        let model = |id: &'static str, label: &'static str, url: &'static str, path: &'static str, bytes: u64| Asset {
            id,
            label,
            kind: AssetKind::Model,
            url,
            relative_path: path,
            bytes,
            unzip_into: None,
            marker: "",
            pick: &[],
            vram_gb: None,
            note: "",
        };
        vec![
            Asset {
                id: "ace-caption",
                label: leak(format!("Captioner (HOT-Step {})", &source.commit[..8])),
                kind: AssetKind::Runtime,
                url: leak(format!("https://github.com/timoncool/YuE2-Studio/releases/download/{}/{}", source.release_tag, source.caption_asset)),
                relative_path: leak(source.caption_asset.clone()),
                bytes: source.caption_bytes,
                unzip_into: Some(trainer_folder()),
                marker: CAPTIONER,
                pick: &CAPTIONER_PICK,
                vram_gb: None,
                note: "",
            },
            model(
                "moss-audio",
                "MOSS-Music audio tower (F16)",
                "https://huggingface.co/scragnog/MOSS-Music-8B-Instruct-GGUF/resolve/9fe86435bd542bf29cbf4984e9e0ab0ea8ca7e00/moss-aud-f16.gguf",
                "models/moss/moss-aud-f16.gguf",
                1_724_480_640,
            ),
            model(
                "moss-lm",
                "MOSS-Music 8B (Q8_0)",
                "https://huggingface.co/scragnog/MOSS-Music-8B-Instruct-GGUF/resolve/9fe86435bd542bf29cbf4984e9e0ab0ea8ca7e00/moss-lm-q8_0.gguf",
                "models/moss/moss-lm-q8_0.gguf",
                8_709_513_792,
            ),
            model(
                "moss-lm-q4",
                "MOSS-Music 8B (Q4_K_M)",
                "https://huggingface.co/nerualdreming/MOSS-Music-8B-Instruct-GGUF/resolve/0b4eac01086c26baf93238aa8b142ec07b3ae56d/moss-lm-q4_k_m.gguf",
                "models/moss/moss-lm-q4_k_m.gguf",
                5_188_223_648,
            ),
            model(
                "beat-this",
                "Beat This! (tempo)",
                "https://github.com/mosynthkey/beat_this_cpp/raw/07ab790a9ec2eda8093d52d249e3ec4f0510ee72/onnx/beat_this.onnx",
                "models/audio-facts/beat_this.onnx",
                83_077_778,
            ),
        ]
    })
}

fn now() -> String {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs().to_string()).unwrap_or_default()
}

/// The trainer adds staging directories and temporary filenames to the output path.
#[cfg(windows)]
fn joint_checkpoint_paths(mut stage: yue_train::TrainingStage) -> Result<yue_train::TrainingStage> {
    use std::ffi::OsStr;

    if stage.args.first().map(|arg| arg.as_os_str()) != Some(OsStr::new("yue2-joint-train")) {
        return Ok(stage);
    }
    let mut args = stage.args.iter_mut();
    while let Some(flag) = args.next() {
        let output = flag == "--output";
        if !output && flag != "--resume" {
            continue;
        }
        let value = args.next().context("the trainer is missing its checkpoint path")?;
        let path = Path::new(value);
        // Canonicalize the existing parent of a new output directory; the trainer
        // requires the output itself to be absent. For resume, the file already exists.
        let extended = if output {
            let parent = path.parent().filter(|parent| !parent.as_os_str().is_empty()).unwrap_or_else(|| Path::new("."));
            let folder = path.file_name().context("the training output has no directory name")?;
            std::fs::canonicalize(parent).map(|parent| parent.join(folder))
        } else {
            std::fs::canonicalize(path)
        }
        .with_context(|| format!("resolve the trainer's checkpoint path {}", path.display()))?;
        *value = extended.into_os_string();
    }
    Ok(stage)
}

/// The trainer prints the file error before a short stage summary. Keep both for the run card.
#[derive(Default)]
struct TrainerFailure {
    file_error: Option<String>,
    summary: String,
}

impl TrainerFailure {
    fn observe(&mut self, line: &str) {
        if line.starts_with("[STWrite]") {
            self.file_error = Some(line.to_owned());
        } else if line.contains("FATAL") || line.to_ascii_lowercase().contains("error") || line.starts_with("ace-train ") && line.contains("failed") {
            self.summary = line.to_owned();
        }
    }

    fn message(self) -> String {
        match self.file_error {
            Some(detail) if self.summary.is_empty() => detail,
            Some(detail) => format!("{detail} | {}", self.summary),
            None => self.summary,
        }
    }
}

fn new_id() -> String {
    uuid::Uuid::now_v7().simple().to_string()
}

/// A bare `name.wav`: no folder, no drive (`C:x.wav` is a path on Windows).
fn is_plain_wav_name(name: &str) -> bool {
    name.ends_with(".wav") && !name.contains([':', '/', '\\']) && Path::new(name).file_name().and_then(|n| n.to_str()) == Some(name) && name != ".wav"
}

fn safe_id(id: &str) -> Result<&str> {
    if id.is_empty() || !id.chars().all(|c| c.is_ascii_alphanumeric() || c == '-') {
        bail!("not an id: {id}");
    }
    Ok(id)
}

fn write_json(path: &Path, value: &impl Serialize) -> Result<()> {
    let temporary = path.with_extension(format!("{}.part", new_id()));
    std::fs::write(&temporary, serde_json::to_vec_pretty(value)?)?;
    std::fs::rename(&temporary, path)?;
    Ok(())
}

fn read_json<T: for<'a> Deserialize<'a>>(path: &Path) -> Option<T> {
    serde_json::from_slice(&std::fs::read(path).ok()?).ok()
}

/// A run's trained steps, one JSON line each, beside its run.json.
const STEPS_FILE: &str = "steps.jsonl";

/// A run as its folder holds it: run.json, with the steps from their own file
/// once it exists. A line still being written has no newline yet and is left
/// for the next read, and one a stop cut off mid-write goes with the next step's
/// append.
fn read_run(dir: &Path) -> Option<Run> {
    let mut run: Run = read_json(&dir.join("run.json"))?;
    if let Ok(text) = std::fs::read_to_string(dir.join(STEPS_FILE)) {
        let complete = &text[..text.rfind('\n').map_or(0, |end| end + 1)];
        let mut steps = Vec::new();
        for line in complete.lines() {
            match serde_json::from_str(line) {
                Ok(record) => steps.push(record),
                Err(error) => eprintln!("[ERROR] {}: a step line that is not JSON is left out ({error}): {line}", dir.join(STEPS_FILE).display()),
            }
        }
        run.steps = steps;
    }
    Some(run)
}

fn write_steps(dir: &Path, steps: &[TrainingStepRecord]) -> Result<()> {
    let mut lines = String::new();
    for record in steps {
        lines.push_str(&serde_json::to_string(record)?);
        lines.push('\n');
    }
    let path = dir.join(STEPS_FILE);
    let temporary = path.with_extension(format!("{}.part", new_id()));
    std::fs::write(&temporary, lines)?;
    std::fs::rename(&temporary, &path)?;
    Ok(())
}

impl Training {
    pub fn new(data_root: &Path, engine: &str) -> Self {
        let root = data_root.join("training");
        let _ = fs::create_dir_all(root.join("models/own"));
        let training = Self {
            // the shared tools are asked where they are each time: the HOT-Step folder may be kept elsewhere
            downloader: Downloader::at_places(crate::downloads::Place::Fixed(root.clone()), crate::downloads::Place::download(data_root, "hotstep", "")),
            root,
            engine: engine.to_string(),
            active: RwLock::new(None),
            edits: std::sync::Mutex::new(()),
            ended: std::sync::OnceLock::new(),
            step_stages: std::sync::Mutex::new(yue_train::StepStages::default()),
            f32_path: std::sync::atomic::AtomicBool::new(false),
        };
        training.remove_older_trainers();
        training
    }

    /// Who is told how each run ends; set once.
    pub fn on_run_ended(&self, ended: RunEnded) {
        let _ = self.ended.set(ended);
    }

    pub fn downloader(&self) -> &Downloader {
        &self.downloader
    }

    /// The trainer: where `YUE_TRAIN_BIN` points in a developer build, else
    /// the one the pack unpacked.
    pub fn trainer(&self) -> PathBuf {
        std::env::var_os("YUE_TRAIN_BIN")
            .map(PathBuf::from)
            .unwrap_or_else(|| self.downloader.runtime_dir(trainer_folder()).join(&trainer_source().shipped_as))
    }

    fn previous_trainer(&self) -> PathBuf {
        self.downloader.picked_into(&PREVIOUS_TRAINER).join(PREVIOUS_TRAINER.marker)
    }

    /// The built-in trainer is the default for existing runs and recipes.
    fn builtin_identity(&self, trainer: &Path) -> Result<TrainerIdentity> {
        let version = if std::env::var_os("YUE_TRAIN_BIN").is_some() {
            format!("local-{}", crate::install_record::sha256_of(trainer)?)
        } else if trainer == self.previous_trainer() {
            PREVIOUS_BUILTIN_VERSION.into()
        } else {
            trainer_source().commit.clone()
        };
        Ok(TrainerIdentity {
            id: BUILTIN_TRAINER.into(),
            version,
            generation: None,
            optimizer_format: YUE2_STATE_FORMAT.into(),
            weights_revision: yue_train::WEIGHTS_REVISION.into(),
        })
    }

    async fn select_trainer(&self, id: Option<&str>, saved: Option<&TrainerIdentity>, continuing: bool) -> Result<(PathBuf, TrainerIdentity)> {
        if let Some(saved) = saved
            && (saved.optimizer_format != YUE2_STATE_FORMAT || saved.weights_revision != yue_train::WEIGHTS_REVISION)
        {
            bail!("This checkpoint needs its original YuE2 training base and optimizer format.");
        }
        let choice = saved.map(|saved| saved.id.as_str()).or(id).unwrap_or(BUILTIN_TRAINER);
        let (trainer, identity) = if choice == BUILTIN_TRAINER {
            self.select_builtin_trainer(saved, continuing)?
        } else {
            let data_root = self.root.parent().context("Studio data folder")?;
            let generation = saved.and_then(|saved| saved.generation.as_deref());
            let worker = crate::engine_catalogue::install::resolve_trainer(data_root, choice, generation).await?;
            (
                worker.executable,
                TrainerIdentity {
                    id: choice.into(), version: worker.version, generation: Some(worker.generation),
                    optimizer_format: YUE2_STATE_FORMAT.into(), weights_revision: yue_train::WEIGHTS_REVISION.into(),
                },
            )
        };
        if let Some(saved) = saved && !identity.can_resume(saved) {
            bail!("Install the original trainer generation before continuing this checkpoint.");
        }
        if !self.shared_weights_ready() {
            bail!("the YuE2 shared training weights are not downloaded yet");
        }
        Ok((trainer, identity))
    }

    fn select_builtin_trainer(&self, saved: Option<&TrainerIdentity>, continuing: bool) -> Result<(PathBuf, TrainerIdentity)> {
        let program = self.trainer();
        if self.installed(&pack()[0]) {
            let identity = self.builtin_identity(&program)?;
            return Ok((program, identity));
        }
        if continuing
            && std::env::var_os("YUE_TRAIN_BIN").is_none()
            && trainer_source().commit == CURRENT_BUILTIN_VERSION
            && saved.is_none_or(|identity| identity.version == PREVIOUS_BUILTIN_VERSION && identity.generation.is_none())
            && self.downloader.is_verified_install(&PREVIOUS_TRAINER)
        {
            let previous = self.previous_trainer();
            let identity = self.builtin_identity(&previous)?;
            return Ok((previous, identity));
        }
        bail!("the trainer is not installed: {} has no completed installation", program.display());
    }

    pub(super) fn training_base_asset(id: &str) -> Result<&'static Asset> {
        if id == STOCK_BASE {
            return pack().iter().find(|asset| asset.id == yue_train::TRAINING_FILES[0].id)
                .context("stock training base");
        }
        ALTERNATE_BASES.iter().find(|(asset, _)| asset.id == id).map(|(asset, _)| asset)
            .with_context(|| format!("Unknown YuE2 training base: {id}"))
    }

    pub(super) fn own_base_id(id: &str) -> bool {
        id.starts_with(OWN_BASE_PREFIX)
    }

    pub(super) fn own_bases_directory(&self) -> PathBuf {
        self.models_dir().join("own")
    }

    fn own_base_file(&self, id: &str) -> Result<PathBuf> {
        let name = id.strip_prefix(OWN_BASE_PREFIX).context("not a custom training base")?;
        let path = Path::new(name);
        anyhow::ensure!(path.file_name() == Some(path.as_os_str())
            && path.extension().is_some_and(|ext| ext.eq_ignore_ascii_case("safetensors")),
            "invalid custom YuE2 training file name");
        let file = self.own_bases_directory().join(path);
        anyhow::ensure!(file.is_file(), "custom training base is missing: {}", file.display());
        Ok(file)
    }

    pub(super) fn base_choices(&self) -> Vec<serde_json::Value> {
        let mut choices: Vec<_> = std::iter::once(STOCK_BASE).chain(ALTERNATE_BASES.iter().map(|(asset, _)| asset.id))
            .filter_map(|id| Self::training_base_asset(id).ok().map(|asset| (id, asset)))
            .map(|(id, asset)| serde_json::json!({
                "id": id, "label": asset.label, "bytes": asset.bytes,
                "installed": self.installed(asset), "note": asset.note,
            }))
            .collect();
        let mut own: Vec<_> = fs::read_dir(self.own_bases_directory()).into_iter().flatten().flatten()
            .filter_map(|entry| {
                let name = entry.file_name().into_string().ok()?;
                let id = format!("{OWN_BASE_PREFIX}{name}");
                let file = self.own_base_file(&id).ok()?;
                let bytes = file.metadata().ok()?.len();
                Some((name, id, bytes))
            }).collect();
        own.sort_unstable();
        choices.extend(own.into_iter().map(|(label, id, bytes)| serde_json::json!({
            "id": id, "label": label, "bytes": bytes, "installed": true, "note": "",
        })));
        choices
    }

    pub(super) fn validate_base_install(&self, id: &str) -> Result<()> {
        if Self::own_base_id(id) {
            self.own_base_file(id)?;
        } else {
            Self::training_base_asset(id)?;
        }
        Ok(())
    }

    pub(super) async fn install_base(&self, id: &str) -> Result<()> {
        self.validate_base_install(id)?;
        let asset = Self::training_base_asset(id).ok();
        let missing: Vec<_> = pack().iter().filter(|file| file.id != yue_train::TRAINING_FILES[0].id)
            .chain(asset)
            .filter(|file| !self.installed(file))
            .collect();
        if !missing.is_empty() {
            self.downloader.install_all(BASE_SCOPE, &missing).await?;
        }
        Ok(())
    }

    async fn resolve_training_base(
        &self,
        requested: Option<&str>,
        saved: Option<&TrainingBaseIdentity>,
        companion: &Path,
        tokenizer: Option<&Path>,
    ) -> Result<(PathBuf, TrainingBaseIdentity)> {
        let id = saved.map(|value| value.id.as_str()).or(requested).unwrap_or(STOCK_BASE);
        let custom = Self::own_base_id(id);
        let (checkpoint, label, expected) = if custom {
            let file = self.own_base_file(id)?;
            let header = crate::adapters::local_header(&file).context("read the custom ConvRot header")?;
            let meta = header.get("__metadata__");
            anyhow::ensure!(meta.and_then(|value| value.get("yue2_format")).and_then(serde_json::Value::as_str) == Some("1")
                && meta.and_then(|value| value.get("quantization")).and_then(serde_json::Value::as_str) == Some("convrot_int8")
                && header.contains_key("model.diffusion_model.llm2vae.weight_scale"),
                "the custom training base must be a YuE2 INT8 ConvRot Safetensors");
            (file, id, None)
        } else {
            let asset = Self::training_base_asset(id)?;
            if !self.installed(asset) {
                bail!("Install the YuE2 training base `{}` before training.", asset.label);
            }
            let expected = if id == STOCK_BASE {
                Some("96fe199377309001ed8cd26a944baeee8cc31a20ba7c36d1d3c0a7e1f4149db6")
            } else {
                base_asset_sha(asset.url)
            };
            (self.root.join(asset.relative_path), asset.label, expected)
        };
        let source = checkpoint.clone();
        let decoder = companion.to_owned();
        let active_own = if custom && saved.is_none() {
            Some(tokenizer.context("select the paired custom YuE2 generation GGUF")?.to_owned())
        } else {
            None
        };
        let (checkpoint_sha256, companion_sha256, active_own_sha) = tokio::task::spawn_blocking(move || {
            Ok::<_, anyhow::Error>((
                crate::install_record::sha256_of(&source).context("hash the training checkpoint")?,
                generation_model_sha(&decoder).context("hash the decoder companion")?,
                active_own.as_deref().map(generation_model_sha).transpose()?,
            ))
        }).await??;
        if expected.is_some_and(|expected| expected != checkpoint_sha256) {
            bail!("The YuE2 training base `{label}` differs from its published SHA-256.");
        }
        let own_backbone_sha256 = saved.and_then(|original| original.own_backbone_sha256.clone()).or(active_own_sha);
        let identity = TrainingBaseIdentity { id: id.into(), checkpoint_sha256, companion_sha256, own_backbone_sha256 };
        if saved.is_some_and(|original| original != &identity) {
            bail!("The checkpoint needs the original YuE2 training base and decoder companion to continue.");
        }
        Ok((checkpoint, identity))
    }

    pub fn models_dir(&self) -> PathBuf {
        self.root.join("models")
    }

    /// The captioner: `YUE_CAPTION_BIN` in a developer build, the one bundled
    /// beside the MIDI transcriber on macOS and Linux, else the one the
    /// listening pack unpacked beside the trainer.
    pub fn captioner(&self) -> PathBuf {
        std::env::var_os("YUE_CAPTION_BIN")
            .map(PathBuf::from)
            .or_else(bundled_captioner)
            .unwrap_or_else(|| self.downloader.runtime_dir(trainer_folder()).join(CAPTIONER))
    }

    pub fn moss_dir(&self) -> PathBuf {
        self.models_dir().join("moss")
    }

    pub fn audio_facts_dir(&self) -> PathBuf {
        self.models_dir().join("audio-facts")
    }

    fn listen_installed(&self, asset: &Asset) -> bool {
        if asset.marker == CAPTIONER {
            return self.captioner().is_file();
        }
        self.downloader.is_installed(asset)
    }

    /// The listening pack this machine downloads and runs: every file but the MOSS-Music build its card does not take
    /// (`listen::hearing`).
    fn listen_files(&self) -> impl Iterator<Item = &'static Asset> {
        let hearing = crate::listen::hearing(&crate::hardware::hardware(), false);
        listen_pack().iter().filter(move |asset| !asset.id.starts_with("moss-lm") || asset.relative_path.ends_with(hearing.lm))
    }

    /// The listening pack's files with whether each is on disk.
    pub fn listen_status(&self) -> Vec<serde_json::Value> {
        self.listen_files()
            .map(|asset| serde_json::json!({ "id": asset.id, "label": asset.label, "bytes": asset.bytes, "installed": self.listen_installed(asset) }))
            .collect()
    }

    pub fn listen_ready(&self) -> bool {
        self.listen_files().all(|asset| self.listen_installed(asset))
    }

    pub async fn install_listen(&self) -> Result<()> {
        let missing: Vec<&'static Asset> = self.listen_files().filter(|asset| !self.listen_installed(asset)).collect();
        if missing.is_empty() {
            return Ok(());
        }
        self.downloader.install_all(LISTEN_SCOPE, &missing).await
    }

    fn datasets_dir(&self) -> PathBuf {
        self.root.join("datasets")
    }

    fn runs_dir(&self) -> PathBuf {
        self.root.join("runs")
    }

    fn dataset_dir(&self, id: &str) -> Result<PathBuf> {
        Ok(self.datasets_dir().join(safe_id(id)?))
    }

    /// Where a dataset keeps its separated vocals: `<song>/vocals.wav`, the
    /// layout the trainer's aligner reads.
    fn vocals_dir(&self, id: &str) -> Result<PathBuf> {
        Ok(self.dataset_dir(id)?.join("vocals"))
    }

    /// The separated vocals of one dataset song, whether or not made yet.
    pub fn item_vocals(&self, id: &str, item_id: &str) -> Result<PathBuf> {
        let dataset = self.dataset(id)?;
        let item = dataset.items.iter().find(|item| item.id == item_id).with_context(|| format!("no song {item_id} in the dataset"))?;
        Ok(self.vocals_dir(id)?.join(item.file.trim_end_matches(".wav")).join("vocals.wav"))
    }

    /// Songs with lyrics whose vocals are not separated yet.
    fn missing_vocals(&self, dataset: &Dataset) -> Result<Vec<(PathBuf, PathBuf)>> {
        let audio = self.dataset_dir(&dataset.id)?.join("audio");
        let vocals = self.vocals_dir(&dataset.id)?;
        Ok(dataset
            .items
            .iter()
            .filter(|item| !item.instrumental && !item.lyrics.trim().is_empty())
            .map(|item| (audio.join(&item.file), vocals.join(item.file.trim_end_matches(".wav")).join("vocals.wav")))
            .filter(|(_, out)| !out.is_file())
            .collect())
    }

    fn run_dir(&self, id: &str) -> Result<PathBuf> {
        Ok(self.runs_dir().join(safe_id(id)?))
    }

    fn installed(&self, asset: &Asset) -> bool {
        if asset.id == "music-train" && std::env::var_os("YUE_TRAIN_BIN").is_some() {
            return self.trainer().is_file();
        }
        self.downloader.is_installed(asset)
    }

    /// The pack's files with whether each is on disk.
    pub fn pack_status(&self) -> Vec<serde_json::Value> {
        pack()
            .iter()
            .map(|asset| serde_json::json!({ "id": asset.id, "label": asset.label, "bytes": asset.bytes, "installed": self.installed(asset) }))
            .collect()
    }

    pub(super) fn shared_weights_ready(&self) -> bool {
        pack().iter().filter(|asset| asset.id != "music-train" && asset.id != yue_train::TRAINING_FILES[0].id)
            .all(|asset| self.installed(asset))
    }

    pub(super) fn weights_ready(&self) -> bool {
        pack().iter().filter(|asset| asset.id != "music-train").all(|asset| self.installed(asset))
    }

    pub(super) async fn trainer_choices(&self) -> Vec<serde_json::Value> {
        let bundle = &pack()[0];
        let mut choices = vec![serde_json::json!({
            "id": BUILTIN_TRAINER,
            "label": bundle.label,
            "version": trainer_source().commit,
            "installed": self.installed(bundle),
            "bytes": bundle.bytes,
        })];
        if let Some(data_root) = self.root.parent() {
            choices.extend(crate::engine_catalogue::install::trainer_choices(data_root).await
                .into_iter().filter(|choice| choice["id"] != BUILTIN_TRAINER));
        }
        choices
    }

    pub fn pack_ready(&self) -> bool {
        pack().iter().all(|asset| self.installed(asset))
    }

    pub async fn install_pack(&self) -> Result<()> {
        let missing: Vec<&'static Asset> = pack().iter().filter(|asset| !self.installed(asset)).collect();
        if !missing.is_empty() {
            self.downloader.install_all(SCOPE, &missing).await?;
        }
        self.remove_older_trainers();
        Ok(())
    }

    /// Retire older tools once the upgrade is complete, keeping the compatible
    /// predecessor available for continuations that started during the upgrade.
    fn remove_older_trainers(&self) {
        let Some(runtime) = pack().iter().find(|asset| asset.id == "music-train") else { return };
        let managed = self.downloader.runtime_dir(trainer_folder()).join(runtime.marker);
        if managed.is_file() && self.downloader.is_installed(runtime) {
            let retained = PREVIOUS_TRAINER.unzip_into.filter(|_| trainer_source().commit == CURRENT_BUILTIN_VERSION);
            remove_older_tool_folders(&self.downloader, trainer_folder(), retained, "music-train");
        }
    }

    // ── datasets ────────────────────────────────────────────────────────────

    pub fn datasets(&self) -> Vec<Dataset> {
        let Ok(entries) = std::fs::read_dir(self.datasets_dir()) else { return Vec::new() };
        let mut list: Vec<Dataset> = entries
            .flatten()
            .filter(|entry| entry.path().join("dataset.json").is_file())
            .filter_map(|entry| match read_dataset(&entry.path().join("dataset.json")) {
                Ok(dataset) => Some(dataset),
                Err(error) => {
                    eprintln!("[ERROR] {error:#}");
                    None
                }
            })
            .collect();
        list.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        list
    }

    pub fn dataset(&self, id: &str) -> Result<Dataset> {
        let path = self.dataset_dir(id)?.join("dataset.json");
        if !path.is_file() {
            bail!("no dataset {id}");
        }
        read_dataset(&path)
    }

    fn save_dataset(&self, dataset: &Dataset) -> Result<()> {
        let dir = self.dataset_dir(&dataset.id)?;
        std::fs::create_dir_all(dir.join("audio"))?;
        write_json(&dir.join("dataset.json"), dataset)
    }

    pub fn create_dataset(&self, name: &str, trigger: &str) -> Result<Dataset> {
        let name = name.trim();
        if name.is_empty() {
            bail!("a dataset needs a name");
        }
        // every dataset has a trigger word from the start; the user can change it
        let trigger = if trigger.trim().is_empty() { trigger_from(name) } else { trigger.trim().to_string() };
        let dataset = Dataset { format: dataset_format(), id: new_id(), name: name.into(), trigger, trigger_chosen: false, created_at: now(), items: Vec::new() };
        self.save_dataset(&dataset)?;
        Ok(dataset)
    }

    pub fn update_dataset(&self, id: &str, name: Option<String>, trigger: Option<String>) -> Result<Dataset> {
        let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut dataset = self.dataset(id)?;
        if let Some(name) = name.map(|name| name.trim().to_string()).filter(|name| !name.is_empty()) {
            dataset.name = name;
        }
        if let Some(trigger) = trigger {
            dataset.trigger = trigger.trim().into();
            dataset.trigger_chosen = true;
        }
        self.save_dataset(&dataset)?;
        Ok(dataset)
    }

    /// Adds a song, stored as 48 kHz 24-bit WAV whatever it came as: the
    /// model's own rate, and more depth than any source has.
    /// `instrumental` is what is known of the song: a library song made without
    /// lyrics is one, an audio file is sung until recognition hears no words.
    #[allow(clippy::too_many_arguments)]
    pub fn add_item(&self, id: &str, source_audio: &Path, title: &str, artist: &str, style: &str, lyrics: &str, instrumental: bool, source: &str) -> Result<Dataset> {
        self.dataset(id)?;
        let audio = crate::audio_pcm::decode_stereo(source_audio)?;
        self.add_audio(id, audio, title, artist, style, lyrics, instrumental, source)
    }

    /// A whole-album file cut into its songs by the cue sheet beside it; the
    /// album is decoded once. Pieces under ten seconds, such as a hidden
    /// intro, are left out.
    pub fn add_album(&self, id: &str, source_audio: &Path, tracks: &[CueTrack], artist: &str, source: &str) -> Result<Dataset> {
        let album = crate::audio_pcm::decode_stereo(source_audio)?;
        let rate = album.rate as f64;
        let mut dataset = self.dataset(id)?;
        for (index, track) in tracks.iter().enumerate() {
            let start = ((track.start * rate) as usize).min(album.frames());
            let end = tracks.get(index + 1).map_or(album.frames(), |next| ((next.start * rate) as usize).min(album.frames()));
            if (end.saturating_sub(start) as f64) < 10.0 * rate {
                continue;
            }
            let piece = audio_post::Stereo::new(album.left[start..end].to_vec(), album.right[start..end].to_vec(), album.rate);
            let performer = if track.performer.is_empty() { artist } else { track.performer.as_str() };
            dataset = self.add_audio(id, piece, &track.title, performer, "", "", false, &format!("{source}#{}", index + 1))?;
        }
        Ok(dataset)
    }

    #[allow(clippy::too_many_arguments)]
    fn add_audio(&self, id: &str, audio: audio_post::Stereo, title: &str, artist: &str, style: &str, lyrics: &str, instrumental: bool, source: &str) -> Result<Dataset> {
        let audio = if audio.rate == 48_000 { audio } else { audio.resampled(48_000)? };
        let seconds = audio.frames() as f64 / 48_000.0;
        if seconds < 10.0 {
            bail!("{title} is shorter than ten seconds; the trainer cuts songs into ten-second pieces");
        }
        let item_id = new_id();
        let file = format!("{item_id}.wav");
        crate::audio_pcm::write_wav24(&self.dataset_dir(id)?.join("audio").join(&file), &audio)?;
        let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut dataset = self.dataset(id)?;
        dataset.items.push(DatasetItem {
            id: item_id,
            title: title.trim().into(),
            artist: artist.trim().into(),
            lyrics_source: String::new(),
            style: style.trim().into(),
            lyrics: lyrics.trim().into(),
            instrumental,
            file,
            seconds,
            source: source.into(),
            lyrics_state: lyrics_state_of(lyrics, instrumental),
            style_state: style_state_of(style),
            heard: None,
        });
        self.save_dataset(&dataset)?;
        Ok(dataset)
    }

    pub fn update_item(&self, id: &str, item_id: &str, patch: ItemPatch) -> Result<Dataset> {
        let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut dataset = self.dataset(id)?;
        let item = dataset.items.iter_mut().find(|item| item.id == item_id).with_context(|| format!("no song {item_id} in the dataset"))?;
        if let Some(title) = patch.title {
            item.title = title.trim().into();
        }
        if let Some(artist) = patch.artist {
            item.artist = artist.trim().into();
        }
        if let Some(source) = patch.lyrics_source {
            item.lyrics_source = source;
        }
        if let Some(style) = patch.style {
            item.style = style.trim().into();
        }
        if let Some(lyrics) = patch.lyrics {
            item.lyrics = lyrics.trim().into();
        }
        if let Some(instrumental) = patch.instrumental {
            item.instrumental = instrumental;
        }
        if let Some(state) = patch.lyrics_state {
            item.lyrics_state = state;
        }
        if let Some(state) = patch.style_state {
            item.style_state = state;
        }
        if let Some(heard) = patch.heard {
            item.heard = heard;
        }
        self.save_dataset(&dataset)?;
        Ok(dataset)
    }

    /// An edit by the user: what they write is final, and a preparation
    /// leaves it alone.
    pub fn edit_item(&self, id: &str, item_id: &str, mut patch: ItemPatch) -> Result<Dataset> {
        let dataset = self.dataset(id)?;
        let item = dataset.items.iter().find(|item| item.id == item_id).with_context(|| format!("no song {item_id} in the dataset"))?;
        if patch.lyrics.is_some() || patch.instrumental.is_some() {
            let instrumental = patch.instrumental.unwrap_or(item.instrumental);
            let lyrics = patch.lyrics.as_deref().unwrap_or(&item.lyrics);
            patch.lyrics_state = Some(if instrumental || !lyrics.trim().is_empty() { LyricsState::Done } else { LyricsState::Wanted });
        }
        if let Some(style) = &patch.style {
            patch.style_state = Some(style_state_of(style));
            patch.heard = Some(None);
        }
        self.update_item(id, item_id, patch)
    }

    /// Sends the chosen songs back to the start of a step, their text kept
    /// until the new one is there: "find again", "describe again".
    pub fn reset_states(&self, id: &str, items: &[String], lyrics: bool, style: bool) -> Result<()> {
        let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut dataset = self.dataset(id)?;
        for item in dataset.items.iter_mut().filter(|item| items.contains(&item.id)) {
            if lyrics {
                item.lyrics_state = LyricsState::Wanted;
            }
            if style {
                item.style_state = StyleState::Wanted;
                item.heard = None;
            }
        }
        self.save_dataset(&dataset)
    }

    /// The preparation at work, kept on disk so a restart picks it up.
    pub fn prepare_job_path(&self) -> PathBuf {
        self.root.join("prepare.json")
    }

    /// The stored audio of one song of a dataset.
    pub fn item_audio(&self, id: &str, item_id: &str) -> Result<PathBuf> {
        let dataset = self.dataset(id)?;
        let item = dataset.items.iter().find(|item| item.id == item_id).with_context(|| format!("no song {item_id} in the dataset"))?;
        Ok(self.dataset_dir(id)?.join("audio").join(&item.file))
    }

    pub fn remove_item(&self, id: &str, item_id: &str) -> Result<Dataset> {
        let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut dataset = self.dataset(id)?;
        let position = dataset.items.iter().position(|item| item.id == item_id).with_context(|| format!("no song {item_id} in the dataset"))?;
        let item = dataset.items.remove(position);
        let _ = std::fs::remove_file(self.dataset_dir(id)?.join("audio").join(&item.file));
        let _ = std::fs::remove_dir_all(self.vocals_dir(id)?.join(item.file.trim_end_matches(".wav")));
        self.save_dataset(&dataset)?;
        Ok(dataset)
    }

    /// Takes a dataset another studio of the family wrote: its `dataset.json`
    /// and the WAV files it names. The copy gets an id of its own, so the same
    /// folder can come in twice without the two meeting.
    /// Takes a dataset another studio wrote: its `dataset.json` and the audio
    /// files uploaded beside it, by their file names. Every song is checked
    /// before anything is written, and a failed import leaves nothing behind.
    pub fn import_dataset(&self, manifest: &[u8], files: &[(String, PathBuf)]) -> Result<Dataset> {
        let mut dataset: serde_json::Value = serde_json::from_slice(manifest).context("dataset.json is not a dataset")?;
        settle_states(&mut dataset);
        let mut dataset: Dataset = serde_json::from_value(dataset).context("dataset.json is not a dataset")?;
        if dataset.format != dataset_format() {
            bail!("dataset.json is {}, this studio reads {}", dataset.format, dataset_format());
        }
        if dataset.items.is_empty() {
            bail!("the dataset has no songs");
        }
        for item in &dataset.items {
            if !is_plain_wav_name(&item.file) {
                bail!("{} is not a dataset audio file", item.file);
            }
        }
        let by_name = |name: &str| files.iter().find(|(file, _)| file == name).map(|(_, path)| path);
        let missing: Vec<&str> = dataset.items.iter().map(|item| item.file.as_str()).filter(|file| by_name(file).is_none()).collect();
        if !missing.is_empty() {
            bail!("the folder lacks {} of the dataset's songs: {}", missing.len(), missing.join(", "));
        }
        dataset.id = new_id();
        dataset.created_at = now();
        let dir = self.dataset_dir(&dataset.id)?;
        let written = (|| -> Result<()> {
            let audio = dir.join("audio");
            std::fs::create_dir_all(&audio)?;
            // every song takes a fresh id and file name here, whatever the other
            // studio called it
            for item in &mut dataset.items {
                let source = by_name(&item.file).context("song vanished")?.clone();
                item.id = new_id();
                item.file = format!("{}.wav", item.id);
                std::fs::copy(&source, audio.join(&item.file)).with_context(|| format!("copy {}", item.title))?;
            }
            self.save_dataset(&dataset)
        })();
        if let Err(error) = written {
            let _ = std::fs::remove_dir_all(&dir);
            return Err(error);
        }
        Ok(dataset)
    }

    /// The folder a dataset lives in, to share it with another studio.
    pub fn dataset_folder(&self, id: &str) -> Result<PathBuf> {
        let dir = self.dataset_dir(id)?;
        if !dir.join("dataset.json").is_file() {
            bail!("no dataset {id}");
        }
        Ok(dir)
    }

    pub fn remove_dataset(&self, id: &str) -> Result<()> {
        let dir = self.dataset_dir(id)?;
        if !dir.join("dataset.json").is_file() {
            bail!("no dataset {id}");
        }
        std::fs::remove_dir_all(dir)?;
        Ok(())
    }

    /// Writes the sidecars the recipe reads beside every song, from what the
    /// dataset says now, so an edit made after import is what trains.
    fn write_sidecars(&self, dataset: &Dataset) -> Result<PathBuf> {
        let audio = self.dataset_dir(&dataset.id)?.join("audio");
        for item in &dataset.items {
            let stem = item.file.trim_end_matches(".wav");
            let lyrics = if item.instrumental { "" } else { item.lyrics.as_str() };
            for (extension, text) in yue_train::sidecars(&item.style, lyrics, item.instrumental) {
                std::fs::write(audio.join(format!("{stem}{extension}")), text)?;
            }
        }
        Ok(audio)
    }

    // ── runs ────────────────────────────────────────────────────────────────

    pub fn runs(&self) -> Vec<Run> {
        let Ok(entries) = std::fs::read_dir(self.runs_dir()) else { return Vec::new() };
        let mut list: Vec<Run> = entries.flatten().filter_map(|entry| read_run(&entry.path())).filter(|run: &Run| run.engine == self.engine
            || (self.engine == crate::PRIMARY_MUSIC_ENGINE_ID && matches!(run.engine.as_str(), crate::hotstep_cover::ENGINE | crate::rvc_burn::STAGE))).collect();
        list.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        list
    }

    pub fn run(&self, id: &str) -> Result<Run> {
        read_run(&self.run_dir(id)?).with_context(|| format!("no training run {id}"))
    }

    /// Writes the run; once its steps have a file of their own, they go there
    /// and run.json keeps none.
    fn save_run(&self, run: &Run) -> Result<()> {
        let dir = self.run_dir(&run.id)?;
        std::fs::create_dir_all(&dir)?;
        if !dir.join(STEPS_FILE).is_file() {
            return write_json(&dir.join("run.json"), run);
        }
        write_steps(&dir, &run.steps)?;
        write_json(&dir.join("run.json"), &Run { steps: Vec::new(), ..run.clone() })
    }

    /// Records one trained step by adding a line, not by writing the whole run again.
    fn append_step(&self, run_id: &str, record: TrainingStepRecord) -> Result<()> {
        use std::io::{Read, Seek, SeekFrom, Write};
        let dir = self.run_dir(run_id)?;
        if !dir.join(STEPS_FILE).is_file() {
            let mut run = self.run(run_id)?;
            run.steps.push(record);
            write_steps(&dir, &run.steps)?;
            return write_json(&dir.join("run.json"), &Run { steps: Vec::new(), ..run });
        }
        let mut file = std::fs::OpenOptions::new().read(true).write(true).open(dir.join(STEPS_FILE))?;
        // a line cut off by a stop mid-write ends without its newline: it goes, and the next record takes its place
        let length = file.metadata()?.len();
        if length > 0 {
            let mut last = [0u8; 1];
            file.seek(SeekFrom::End(-1))?;
            file.read_exact(&mut last)?;
            if last[0] != b'\n' {
                let mut text = Vec::new();
                file.seek(SeekFrom::Start(0))?;
                file.read_to_end(&mut text)?;
                let kept = text.iter().rposition(|byte| *byte == b'\n').map_or(0, |end| end + 1);
                file.set_len(kept as u64)?;
            }
        }
        file.seek(SeekFrom::End(0))?;
        file.write_all(format!("{}\n", serde_json::to_string(&record)?).as_bytes())?;
        Ok(())
    }

    /// A run left `running` by a studio that closed is marked interrupted.
    pub fn recover(&self) {
        for mut run in self.runs().into_iter().filter(|run| run.status == RunStatus::Running) {
            run.status = RunStatus::Interrupted;
            run.finished_at = Some(now());
            let _ = self.save_run(&run);
        }
    }

    /// Whether the run going now trains on this dataset.
    pub async fn dataset_in_use(&self, dataset_id: &str) -> bool {
        match self.active_run().await {
            Some(run_id) => self.run(&run_id).is_ok_and(|run| run.dataset_id == dataset_id),
            None => false,
        }
    }

    pub async fn active_run(&self) -> Option<String> {
        self.active.read().await.as_ref().map(|active| active.run_id.clone())
    }

    /// The part of a step the training stage is working on now.
    pub fn step_stage(&self) -> Option<yue_train::StepStageNow> {
        self.step_stages.lock().unwrap_or_else(|poisoned| poisoned.into_inner()).now(unix_millis())
    }

    /// Whether the training stage going now took the trainer's F32 path, several times slower (RTX 20xx).
    pub fn f32_path(&self) -> bool {
        self.f32_path.load(std::sync::atomic::Ordering::Relaxed)
    }

    pub fn checkpoints(&self, run_id: &str) -> Vec<yue_train::TrainingCheckpoint> {
        self.run_dir(run_id).map(|dir| yue_train::checkpoints(&dir)).unwrap_or_default()
    }

    /// The last `lines` of a run's log that are not progress JSON, and what
    /// the trainer computes on as the log names it ("CUDA0", "Vulkan0", "CPU";
    /// none before it has said), from one read of the log.
    pub fn log_view(&self, run_id: &str, lines: usize) -> (Vec<String>, Option<String>) {
        let Ok(text) = self.run_dir(run_id).and_then(|dir| Ok(std::fs::read_to_string(dir.join("run.log"))?)) else { return (Vec::new(), None) };
        let all: Vec<&str> = text.lines().filter(|line| !line.trim_start().starts_with('{')).collect();
        let tail = all[all.len().saturating_sub(lines)..].iter().map(|line| line.to_string()).collect();
        (tail, trainer_device(&text))
    }

    /// Starts training a dataset; one run at a time, since each wants the card.
    /// `libraries` is where the CUDA runtime the trainer imports lives: the
    /// engine's, fetched on its first start, so it is not downloaded twice.
    pub async fn start(
        self: &Arc<Self>,
        libraries: Option<PathBuf>,
        tokenizer: PathBuf,
        companion: PathBuf,
        separator: Option<Arc<dyn VocalSeparator>>,
        dataset_id: &str,
        name: &str,
        recipe: Recipe,
        trainer_id: Option<&str>,
        base_id: Option<&str>,
        card: CardHooks,
    ) -> Result<Run> {
        let (trainer, trainer_identity) = self.select_trainer(trainer_id, None, false).await?;
        let (checkpoint, training_base) = self.resolve_training_base(base_id, None, &companion, Some(&tokenizer)).await?;
        let dataset = self.dataset(dataset_id)?;
        if dataset.items.is_empty() {
            bail!("the dataset has no songs yet");
        }
        let unsung: Vec<&str> = dataset.items.iter().filter(|item| !item.instrumental && item.lyrics.trim().is_empty()).map(|item| item.title.as_str()).collect();
        if !unsung.is_empty() {
            bail!("these songs have no lyrics: {}; prepare the dataset, write them, or mark the songs instrumental", unsung.join(", "));
        }
        // by epochs, the run's steps follow from the songs it has
        let recipe = recipe.for_songs(dataset.items.len());
        if let Err(problem) = recipe.check() {
            bail!("{problem}");
        }
        let missing = if recipe.lyric_timing { self.missing_vocals(&dataset)? } else { Vec::new() };
        if !missing.is_empty() && separator.is_none() {
            bail!("the vocal separator is not installed; lyric timing needs the vocals of every song with lyrics");
        }
        let mut active = self.active.write().await;
        if active.is_some() {
            bail!("a training run is already going");
        }
        let audio = self.write_sidecars(&dataset)?;
        let run_id = new_id();
        let run_dir = self.run_dir(&run_id)?;
        let inputs = yue_train::TrainingInputs {
            audio,
            models: self.models_dir(),
            checkpoint,
            tokenizer,
            companion,
            run: run_dir.clone(),
            vocals: self.vocals_dir(&dataset.id)?,
            trigger: dataset.trigger.clone(),
            recipe: recipe.clone(),
        };
        let stages = yue_train::training_stages(&inputs);
        let run = Run {
            id: run_id.clone(),
            engine: self.engine.clone(),
            dataset_id: dataset.id.clone(),
            dataset_name: dataset.name.clone(),
            name: if name.trim().is_empty() { dataset.name.clone() } else { name.trim().into() },
            trigger: dataset.trigger.clone(),
            recipe,
            trainer: Some(trainer_identity),
            training_base: Some(training_base),
            status: RunStatus::Running,
            stage: None,
            stages: inputs.recipe.lyric_timing.then_some(VOCALS_STAGE).into_iter().chain(stages.iter().map(|stage| stage.id)).map(str::to_string).collect(),
            steps: Vec::new(),
            error: None,
            created_at: now(),
            finished_at: None,
            installed: Vec::new(),
            continuations: Vec::new(),
            output_adapter: None,
            hotstep_sa3_settings: None,
            hotstep_heartmula_settings: None,
            rvc_burn_settings: None,
            rvc_voice_id: None,
        };
        self.save_run(&run)?;
        let cancel = Arc::new(tokio::sync::Notify::new());
        *active = Some(Active { run_id: run_id.clone(), cancel: cancel.clone() });
        drop(active);

        let training = self.clone();
        tokio::spawn(async move {
            (card.take)().await;
            let outcome = match training.separate_vocals(&run_id, separator, missing, cancel.clone()).await {
                Ok(true) => training.work(&trainer, libraries.as_deref(), &run_dir, &run_id, stages, cancel).await,
                other => other,
            };
            training.settle(&run_id, outcome, (card.give_back)()).await;
        });
        Ok(run)
    }

    /// Runs a native HOT-Step trainer and publishes its adapter when it finishes.
    pub(super) async fn start_hotstep(
        self: &Arc<Self>,
        model: crate::hotstep_sa3_training::Model,
        trainer: PathBuf,
        models: PathBuf,
        dataset_id: &str,
        name: &str,
        settings: crate::hotstep_sa3_training::Settings,
        card: CardHooks,
    ) -> Result<Run> {
        use crate::hotstep_sa3_training as sa3;
        use std::sync::atomic::{AtomicBool, Ordering};

        let dataset = self.dataset(dataset_id)?;
        let heart = model == sa3::Model::Heartmula;
        if heart && (dataset.items.is_empty() || dataset.items.iter().any(|item| item.style.trim().is_empty() || (!item.instrumental && item.lyrics.trim().is_empty()))) {
            bail!("HeartMuLa training needs a style on every track and lyrics on tracks with vocals.");
        }
        if !heart && (dataset.items.is_empty() || dataset.items.iter().any(|item| !item.instrumental || item.style.trim().is_empty())) {
            bail!("Stable Audio 3 training needs instrumental songs with a style description on every song.");
        }
        let mut active = self.active.write().await;
        if active.is_some() {
            bail!("a training run is already going");
        }
        let run_id = new_id();
        let run_dir = self.run_dir(&run_id)?;
        let input_audio = self.dataset_dir(&dataset.id)?.join("audio");
        let stages = if heart { sa3::heart_stages(&models, &run_dir, &settings) } else { vec![sa3::stage(&models, &run_dir, &settings)] };
        let stage_names = std::iter::once("prepare").chain(stages.iter().map(|stage| stage.id)).map(str::to_owned).collect();
        let step_goal = settings.steps;
        let run = Run {
            id: run_id.clone(),
            engine: "hotstep".into(),
            dataset_id: dataset.id.clone(),
            dataset_name: dataset.name.clone(),
            name: if name.trim().is_empty() { dataset.name.clone() } else { name.trim().into() },
            trigger: String::new(),
            recipe: Recipe {
                preset: if heart { "hotstep-heartmula" } else { "hotstep-sa3" }.into(),
                stop: "steps".into(),
                steps: settings.steps,
                rank: settings.rank,
                alpha: settings.alpha,
                learning_rate: settings.learning_rate,
                seed: settings.seed,
                lyric_timing: false,
                ..Recipe::default()
            },
            trainer: None,
            training_base: None,
            status: RunStatus::Running,
            stage: Some("prepare".into()),
            stages: stage_names,
            steps: Vec::new(),
            error: None,
            created_at: now(),
            finished_at: None,
            installed: Vec::new(),
            continuations: Vec::new(),
            output_adapter: None,
            hotstep_sa3_settings: (!heart).then(|| settings.clone()),
            hotstep_heartmula_settings: heart.then_some(settings),
            rvc_burn_settings: None,
            rvc_voice_id: None,
        };
        self.save_run(&run)?;
        let cancel = Arc::new(tokio::sync::Notify::new());
        *active = Some(Active { run_id: run_id.clone(), cancel: cancel.clone() });
        drop(active);
        let training = self.clone();
        tokio::spawn(async move {
            (card.take)().await;
            let outcome = async {
                let stop = Arc::new(AtomicBool::new(false));
                let (manifest_models, manifest_run, stopped) = (models.clone(), run_dir.clone(), stop.clone());
                let mut preparing = tokio::task::spawn_blocking(move || {
                    if heart { sa3::heart_manifest(&manifest_run, &input_audio, &dataset) }
                    else { sa3::dataset_manifest(&manifest_models, &manifest_run, &input_audio, &dataset, &stopped) }
                });
                tokio::select! {
                    prepared = &mut preparing => prepared??,
                    _ = cancel.notified() => {
                        stop.store(true, Ordering::Relaxed);
                        let _ = preparing.await;
                        return Ok(false);
                    }
                }
                if !training.work(&trainer, None, &run_dir, &run_id, stages, cancel).await? {
                    return Ok(false);
                }
                let (path, id) = (run_dir.clone(), run_id.clone());
                let name = tokio::task::spawn_blocking(move || if heart { sa3::publish_heart(&models, &path, &id, step_goal) } else { sa3::publish(&models, &path, &id) }).await??;
                let _edit = training.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
                let mut finished = training.run(&run_id)?;
                finished.output_adapter = Some(name);
                finished.installed.push(step_goal);
                training.save_run(&finished)?;
                Ok(true)
            }.await;
            training.settle(&run_id, outcome, (card.give_back)()).await;
        });
        Ok(run)
    }

    /// Uses the existing run scheduler for the native RVC voice trainer.
    pub(super) async fn start_rvc_burn(
        self: &Arc<Self>,
        runtime: crate::rvc_burn::Runtime,
        dataset_id: &str,
        name: &str,
        settings: crate::rvc_burn::Settings,
        card: CardHooks,
    ) -> Result<Run> {
        let dataset = self.dataset(dataset_id)?;
        let audio = self.dataset_dir(dataset_id)?.join("audio");
        let clips = dataset.items.iter().filter(|item| !item.instrumental).map(|item| {
            let name = Path::new(&item.file);
            if name.components().count() != 1 || !matches!(name.components().next(), Some(std::path::Component::Normal(_))) {
                bail!("Invalid RVC recording filename.");
            }
            let path = audio.join(name);
            if !path.is_file() { bail!("Recording does not exist: {}", item.title); }
            Ok(path)
        }).collect::<Result<Vec<_>>>()?;
        if clips.is_empty() { bail!("Add at least one isolated voice recording to the dataset."); }
        let mut active = self.active.write().await;
        if active.is_some() { bail!("a training run is already going"); }
        let run_id = new_id();
        let run_dir = self.run_dir(&run_id)?;
        std::fs::create_dir_all(run_dir.join("rvc-output"))?;
        // Keep the files available if the dataset changes while the trainer
        // reads them. Its CLI takes file arguments, relative to the run folder.
        let inputs = tempfile::Builder::new().prefix("rvc-").tempdir_in(&run_dir)?;
        let mut staged_clips = Vec::with_capacity(clips.len());
        for (index, path) in clips.into_iter().enumerate() {
            let target = inputs.path().join(format!("{index}.wav"));
            if std::fs::hard_link(&path, &target).is_err() {
                std::fs::copy(&path, &target)?;
            }
            staged_clips.push(target.strip_prefix(&run_dir)?.to_owned());
        }
        let stage = runtime.training_stage(staged_clips, &run_dir, &settings);
        let run = Run {
            id: run_id.clone(), engine: crate::rvc_burn::STAGE.into(),
            dataset_id: dataset.id, dataset_name: dataset.name.clone(),
            name: if name.trim().is_empty() { dataset.name } else { name.trim().to_owned() },
            trigger: String::new(),
            recipe: Recipe { preset:"rvc-burn".into(), stop:"epochs".into(), epochs:settings.epochs,
                grad_accum:settings.batch_size, learning_rate:settings.learning_rate, steps:0, ..Recipe::default() },
            trainer: None,
            training_base: None,
            status: RunStatus::Running, stage:Some(stage.id.into()), stages:vec![stage.id.into()],
            steps:vec![], error:None, created_at:now(), finished_at:None,
            installed:vec![], continuations:vec![], output_adapter:None, hotstep_sa3_settings:None,
            hotstep_heartmula_settings:None, rvc_burn_settings:Some(settings), rvc_voice_id:None,
        };
        self.save_run(&run)?;
        let cancel = Arc::new(tokio::sync::Notify::new());
        *active = Some(Active { run_id:run_id.clone(), cancel:cancel.clone() });
        drop(active);
        let training = self.clone();
        tokio::spawn(async move {
            (card.take)().await;
            let outcome = training.work(&runtime.exe, None, &run_dir, &run_id, vec![stage], cancel).await
                .and_then(|done| {
                    if done && !run_dir.join(crate::rvc_burn::CHECKPOINT).is_file() {
                        bail!("RVC Burn completed without exporting a voice.");
                    }
                    Ok(done)
                });
            drop(inputs);
            training.settle(&run_id, outcome, (card.give_back)()).await;
        });
        Ok(run)
    }

    pub(super) fn rvc_burn_checkpoint(&self, id: &str) -> Result<PathBuf> {
        let run = self.run(id)?;
        let root = self.run_dir(id)?;
        let path = if run.status == RunStatus::Done { root.join(crate::rvc_burn::CHECKPOINT) }
            else if let Some(saved) = crate::rvc_burn::best_snapshot(&root) { saved.join("voice.safetensors") }
            else { root.join("rvc-output/checkpoint/voice.best.safetensors") };
        if !path.is_file() { bail!("This RVC run has no saved voice."); }
        Ok(path)
    }

    pub(super) fn rvc_burn_best(&self, id: &str) -> Option<serde_json::Value> {
        let root = self.run_dir(id).ok()?;
        crate::rvc_burn::best_snapshot(&root)
            .and_then(|saved| read_json(&saved.join("best.json")))
            .or_else(|| {
                if self.run(id).ok()?.status == RunStatus::Running { return None; }
                read_json(&root.join("rvc-output/checkpoint/voice.best.json"))
            })
    }

    pub(super) fn record_rvc_burn_voice(&self, id: &str, voice: &str) -> Result<()> {
        let _edit = self.edits.lock().unwrap_or_else(|error| error.into_inner());
        let mut run = self.run(id)?;
        run.rvc_voice_id = Some(voice.to_owned());
        self.save_run(&run)
    }

    /// Where a run can be trained further from, or which [`RESUME_REFUSALS`]
    /// keeps it from going on.
    pub fn resume_point(&self, run_id: &str) -> Result<(u32, PathBuf), &'static str> {
        let dir = self.run_dir(run_id).map_err(|_| "no_run")?;
        if !dir.join("prepared").join("dataset.json").is_file() {
            return Err("prepared_gone");
        }
        yue_train::resume_point(&dir).ok_or("no_checkpoint")
    }

    /// Trains a run further, up to `steps` in all, from its latest checkpoint:
    /// the same recipe, the same prepared songs, the steps and the chart go on
    /// where they stopped. Stops by steps only - a likeness target would be
    /// judged on a window the resumed trainer starts empty.
    pub async fn continue_run(self: &Arc<Self>, libraries: Option<PathBuf>, companion: PathBuf, run_id: &str, steps: u32, card: CardHooks) -> Result<Run> {
        let saved = self.run(run_id)?;
        let (trainer, trainer_identity) = self.select_trainer(None, saved.trainer.as_ref(), true).await?;
        let (checkpoint, training_base) = self.resolve_training_base(None, saved.training_base.as_ref(), &companion, None).await?;
        let (from, state) = self.resume_point(run_id).map_err(|code| anyhow::anyhow!(refusal(code)))?;
        if steps <= from {
            bail!("set the steps above {from}, the checkpoint the run goes on from");
        }
        let mut active = self.active.write().await;
        if active.is_some() {
            bail!("a training run is already going");
        }
        let run_dir = self.run_dir(run_id)?;
        let edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut run = self.run(run_id)?;
        let mut recipe = run.recipe.clone();
        recipe.steps = steps;
        recipe.target_kl = 0.0;
        recipe.stop = "kl".into();
        let output = run_dir.join(format!("output-{}", new_id()));
        let stage = yue_train::continuation_stage(&checkpoint, &companion, &run_dir, &recipe, &output, &state);
        run.recipe = recipe;
        run.trainer = Some(trainer_identity);
        run.training_base = Some(training_base);
        run.status = RunStatus::Running;
        run.stage = None;
        run.stages = vec![stage.id.to_string()];
        run.error = None;
        run.finished_at = None;
        // steps past the checkpoint are trained again; the chart keeps the new ones
        run.steps.retain(|record| record.step <= from);
        run.continuations.push(Continuation { from, to: steps, at: now() });
        self.save_run(&run)?;
        drop(edit);
        let cancel = Arc::new(tokio::sync::Notify::new());
        *active = Some(Active { run_id: run_id.to_string(), cancel: cancel.clone() });
        drop(active);

        let training = self.clone();
        let run_id = run_id.to_string();
        tokio::spawn(async move {
            (card.take)().await;
            let outcome = training.work(&trainer, libraries.as_deref(), &run_dir, &run_id, vec![stage], cancel).await;
            training.settle(&run_id, outcome, (card.give_back)()).await;
        });
        Ok(run)
    }

    /// Records how a run ended and lets the next one start.
    async fn settle(&self, run_id: &str, outcome: Result<bool>, restore_engine: impl std::future::Future<Output = ()>) {
        // Restoring the engine can restart its process. Keep the card reserved
        // until then so a song submitted after training survives that restart.
        restore_engine.await;
        if let Some(ended) = self.ended.get() {
            match &outcome {
                Ok(true) => ended(Ok(()), false),
                Ok(false) => ended(Err("stopped".to_string()), true),
                Err(error) => ended(Err(format!("{error:#}")), false),
            }
        }
        {
            let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
            if let Ok(mut run) = self.run(run_id) {
                run.finished_at = Some(now());
                match outcome {
                    Ok(true) => {
                        run.status = RunStatus::Done;
                        run.stage = None;
                    }
                    Ok(false) => run.status = RunStatus::Cancelled,
                    Err(error) => {
                        run.status = RunStatus::Failed;
                        run.error = Some(format!("{error:#}"));
                    }
                }
                let _ = self.save_run(&run);
            }
        }
        *self.active.write().await = None;
    }

    /// Separates the vocals still missing, one song at a time; the result is
    /// kept with the dataset, so the next run and lyric recognition reuse it.
    async fn separate_vocals(&self, run_id: &str, separator: Option<Arc<dyn VocalSeparator>>, missing: Vec<(PathBuf, PathBuf)>, cancel: Arc<tokio::sync::Notify>) -> Result<bool> {
        if missing.is_empty() {
            return Ok(true);
        }
        {
            let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
            let mut run = self.run(run_id)?;
            run.stage = Some(VOCALS_STAGE.into());
            self.save_run(&run)?;
        }
        let Some(separator) = separator else { return Ok(true) };
        for (mix, out) in missing {
            let separator = separator.clone();
            let mut job = tokio::task::spawn_blocking(move || -> Result<()> {
                let folder = out.parent().context("vocals folder")?;
                std::fs::create_dir_all(folder)?;
                let partial = folder.join(format!("vocals.{}.part.wav", new_id()));
                let separated = separator.separate(&mix, &partial).and_then(|()| Ok(std::fs::rename(&partial, &out)?));
                if separated.is_err() {
                    let _ = std::fs::remove_file(&partial);
                }
                separated
            });
            tokio::select! {
                done = &mut job => done.context("vocal separation")?.context("separating the vocals")?,
                _ = cancel.notified() => {
                    // the separator cannot be stopped mid-song; the run ends
                    // once it has let go of the card
                    let _ = job.await;
                    return Ok(false);
                }
            }
        }
        Ok(true)
    }

    /// Runs the stages in order; `Ok(false)` when cancelled.
    async fn work(&self, trainer: &Path, libraries: Option<&Path>, run_dir: &Path, run_id: &str, stages: Vec<yue_train::TrainingStage>, cancel: Arc<tokio::sync::Notify>) -> Result<bool> {
        use tokio::io::AsyncWriteExt;
        let mut log = tokio::fs::OpenOptions::new().create(true).append(true).open(run_dir.join("run.log")).await?;
        for stage in stages {
            #[cfg(windows)]
            let stage = joint_checkpoint_paths(stage)?;
            let signed_trainer = {
                let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
                let mut run = self.run(run_id)?;
                run.stage = Some(stage.id.to_string());
                self.save_run(&run)?;
                run.trainer.is_some_and(|trainer| trainer.generation.is_some())
            };
            log.write_all(format!("==== {}\n", stage.id).as_bytes()).await?;
            let cuda12_runtime = (cfg!(windows) && !signed_trainer
                && (trainer == self.downloader.runtime_dir(trainer_folder()).join(&trainer_source().shipped_as)
                    || trainer == self.previous_trainer())
                && crate::trainer_cuda_build() == Some(crate::hardware::CudaBuild::Cuda12))
                .then(|| -> Result<_> {
                    let asset = cuda12_backend();
                    if !self.downloader.is_installed(asset) {
                        bail!("Install the HOT-Step CUDA 12 backend from the training pack");
                    }
                    let directory = tempfile::Builder::new().prefix("cuda12-trainer-").tempdir_in(run_dir)?;
                    let backend = self.downloader.runtime_dir(&trainer_source().cuda12_backend_tag).join(asset.marker);
                    let executable = stage_cuda12_trainer(trainer, &backend, directory.path())?;
                    Ok((directory, executable))
                }).transpose()?;
            let trainer = cuda12_runtime.as_ref().map_or(trainer, |(_, executable)| executable.as_path());
            // A signed generation declares its dependencies and is verified again on resume.
            if !signed_trainer {
                music_core::process::runtime_beside(trainer);
            }
            let mut command = tokio::process::Command::new(trainer);
            if let Some(path) = music_core::process::own_libraries_first(trainer) {
                command.env("LD_LIBRARY_PATH", path);
            }
            dub_core::proc::outside_appimage(command.as_std_mut());
            command
                .args(&stage.args)
                .current_dir(run_dir)
                .stdin(std::process::Stdio::null())
                .stdout(std::process::Stdio::piped())
                .stderr(std::process::Stdio::piped())
                .kill_on_drop(true);
            if let Some(libraries) = libraries {
                let mut paths = vec![std::path::PathBuf::from(libraries.as_os_str())];
                paths.extend(std::env::var_os("PATH").iter().flat_map(std::env::split_paths));
                if let Ok(path) = std::env::join_paths(paths) {
                    command.env("PATH", path);
                }
            }
            // The pack carries ggml's processor builds beside CUDA; without this
            // a card whose CUDA does not load would train on the processor.
            command.env("GGML_BACKEND", "CUDA0");
            if stage.id == crate::rvc_burn::STAGE {
                let folder = trainer.parent().context("RVC Burn runtime folder")?.to_owned();
                command.envs(crate::rvc_burn::Runtime::from_folder(folder).environment(run_dir));
            }
            #[cfg(windows)]
            command.creation_flags(0x0800_0000);
            let mut child = command.spawn().with_context(|| format!("start {}", trainer.display()))?;
            let stdout = child.stdout.take().context("trainer output")?;
            let stderr = child.stderr.take().context("trainer errors")?;
            let (lines_out, mut lines_in) = tokio::sync::mpsc::unbounded_channel::<String>();
            for stream in [Box::new(stdout) as Box<dyn tokio::io::AsyncRead + Unpin + Send>, Box::new(stderr)] {
                let lines_out = lines_out.clone();
                tokio::spawn(async move {
                    let mut lines = BufReader::new(stream).split(b'\n');
                    while let Ok(Some(bytes)) = lines.next_segment().await {
                        let bytes = bytes.strip_suffix(b"\r").unwrap_or(&bytes);
                        if lines_out.send(String::from_utf8_lossy(bytes).into_owned()).is_err() {
                            break;
                        }
                    }
                });
            }
            drop(lines_out);
            *self.step_stages.lock().unwrap_or_else(|poisoned| poisoned.into_inner()) = yue_train::StepStages::default();
            self.f32_path.store(false, std::sync::atomic::Ordering::Relaxed);
            let pid = child.id();
            let mut failure = TrainerFailure::default();
            let status = loop {
                tokio::select! {
                    line = lines_in.recv() => match line {
                        Some(line) => {
                            log.write_all(line.as_bytes()).await?;
                            log.write_all(b"\n").await?;
                            if stage.id == crate::rvc_burn::STAGE
                                && let Some((step, mel)) = crate::rvc_burn::best_report(&line)
                            {
                                let run_dir = run_dir.to_owned();
                                let snapshot = tokio::task::spawn_blocking(move || crate::rvc_burn::snapshot_best(&run_dir, step, mel)).await;
                                if let Err(error) = snapshot.map_err(anyhow::Error::from).and_then(|result| result) {
                                    log.write_all(format!("[studio] the previous RVC checkpoint was kept: {error:#}\n").as_bytes()).await?;
                                }
                            }
                            let step = if stage.id == crate::rvc_burn::STAGE {
                                crate::rvc_burn::progress(&line).map(|(total, step)| {
                                    let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
                                    if let Ok(mut run) = self.run(run_id)
                                        && run.recipe.steps != total
                                    {
                                        run.recipe.steps = total;
                                        let _ = self.save_run(&run);
                                    }
                                    step
                                })
                            } else if stage.id == crate::hotstep_sa3_training::STAGE {
                                crate::hotstep_sa3_training::progress(&line)
                            } else if stage.id == crate::hotstep_sa3_training::HEART_STAGE {
                                crate::hotstep_sa3_training::heart_progress(&line)
                            } else {
                                yue_train::parse_training_step(&line).map(Into::into)
                            };
                            if let Some(step) = step {
                                let recorded = {
                                    let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
                                    self.append_step(run_id, step)
                                };
                                if let Err(error) = recorded {
                                    log.write_all(format!("[studio] the step was not recorded: {error:#}\n").as_bytes()).await?;
                                }
                            } else if let Some((step, stage)) = yue_train::parse_step_stage(&line) {
                                self.step_stages.lock().unwrap_or_else(|poisoned| poisoned.into_inner()).started(step, stage, unix_millis());
                            } else if yue_train::takes_f32_path(&line) {
                                self.f32_path.store(true, std::sync::atomic::Ordering::Relaxed);
                            } else {
                                failure.observe(&line);
                            }
                        }
                        None => break child.wait().await?,
                    },
                    _ = cancel.notified() => {
                        let _ = child.kill().await;
                        return Ok(false);
                    }
                }
            };
            if !status.success() {
                let mut last_error = failure.message();
                if last_error.contains("GGML_BACKEND=CUDA0 not found") {
                    if matches!(stage.id, crate::hotstep_sa3_training::STAGE | crate::hotstep_sa3_training::HEART_STAGE | crate::hotstep_sa3_training::HEART_PREPARE) {
                        bail!("HOT-Step CUDA did not load; check the NVIDIA driver and the pinned CUDA 12 runtime.");
                    }
                    bail!("{} stopped: the trainer's CUDA did not load on the graphics card, and training does not run on the processor; it needs NVIDIA driver {} or newer", stage.id, crate::hardware::CUDA13_DRIVER);
                }
                // a crash says where it happened only in Windows' record of it
                if last_error.is_empty() || music_core::process::exited_on_exception(status.code()) {
                    if let Some(pid) = pid {
                        let fault = tokio::task::spawn_blocking(move || music_core::process::fault_of(pid, std::time::Duration::from_secs(5))).await.ok().flatten();
                        if let Some(fault) = fault {
                            last_error = if last_error.is_empty() { fault.to_string() } else { format!("{last_error} | {fault}") };
                        }
                    }
                }
                bail!("{} stopped ({status}){}", stage.id, if last_error.is_empty() { String::new() } else { format!(": {last_error}") });
            }
        }
        Ok(true)
    }

    pub async fn cancel(&self, run_id: &str) -> Result<()> {
        let active = self.active.read().await;
        match active.as_ref() {
            Some(active) if active.run_id == run_id => {
                active.cancel.notify_one();
                Ok(())
            }
            _ => bail!("run {run_id} is not going"),
        }
    }

    pub fn mark_installed(&self, run_id: &str, step: u32) -> Result<()> {
        let _edit = self.edits.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut run = self.run(run_id)?;
        if !run.installed.contains(&step) {
            run.installed.push(step);
        }
        self.save_run(&run)
    }

    pub async fn remove_run(&self, run_id: &str) -> Result<()> {
        if self.active_run().await.as_deref() == Some(run_id) {
            bail!("stop the run before removing it");
        }
        let dir = self.run_dir(run_id)?;
        if !dir.join("run.json").is_file() {
            bail!("no training run {run_id}");
        }
        std::fs::remove_dir_all(dir)?;
        Ok(())
    }
}

/// Why a run cannot be trained further, by the code the page translates.
fn refusal(code: &str) -> &'static str {
    match code {
        "prepared_gone" => "the prepared songs of this run are gone; train it again from the dataset",
        "no_checkpoint" => "this run saved no checkpoint to continue from",
        _ => "no such training run",
    }
}

/// What an edit of a dataset song may change.
#[derive(Debug, Clone, Default, Deserialize)]
pub struct ItemPatch {
    pub title: Option<String>,
    pub artist: Option<String>,
    pub lyrics_source: Option<String>,
    pub style: Option<String>,
    pub lyrics: Option<String>,
    pub instrumental: Option<bool>,
    /// Set by the preparation, never by the page.
    #[serde(skip)]
    pub lyrics_state: Option<LyricsState>,
    #[serde(skip)]
    pub style_state: Option<StyleState>,
    #[serde(skip)]
    pub heard: Option<Option<HeardNote>>,
}

/// One song of a cue sheet.
#[derive(Debug, Clone, PartialEq)]
pub struct CueTrack {
    pub title: String,
    /// The track's own performer, or the sheet's.
    pub performer: String,
    /// Where the song starts in the album file, in seconds.
    pub start: f64,
}

/// A cue sheet: the audio file it describes and the songs in it. Rippers
/// write them in the system code page as often as in UTF-8.
pub fn cue_sheet(bytes: &[u8]) -> (Option<String>, Vec<CueTrack>) {
    cue_sheet_text(&crate::legacy_text::decode(bytes))
}

fn cue_sheet_text(text: &str) -> (Option<String>, Vec<CueTrack>) {
    let mut sheet_performer = String::new();
    let mut performer: Option<String> = None;
    let quoted = |rest: &str| rest.trim().trim_matches('"').to_string();
    let mut file = None;
    let mut tracks: Vec<CueTrack> = Vec::new();
    let mut title: Option<String> = None;
    let mut in_track = false;
    for line in text.lines() {
        let line = line.trim();
        let (command, rest) = line.split_once(' ').unwrap_or((line, ""));
        match command.to_ascii_uppercase().as_str() {
            "FILE" if file.is_none() => {
                let rest = rest.trim();
                let name = match rest.strip_prefix('"') {
                    Some(inner) => inner.split('"').next().unwrap_or_default().to_string(),
                    None => rest.rsplit_once(' ').map_or(rest, |(name, _)| name).to_string(),
                };
                file = Some(name);
            }
            "TRACK" => {
                in_track = true;
                title = None;
                performer = None;
            }
            "TITLE" if in_track => title = Some(quoted(rest)),
            "PERFORMER" if in_track => performer = Some(quoted(rest)),
            "PERFORMER" => sheet_performer = quoted(rest),
            "INDEX" if in_track => {
                let mut parts = rest.split_whitespace();
                if parts.next() == Some("01") {
                    let stamp: Vec<f64> = parts.next().unwrap_or_default().split(':').filter_map(|part| part.parse().ok()).collect();
                    if let [minutes, seconds, frames] = stamp[..] {
                        let number = tracks.len() + 1;
                        tracks.push(CueTrack {
                            title: title.clone().filter(|title| !title.is_empty()).unwrap_or_else(|| format!("{number:02}")),
                            performer: performer.clone().filter(|performer| !performer.is_empty()).unwrap_or_else(|| sheet_performer.clone()),
                            start: minutes * 60.0 + seconds + frames / 75.0,
                        });
                    }
                }
            }
            _ => {}
        }
    }
    (file, tracks)
}

/// Artist and title of an audio file: its own tags first, then its name,
/// then the folders it was dropped in. `relative` is the path inside what
/// was dropped ("Artist/2011 - Album/01. Title.flac"), or just the file name.
pub fn identify(path: &Path, relative: &str) -> (String, String) {
    let tags = crate::audio_pcm::tags(path);
    let parts: Vec<&str> = relative.split(['/', '\\']).filter(|part| !part.is_empty()).collect();
    let stem = parts.last().map(|name| Path::new(name).file_stem().and_then(|stem| stem.to_str()).unwrap_or(name)).unwrap_or_default();
    let (named_artist, named_title) = split_file_name(stem);
    let folders = if parts.len() > 1 { &parts[..parts.len() - 1] } else { &[][..] };
    let tag_artist = Some(tags.artist.trim().to_string()).filter(|artist| !artist.is_empty() && !is_various(artist));
    let artist = tag_artist.or(named_artist).or_else(|| artist_from_folders(folders)).unwrap_or_default();
    let title = Some(tags.title.trim().to_string()).filter(|title| !title.is_empty()).unwrap_or(named_title);
    (artist, title)
}

fn is_various(artist: &str) -> bool {
    matches!(artist.trim().to_lowercase().as_str(), "various artists" | "various" | "va" | "v.a." | "сборник" | "разные исполнители")
}

fn dash_split(text: &str) -> Vec<String> {
    let dashes = regex::Regex::new(r"\s+[-–—]\s+").expect("valid regex");
    dashes.split(text).map(|part| part.trim().to_string()).filter(|part| !part.is_empty()).collect()
}

/// "01 Title", "12. Title", "A3 - Title" lose their track number; "99 Luftballons"
/// keeps its own: a number followed by a bare space is a track number only
/// when it is zero-padded or three digits (disc and track).
fn without_track_number(text: &str) -> String {
    static NUMBER: std::sync::LazyLock<regex::Regex> = std::sync::LazyLock::new(|| regex::Regex::new(r"^\s*(?:[A-Da-d]?\d{1,3}\s*[.)_\-–]\s*|[A-Da-d]?0\d\s+|\d{3}\s+)").expect("valid regex"));
    let stripped = NUMBER.replace(text, "").trim().to_string();
    if stripped.is_empty() { text.trim().to_string() } else { stripped }
}

/// "01. Artist - Title", "Artist - Album - 06 Title", "03 - Title", "Title".
fn split_file_name(stem: &str) -> (Option<String>, String) {
    let spaced = if stem.contains(' ') { stem.to_string() } else { stem.replace('_', " ") };
    let bare = without_track_number(&spaced);
    let parts = dash_split(&bare);
    match parts.len() {
        0 => (None, bare),
        1 => (None, parts[0].clone()),
        _ => {
            let artist = parts[0].clone();
            let title = without_track_number(parts.last().expect("two parts or more"));
            if artist.chars().all(|c| c.is_ascii_digit()) { (None, title) } else { (Some(artist), title) }
        }
    }
}

/// The artist the folders name, nearest first: "Artist - 2019 - Album",
/// "(2004) Artist - Album", "Artist - Album", "Artist - Discography"; a plain
/// name above an album folder is the artist, unless it names a collection.
fn artist_from_folders(folders: &[&str]) -> Option<String> {
    let brackets = regex::Regex::new(r"\s*[\(\[][^\)\]]*[\)\]]").expect("valid regex");
    let year_first = regex::Regex::new(r"^[\(\[]?\d{4}[\)\]]?(?:\s*[-–—.]\s*|\s+)").expect("valid regex");
    let disc = regex::Regex::new(r"(?i)^(cd|disc|disk|диск)\s*\d+$").expect("valid regex");
    let collection = regex::Regex::new(r"(?i)сборник|трибьют|коллекц|любимые|плейлист|collection|compilation|favorit|playlist|singles|soundtrack|\bost\b|best of|music|lossless|flac|mp3|downloads|spoty|spotify").expect("valid regex");
    let mut under_album = false;
    for folder in folders.iter().rev() {
        let original = folder.trim();
        // "(2004) Sirenia - Album": the year comes first, the artist after it
        if let Some(found) = year_first.find(original) {
            let rest = &original[found.end()..];
            let parts: Vec<String> = dash_split(&brackets.replace_all(rest, "")).into_iter().filter(|part| !disc.is_match(part)).collect();
            if parts.len() >= 2 && !parts[0].chars().all(|c| c.is_ascii_digit()) && !collection.is_match(&parts[0]) {
                return Some(parts[0].clone());
            }
            under_album = true;
            continue;
        }
        let clean = brackets.replace_all(original, "").trim().to_string();
        if clean.is_empty() || disc.is_match(&clean) {
            under_album = true;
            continue;
        }
        let parts = dash_split(&clean);
        if parts.len() >= 2 {
            if !parts[0].chars().all(|c| c.is_ascii_digit()) && !collection.is_match(&parts[0]) {
                return Some(parts[0].clone());
            }
            continue;
        }
        let words = clean.split_whitespace().count();
        if collection.is_match(&clean) || words > 4 {
            continue;
        }
        if under_album || folders.len() == 1 || std::ptr::eq(folder, &folders[0]) {
            return Some(clean);
        }
    }
    None
}


/// Lyrics from a `.txt` or `.lrc` file: time stamps and word timings removed,
/// metadata tags such as `[ar:...]` dropped, section tags kept.
pub fn plain_lyrics(text: &str) -> String {
    let mut out = Vec::new();
    for line in text.lines() {
        let mut rest = line.trim();
        while let Some(stripped) = rest.strip_prefix('[') {
            let Some(end) = stripped.find(']') else { break };
            let tag = &stripped[..end];
            let timed = tag.chars().next().is_some_and(|c| c.is_ascii_digit());
            let meta = tag.contains(':') && !timed;
            if !(timed || meta) {
                break;
            }
            rest = stripped[end + 1..].trim_start();
        }
        let mut clean = String::new();
        let mut inside = false;
        for c in rest.chars() {
            match c {
                '<' => inside = true,
                '>' if inside => inside = false,
                _ if !inside => clean.push(c),
                _ => {}
            }
        }
        out.push(clean.trim().to_string());
    }
    out.join("\n").trim().to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn independently_installed_bases_do_not_share_the_stock_path() {
        let stock = Training::training_base_asset(STOCK_BASE).unwrap();
        let tw = Training::training_base_asset(RUACH_TW_BASE).unwrap();
        let fw = Training::training_base_asset(RUACH_FW_BASE).unwrap();
        assert_ne!(stock.relative_path, tw.relative_path);
        assert_ne!(tw.relative_path, fw.relative_path);
        assert!(base_asset_sha(tw.url).is_some());
        let identity = TrainingBaseIdentity {
            id: RUACH_TW_BASE.into(),
            checkpoint_sha256: base_asset_sha(tw.url).unwrap().into(),
            companion_sha256: "decoder".into(),
            own_backbone_sha256: None,
        };
        assert!(identity.matching_backbone("24d965f6f63656b55e5ff6f004627235b708293e2af9058feb162448197f83c4"));
        assert!(!identity.matching_backbone("41121ce97786d7795a325bcf123ca196956c03bb252c9e75384cfc1f2fc19e6b"));
        assert!(!identity.matching_backbone("25793826e9f28c8894b4f7c7f6d3ed54256cf1fcc1966030ac7b1b6a5918baf3"));
    }

    #[test]
    fn own_base_identifiers_stay_in_the_training_folder() {
        let root = tempfile::tempdir().unwrap();
        let training = Training::new(root.path(), "yue2");
        fs::write(training.own_bases_directory().join("local.safetensors"), b"fixture").unwrap();
        assert!(training.own_base_file("own:local.safetensors").is_ok());
        assert!(training.own_base_file("own:../local.safetensors").is_err());
        assert!(training.own_base_file("own:local.gguf").is_err());
    }

    #[test]
    fn the_trainer_says_what_it_computes_on() {
        assert_eq!(trainer_device("x\n[Load] YuE2 backend: CUDA0 (shared)\nstep 1"), Some("CUDA0".into()));
        assert_eq!(trainer_device("[Load] VAE-Enc backend: CPU (CPU threads: 16)"), Some("CPU".into()));
        assert_eq!(
            trainer_device("[Load] CondEncoder backend: CUDA0 (shared)\n[Load] DiT backend: CPU (CPU threads: 16)\n[Load] DiT: 32 layers"),
            Some("CUDA0".into()),
            "the base kept in memory is not what the trainer computes on"
        );
        assert_eq!(trainer_device("[Load] DiT backend: CPU (CPU threads: 16)"), None);
        assert_eq!(trainer_device("nothing yet"), None);
    }

    /// The trainer's cleanup keeps the transcriber's CUDA 12.9 and processor
    /// builds of today's release, and takes every folder of an earlier one.
    #[test]
    fn the_cuda12_trainer_stages_its_backend_without_changing_originals() {
        let fixture = tempfile::tempdir().unwrap();
        let original = fixture.path().join("original");
        let staged = fixture.path().join("staged");
        std::fs::create_dir(&original).unwrap();
        std::fs::create_dir(&staged).unwrap();
        for (name, bytes) in [
            ("music-train.exe", "trainer"),
            ("music-midi.exe", "midi"),
            ("ggml.dll", "shared"),
            ("ggml-base.dll", "base"),
            ("ggml-cpu-x64.dll", "cpu"),
            ("ggml-cuda.dll", "cuda13"),
        ] {
            std::fs::write(original.join(name), bytes).unwrap();
        }
        let backend = fixture.path().join("cuda12.dll");
        std::fs::write(&backend, "cuda12").unwrap();

        let executable = stage_cuda12_trainer(&original.join("music-train.exe"), &backend, &staged).unwrap();
        assert_eq!(std::fs::read_to_string(executable).unwrap(), "trainer");
        assert_eq!(std::fs::read_to_string(staged.join("ggml-cuda.dll")).unwrap(), "cuda12");
        assert_eq!(std::fs::read_to_string(staged.join("ggml-cpu-x64.dll")).unwrap(), "cpu");
        assert!(!staged.join("music-midi.exe").exists());
        assert_eq!(std::fs::read_to_string(original.join("ggml-cuda.dll")).unwrap(), "cuda13");
    }

    #[test]
    fn todays_tool_folders_stay_and_earlier_releases_go() {
        let root = std::env::temp_dir().join(format!("yue-tool-folders-{}", uuid::Uuid::now_v7()));
        let shared = root.join("hotstep");
        let downloader = Downloader::with_runtimes(root.join("training"), shared.clone());
        for name in ["hotstep-tools-75923e70-xcr0", "hotstep-tools-75923e70-xcr0-midi-cuda12", "hotstep-tools-75923e70-xcr0-midi-cpu", "hotstep-tools-75923e70", "hotstep-tools-2ef93a1c-midi-cpu", "hotstep-tools-local"] {
            std::fs::create_dir_all(shared.join(name)).unwrap();
        }
        remove_older_tool_folders(&downloader, "hotstep-tools-75923e70-xcr0", None, "music-train");
        let mut left: Vec<String> = std::fs::read_dir(&shared).unwrap().flatten().map(|entry| entry.file_name().to_string_lossy().into_owned()).collect();
        left.sort();
        assert_eq!(left, ["hotstep-tools-75923e70-xcr0", "hotstep-tools-75923e70-xcr0-midi-cpu", "hotstep-tools-75923e70-xcr0-midi-cuda12", "hotstep-tools-local"]);
        std::fs::remove_dir_all(&root).ok();
    }

    #[tokio::test]
    async fn upgrading_an_already_installed_trainer_preserves_training_inputs() {
        let data = tempfile::tempdir().unwrap();
        let training = Training::new(data.path(), "yue2");
        let old = tools_root(data.path()).join("hotstep-tools-2ef93a1c");
        std::fs::create_dir_all(&old).unwrap();
        let checkpoint = training.runs_dir().join("previous-run/checkpoints/step-42.safetensors");
        std::fs::create_dir_all(checkpoint.parent().unwrap()).unwrap();
        std::fs::write(&checkpoint, b"resume from step 42").unwrap();
        let trainer = pack().iter().find(|asset| asset.id == "music-train").unwrap();
        for asset in pack().iter().filter(|asset| asset.kind == AssetKind::Model) {
            let file = training.downloader.path_of(asset);
            std::fs::create_dir_all(file.parent().unwrap()).unwrap();
            std::fs::write(file, b"existing weights").unwrap();
        }
        let managed = training.downloader.runtime_dir(trainer_folder()).join(trainer.marker);
        std::fs::create_dir_all(managed.parent().unwrap()).unwrap();
        std::fs::write(&managed, b"current trainer").unwrap();
        training.remove_older_trainers();
        assert!(old.exists(), "an unpacked marker alone cannot retire the previous runtime");
        crate::install_record::write(
            &training.downloader.record_of(trainer), trainer.url, "", &[managed.clone()], &training.downloader.root(),
        ).unwrap();

        let restarted = Training::new(data.path(), "yue2");
        assert!(!old.exists(), "a verified replacement retires the old runtime at startup");
        assert!(restarted.pack_ready());
        std::fs::create_dir_all(&old).unwrap();
        restarted.install_pack().await.unwrap();
        assert!(!old.exists(), "repeat install takes the local ready path and retires old files");
        assert_eq!(std::fs::read(managed).unwrap(), b"current trainer");
        assert_eq!(std::fs::read(checkpoint).unwrap(), b"resume from step 42");
        for asset in pack().iter().filter(|asset| asset.kind == AssetKind::Model) {
            assert_eq!(std::fs::read(restarted.downloader.path_of(asset)).unwrap(), b"existing weights");
        }
    }

    #[test]
    fn the_builtin_trainer_resumes_the_previous_native_release() {
        let current = TrainerIdentity {
            id: BUILTIN_TRAINER.into(),
            version: CURRENT_BUILTIN_VERSION.into(),
            generation: None,
            optimizer_format: YUE2_STATE_FORMAT.into(),
            weights_revision: yue_train::WEIGHTS_REVISION.into(),
        };
        let mut saved = TrainerIdentity {
            version: PREVIOUS_BUILTIN_VERSION.into(),
            ..current.clone()
        };
        assert!(current.can_resume(&saved));
        assert!(!saved.can_resume(&current));
        saved.generation = Some("previous-generation".into());
        assert!(!current.can_resume(&saved));
        saved.generation = None;
        saved.version = "unknown-native-version".into();
        assert!(!current.can_resume(&saved));
    }

    #[tokio::test]
    #[cfg(windows)]
    async fn a_cancelled_or_failed_upgrade_keeps_saved_runs_on_the_verified_trainer() {
        let data = tempfile::tempdir().unwrap();
        let training = Training::new(data.path(), "yue2");
        let downloader = training.downloader();
        let current = &pack()[0];
        let record = downloader.record_of(current);
        let previous_record = downloader.record_of(&PREVIOUS_TRAINER);
        assert_ne!(record, previous_record);
        let previous = downloader.picked_into(&PREVIOUS_TRAINER).join(PREVIOUS_TRAINER.marker);
        std::fs::create_dir_all(previous.parent().unwrap()).unwrap();
        std::fs::write(&previous, b"previous trainer").unwrap();
        crate::install_record::write(
            &previous_record, PREVIOUS_TRAINER.url, crate::pin_sha::sha256(PREVIOUS_TRAINER.url).unwrap(),
            std::slice::from_ref(&previous), downloader.root(),
        ).unwrap();
        for asset in pack().iter().filter(|asset| asset.kind == AssetKind::Model) {
            let file = downloader.path_of(asset);
            std::fs::write(file, b"existing weights").unwrap();
        }
        let saved = TrainerIdentity {
            id: BUILTIN_TRAINER.into(),
            version: PREVIOUS_BUILTIN_VERSION.into(),
            generation: None,
            optimizer_format: YUE2_STATE_FORMAT.into(),
            weights_revision: yue_train::WEIGHTS_REVISION.into(),
        };
        let attempt = downloader.install_all_with_cancel(SCOPE, &[current], Some(&|| true)).await;
        assert_eq!(attempt.unwrap_err().to_string(), "cancelled");
        let (executable, identity) = training.select_trainer(None, Some(&saved), true).await.unwrap();
        assert_eq!(executable, previous);
        assert_eq!(identity.version, PREVIOUS_BUILTIN_VERSION);
        assert!(training.select_trainer(None, None, false).await.is_err());
        let (executable, identity) = training.select_trainer(None, None, true).await.unwrap();
        assert_eq!(executable, previous);
        assert_eq!(identity.version, PREVIOUS_BUILTIN_VERSION);

        let broken = data.path().join("broken.zip");
        std::fs::write(&broken, b"the wrong archive").unwrap();
        let attempt = downloader.install_local_archive(SCOPE, current, &broken).await;
        assert!(format!("{:#}", attempt.unwrap_err()).contains("differs from the pinned"));
        let program = training.trainer();
        std::fs::create_dir_all(program.parent().unwrap()).unwrap();
        crate::install_record::begin(&record).unwrap();
        std::fs::write(&program, b"partially extracted trainer").unwrap();

        let restarted = Training::new(data.path(), "yue2");
        let (executable, identity) = restarted.select_trainer(None, Some(&saved), true).await.unwrap();
        assert_eq!(executable, previous);
        assert_eq!(identity.version, PREVIOUS_BUILTIN_VERSION);
        assert_eq!(std::fs::read(&previous).unwrap(), b"previous trainer");
        assert!(!restarted.pack_ready());

        std::fs::write(&program, b"current trainer").unwrap();
        crate::install_record::write(
            &record, current.url, crate::pin_sha::sha256(current.url).unwrap(),
            std::slice::from_ref(&program), downloader.root(),
        ).unwrap();
        let restarted = Training::new(data.path(), "yue2");
        let (executable, identity) = restarted.select_trainer(None, Some(&saved), true).await.unwrap();
        assert_eq!(executable, program);
        assert_eq!(identity.version, CURRENT_BUILTIN_VERSION);
        assert!(restarted.downloader().is_verified_install(&PREVIOUS_TRAINER));
    }

    #[tokio::test]
    #[cfg(windows)]
    async fn upgrading_the_captioner_does_not_download_moss_again() {
        let root = tempfile::tempdir().unwrap();
        let training = Training::new(root.path(), "yue2");
        let old_engine = tools_root(root.path()).join("hotstep-tools-2ef93a1c");
        std::fs::create_dir_all(&old_engine).unwrap();
        std::fs::write(old_engine.join(CAPTIONER), b"previous captioner").unwrap();
        // The fixed model paths outlive the versioned captioner. A nonempty
        // file represents a completed model download in this fixture.
        for asset in listen_pack().iter().filter(|asset| asset.kind == AssetKind::Model) {
            let path = training.downloader.path_of(asset);
            std::fs::create_dir_all(path.parent().unwrap()).unwrap();
            std::fs::write(path, b"previous weights").unwrap();
        }
        let missing: Vec<_> = training.listen_files().filter(|asset| !training.listen_installed(asset)).map(|asset| asset.id).collect();
        assert_eq!(missing, ["ace-caption"]);

        let captioner = training.downloader.runtime_dir(trainer_folder()).join(CAPTIONER);
        std::fs::create_dir_all(captioner.parent().unwrap()).unwrap();
        std::fs::write(captioner, b"current captioner").unwrap();
        drop(training);

        let restarted = Training::new(root.path(), "yue2");
        assert!(restarted.listen_ready());
        assert!(restarted.listen_status().iter().all(|file| file["installed"].as_bool() == Some(true)));
        assert!(restarted.install_listen().await.is_ok());
        assert!(restarted.downloader.active_for(LISTEN_SCOPE).await.is_none());
    }

    #[cfg(windows)]
    #[test]
    fn a_deep_joint_run_passes_extended_checkpoint_and_resume_paths() {
        let root = tempfile::tempdir().unwrap();
        let run = root.path().join("a".repeat(100)).join("b".repeat(100)).join("training").join("runs").join("c".repeat(32));
        let output = run.join("output");
        let partial = output.join(".checkpoint-step20.tmp");
        std::fs::create_dir_all(&partial).unwrap();
        let optimizer = include_bytes!("../../music-engine/tests/fixtures/optimizer-v1.resume");
        std::fs::write(partial.join("optimizer.resume"), optimizer).unwrap();
        assert!(yue_train::resume_point(&run).is_none(), "an unpublished checkpoint cannot be resumed");
        std::fs::rename(partial, output.join("checkpoint-step20")).unwrap();
        let (step, resume) = yue_train::resume_point(&run).unwrap();
        assert_eq!(step, 20);

        let fresh = run.join("output-next");
        let stage = yue_train::continuation_stage(&run.join("base.safetensors"), &run.join("companion"), &run, &yue_train::Recipe::default(), &fresh, &resume);
        let stage = joint_checkpoint_paths(stage).unwrap();
        let argument = |name: &str| stage.args.windows(2).find(|pair| pair[0] == name).map(|pair| Path::new(&pair[1])).unwrap();
        let output = argument("--output");
        let source = argument("--resume");
        for path in [output, source] {
            assert!(path.to_string_lossy().starts_with(r"\\?\"));
            assert!(path.to_string_lossy().len() > 260);
        }
        assert!(!output.exists(), "only the trainer creates its output directory");
        assert_eq!(output.file_name().unwrap(), "output-next");
        assert_eq!(std::fs::read(source).unwrap(), optimizer.as_slice());
    }

    #[test]
    fn checkpoint_write_reason_survives_the_last_trainer_line() {
        let mut failure = TrainerFailure::default();
        failure.observe("[STWrite] cannot open C:/Studio/data/adapter.safetensors for writing: Permission denied");
        failure.observe("ace-train yue2-joint-train: checkpoint publication failed");
        let message = failure.message();
        assert!(message.contains("adapter.safetensors for writing: Permission denied"));
        assert!(message.ends_with("checkpoint publication failed"));
    }

    #[tokio::test]
    async fn the_card_stays_reserved_until_the_engine_is_restored() {
        let root = tempfile::tempdir().unwrap();
        let training = Training::new(root.path(), "yue2");
        for outcome in [Ok(true), Ok(false), Err(anyhow::anyhow!("trainer exited"))] {
            *training.active.write().await = Some(Active { run_id: "test".into(), cancel: Default::default() });
            training.settle("test", outcome, async {
                assert_eq!(training.active_run().await.as_deref(), Some("test"));
            }).await;
            assert!(training.active_run().await.is_none());
        }
    }

    #[test]
    fn a_step_is_a_line_and_a_run_written_before_keeps_its_steps() {
        let root = std::env::temp_dir().join(format!("yue-train-steps-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        let training = Training::new(&root, "yue2");
        let record = |step: u32| TrainingStepRecord { step, loss: 1.0, ar_kl: None, step_ms: Some(10.0) };
        let run = Run {
            id: "r1".into(),
            engine: "yue2".into(),
            dataset_id: "d".into(),
            dataset_name: "d".into(),
            name: "n".into(),
            trigger: "t".into(),
            recipe: Recipe::default(),
            trainer: None,
            training_base: None,
            status: RunStatus::Running,
            stage: None,
            stages: Vec::new(),
            steps: vec![record(1), record(2)],
            error: None,
            created_at: now(),
            finished_at: None,
            installed: Vec::new(),
            continuations: Vec::new(),
            output_adapter: None,
            hotstep_sa3_settings: None,
            hotstep_heartmula_settings: None,
            rvc_burn_settings: None,
            rvc_voice_id: None,
        };
        training.save_run(&run).unwrap();
        training.append_step("r1", record(3)).unwrap();
        training.append_step("r1", record(4)).unwrap();
        let dir = training.run_dir("r1").unwrap();
        let kept: Run = read_json(&dir.join("run.json")).unwrap();
        assert!(kept.steps.is_empty());
        assert_eq!(training.run("r1").unwrap().steps.iter().map(|record| record.step).collect::<Vec<_>>(), [1, 2, 3, 4]);
        let mut torn = std::fs::OpenOptions::new().append(true).open(dir.join(STEPS_FILE)).unwrap();
        std::io::Write::write_all(&mut torn, b"{\"step\":5,\"lo").unwrap();
        drop(torn);
        assert_eq!(training.run("r1").unwrap().steps.len(), 4);
        // a stop cut that line off: the run carries on after it
        training.append_step("r1", record(6)).unwrap();
        assert_eq!(training.run("r1").unwrap().steps.iter().map(|record| record.step).collect::<Vec<_>>(), [1, 2, 3, 4, 6]);
        let mut again = training.run("r1").unwrap();
        again.steps.retain(|record| record.step <= 2);
        again.status = RunStatus::Done;
        training.save_run(&again).unwrap();
        assert_eq!(training.runs()[0].steps.iter().map(|record| record.step).collect::<Vec<_>>(), [1, 2]);
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn a_trigger_word_is_made_from_the_name() {
        assert_eq!(trigger_from("Нейромонах Феофан"), "nrmnkhffn");
        assert_eq!(trigger_from("Mono Inc."), "mninc");
        assert!(trigger_from("Ария").starts_with("loraar"));
        assert_ne!(trigger_from("周杰伦"), trigger_from("夜に駆ける"));
        assert!(trigger_from("周杰伦").starts_with("lora") && trigger_from("周杰伦").len() == 10);
        assert_eq!(trigger_from("Before The Dawn, Black Sun Aeon"), "bfrthdwnblck");
    }

    #[test]
    fn a_dataset_written_before_the_states_gets_them_from_its_text() {
        let mut dataset = serde_json::json!({"items": [
            {"lyrics": "[Verse 1]\nline", "style": "pop"},
            {"lyrics": "a line\nanother", "style": ""},
            {"lyrics": "", "instrumental": true},
            {"lyrics": ""},
            {"lyrics": "", "lyrics_state": "found", "style_state": "heard"},
        ]});
        settle_states(&mut dataset);
        let states: Vec<(String, String)> = dataset["items"]
            .as_array()
            .unwrap()
            .iter()
            .map(|item| (item["lyrics_state"].as_str().unwrap().to_string(), item["style_state"].as_str().unwrap().to_string()))
            .collect();
        let expected = [("done", "done"), ("found", "wanted"), ("done", "wanted"), ("wanted", "wanted"), ("found", "heard")];
        assert_eq!(states, expected.map(|(lyrics, style)| (lyrics.to_string(), style.to_string())));
    }

    #[test]
    fn songs_are_named_from_their_paths() {
        let name = |relative: &str| {
            let parts: Vec<&str> = relative.split('/').collect();
            let stem = Path::new(parts.last().unwrap()).file_stem().unwrap().to_str().unwrap().to_string();
            let (artist, title) = split_file_name(&stem);
            (artist.or_else(|| artist_from_folders(&parts[..parts.len() - 1])).unwrap_or_default(), title)
        };
        let cases = [
            ("Нейромонах Феофан/Нейромонах Феофан - Тьма во мне 2018/1. Тьма во мне.flac", "Нейромонах Феофан", "Тьма во мне"),
            ("Нейромонах Феофан - Велики силы добра (FLAC)/01 Нейромонах Феофан - Ураган.flac", "Нейромонах Феофан", "Ураган"),
            ("Adrian von Ziegler/2010 - Requiem/12. A Celtic Tale.mp3", "Adrian von Ziegler", "A Celtic Tale"),
            ("Ария/Сборники, трибьюты, саундтреки, синглы, сольные и концертные альбомы/2007 - Пляска Ада (Live) (CD 1)/01 - Интро.mp3", "Ария", "Интро"),
            ("BrunuhVille/2011 Once Upon A Time/BrunuhVille - Once Upon A Time... - 06 Love Is Pain.flac", "BrunuhVille", "Love Is Pain"),
            ("Adrian von Ziegler/2011 - Mirror Of The Night/01  Into the Shadow Realm.mp3", "Adrian von Ziegler", "Into the Shadow Realm"),
            ("ultra/Garbage - Run Baby Run.mp3", "Garbage", "Run Baby Run"),
            ("Sirenia/(2004) Sirenia - An Elixir For Existence (320 kbps)/07 The Fall Within.mp3", "Sirenia", "The Fall Within"),
            ("April Rain/2014 - One Is Glad To Be Of Service [web]/03 - Last Cry Of A Whale Casted Ashore.flac", "April Rain", "Last Cry Of A Whale Casted Ashore"),
            ("Король и Шут/2001 - Как в старой сказке (2001, Мистерия Звука)/08. Зловещий кузен.mp3", "Король и Шут", "Зловещий кузен"),
            ("Classical/Mozart/2005 - The Very Best Of Mozart - CD2/05. Symphony No.41 'Jupiter'_ Molto allegro.flac", "Mozart", "Symphony No.41 'Jupiter'_ Molto allegro"),
            ("Mono inc/Mono Inc. - 2019 - Symphonic Live (FLAC)/04 - If I Fail.flac", "Mono Inc.", "If I Fail"),
            ("Before The Dawn, Black Sun Aeon, Dawn Of Solace ‎– My Darkness - 1999-2013 - 2015/Before The Dawn/2008 - Soundscape Of Silence/06. Fabrication.flac", "Before The Dawn", "Fabrication"),
            ("Franz Ferdinand -  Take Me Out.mp3", "Franz Ferdinand", "Take Me Out"),
            ("Король и Шут/Мотоцикл.mp3", "Король и Шут", "Мотоцикл"),
            ("Lifelover - Discography (2006-2011)/2006 - Pulver/03 - Nackskott.flac", "Lifelover", "Nackskott"),
            ("Nena/99 Luftballons.mp3", "Nena", "99 Luftballons"),
            ("Youssou N'Dour/7 Seconds.flac", "Youssou N'Dour", "7 Seconds"),
        ];
        for (relative, artist, title) in cases {
            assert_eq!(name(relative), (artist.to_string(), title.to_string()), "{relative}");
        }
    }

    #[test]
    fn a_cue_sheet_reads() {
        let text = "PERFORMER \"Нейромонах Феофан\"\r\nFILE \"Альбом.flac\" WAVE\r\n  TRACK 01 AUDIO\r\n    TITLE \"Ураган\"\r\n    INDEX 01 00:00:00\r\n  TRACK 02 AUDIO\r\n    TITLE \"Пни\"\r\n    INDEX 00 02:29:70\r\n    INDEX 01 02:30:08\r\n";
        let (file, tracks) = cue_sheet_text(text);
        assert_eq!(file.as_deref(), Some("Альбом.flac"));
        assert_eq!(tracks.len(), 2);
        assert_eq!(tracks[1].title, "Пни");
        assert!((tracks[1].start - (150.0 + 8.0 / 75.0)).abs() < 1e-9);
    }

    #[test]
    fn titles_leave_out_track_numbers_and_the_artist() {
        assert_eq!(split_file_name("01 Нейромонах Феофан - Ураган").1, "Ураган");
        assert_eq!(split_file_name("9. Нейромонах Феофан - Петь. Плясать.").1, "Петь. Плясать.");
        assert_eq!(split_file_name("1. Замиренье (feat. Drummatix)").1, "Замиренье (feat. Drummatix)");
        assert_eq!(split_file_name("2077").1, "2077");
        assert_eq!(split_file_name("Song").1, "Song");
    }

    #[test]
    fn lrc_files_become_plain_lyrics() {
        let lrc = "[ar:Someone]\n[00:01.00]First <00:01.50>line\n\n[Chorus]\n[00:05.20]Second line";
        assert_eq!(plain_lyrics(lrc), "First line\n\n[Chorus]\nSecond line");
        assert_eq!(plain_lyrics("[Verse 1]\nplain"), "[Verse 1]\nplain");
    }
}

#[cfg(test)]
mod import_tests {
    use super::*;

    #[test]
    fn a_dataset_names_its_songs_as_bare_wav_files() {
        assert!(is_plain_wav_name("01-song.wav"));
        for bad in ["C:evil.wav", "../x.wav", r"a\b.wav", "a/b.wav", ".wav", "song.mp3", ""] {
            assert!(!is_plain_wav_name(bad), "{bad}");
        }
    }

    /// The HOT-Step tools are one package: `scripts/build-hotstep-tools.ps1` builds it from both source files and
    /// refuses two releases.
    #[test]
    fn the_trainer_and_the_transcriber_are_one_tools_release() {
        let read = |text: &str| serde_json::from_str::<serde_json::Value>(text).unwrap();
        let train = read(include_str!("../../../engines/music-train-source.json"));
        let midi = read(include_str!("../../../engines/music-midi-source.json"));
        for key in ["commit", "release_tag", "asset", "bytes"] {
            assert_eq!(train[key], midi[key], "{key}");
        }
    }
}
