//! audio.cpp's `audiocpp_server` for the studio's tools: HT-Demucs stems, MuScriptor audio to MIDI and SheetSage2
//! scores, through Dub Studio's crate `acpp-server` as Speech Studio and Dub Studio run it: one process per build,
//! the models read where they lie on disk, a model left out of the config until its files are there.

use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, OnceLock};
use std::time::Duration;

use acpp_server::asset::Build;
use acpp_server::{AcppError, ModelEntry, Server, ServerConfig};
use anyhow::{anyhow, bail, Result};
use serde_json::Value;

use crate::downloads::{Asset, AssetKind, Downloader};

pub const HTDEMUCS: &str = "htdemucs";
/// The id of a MuScriptor size in the server's config.
pub fn muscriptor_id(size: &str) -> String {
    format!("muscriptor-{size}")
}

/// How long a start may take before the server answers `/health` (it loads no model at start).
const READY_WITHIN: Duration = Duration::from_secs(60);

/// The packaged audio.cpp CUDA modules target the same architectures as YuE2's native modules.
/// Auto uses the processor on NVIDIA when no packaged CUDA image fits. An explicit GPU
/// request can use the Vulkan package on a card with a newer, unsupported architecture.
pub fn build_for(choice: &str) -> Result<Build> {
    if let Some(mac) = Build::for_this_mac() {
        return Ok(mac);
    }
    let hardware = crate::hardware::hardware();
    let card = match hardware.cuda {
        Some(crate::hardware::CudaBuild::Cuda13) => Some(Build::Cuda13),
        Some(crate::hardware::CudaBuild::Cuda12) => Some(Build::Cuda12),
        None if hardware.gpu_name.is_some() && (!hardware.nvidia || (choice == "gpu" && hardware.card_cuda.is_some())) => Some(Build::Vulkan),
        None => None,
    };
    match choice {
        "cpu" => Ok(Build::Cpu),
        "gpu" | "cuda" => card.ok_or_else(|| anyhow!("the selected GPU runtime is unavailable for this card and driver; choose Auto or the processor")),
        _ => Ok(card.unwrap_or(Build::Cpu)),
    }
}

/// [`build_for`] of a device setting: the processor, the card (CUDA, or Vulkan on a card of another make) or Auto.
pub fn build_for_runtime(runtime: crate::lyrics_sync::OnnxFlavour) -> Result<Build> {
    build_for(match runtime {
        crate::lyrics_sync::OnnxFlavour::Cpu => "cpu",
        crate::lyrics_sync::OnnxFlavour::Cuda => "gpu",
        crate::lyrics_sync::OnnxFlavour::Auto => "auto",
    })
}

/// Whether a build computes on the graphics card.
pub fn on_card(build: Build) -> bool {
    !matches!(build, Build::Cpu)
}

fn leak(text: String) -> &'static str {
    Box::leak(text.into_boxed_str())
}

fn exe_name() -> &'static str {
    if cfg!(windows) { "audiocpp_server.exe" } else { "audiocpp_server" }
}

/// Every build of the server, published for this platform or not.
pub const BUILDS: [Build; 5] = [Build::Cuda13, Build::Cuda12, Build::Vulkan, Build::Cpu, Build::Metal];

/// The server archive of a build, as the studio's downloader fetches it into `runtime/<build folder>`.
fn server_asset(build: Build) -> Option<&'static Asset> {
    static ASSETS: OnceLock<Vec<(Build, Asset)>> = OnceLock::new();
    let all = ASSETS.get_or_init(|| {
        BUILDS
            .into_iter()
            .filter_map(|build| {
                let pinned = build.server()?;
                Some((
                    build,
                    Asset {
                        id: leak(format!("audiocpp-{}", build.folder())),
                        label: leak(format!("audio.cpp server ({build:?})")),
                        kind: AssetKind::Runtime,
                        url: pinned.url,
                        relative_path: leak(format!("runtime/{}", pinned.file)),
                        bytes: pinned.size,
                        unzip_into: Some(build.folder()),
                        marker: exe_name(),
                        pick: &[],
                        vram_gb: None,
                        note: "Runs HT-Demucs, MuScriptor and SheetSage2: audio.cpp's server, as Speech Studio and Dub Studio run it.",
                    },
                ))
            })
            .collect()
    });
    all.iter().find(|(of, _)| *of == build).map(|(_, asset)| asset)
}

/// cuFFT 12 (CUDA 13.4 Update 2, NVIDIA's redistributable, as Speech Studio pins it), which the CUDA 13 build imports
/// beside cuBLAS 13; picked out of the archive into the build's folder.
#[cfg(windows)]
const CUFFT13: Asset = Asset {
    id: "audiocpp-cufft12",
    label: "NVIDIA cuFFT 12.4",
    kind: AssetKind::Runtime,
    url: "https://developer.download.nvidia.com/compute/cuda/redist/libcufft/windows-x86_64/libcufft-windows-x86_64-12.4.0.43-archive.zip",
    relative_path: "runtime/libcufft-windows-x86_64-12.4.0.43-archive.zip",
    bytes: 159_602_693,
    unzip_into: Some("audiocpp"),
    marker: "cufft64_12.dll",
    pick: &["cufft64_12.dll"],
    vram_gb: None,
    note: "The transforms audio.cpp's CUDA 13 build computes with.",
};

/// The CUDA 12.9 libraries of the CUDA 12 build (`acpp_server::asset::CUDA12_RUNTIME`, PyPI wheels), picked into the
/// build's folder.
#[cfg(windows)]
fn cuda12_assets() -> &'static [Asset] {
    static ASSETS: OnceLock<Vec<Asset>> = OnceLock::new();
    ASSETS.get_or_init(|| {
        let picks: [&'static [&'static str]; 3] = [&["cudart64_12.dll"], &["cublas64_12.dll", "cublasLt64_12.dll"], &["cufft64_11.dll"]];
        acpp_server::asset::CUDA12_RUNTIME
            .iter()
            .zip(picks)
            .map(|(wheel, pick)| Asset {
                id: leak(format!("audiocpp-{}", wheel.file.split('-').next().unwrap_or(wheel.file))),
                label: leak(format!("NVIDIA {}", wheel.file.split('-').next().unwrap_or(wheel.file))),
                kind: AssetKind::Runtime,
                url: wheel.url,
                relative_path: leak(format!("runtime/{}", wheel.file)),
                bytes: wheel.size,
                unzip_into: Some("audiocpp-cuda12"),
                marker: pick[0],
                pick,
                vram_gb: None,
                note: "The CUDA 12.9 libraries audio.cpp's CUDA 12 build computes with.",
            })
            .collect()
    })
}

/// Linux: the cuFFT of each CUDA build from NVIDIA's manylinux wheels, unpacked beside the server; its CUDA runtime
/// and cuBLAS are the music engine's (`engine_runtime::LINUX_CUDA13` / `LINUX_CUDA12`), one copy for both.
#[cfg(target_os = "linux")]
static LINUX_CUDA: [(Build, Asset); 2] = [
    (Build::Cuda13, Asset {
        id: "audiocpp-libcufft12",
        label: "NVIDIA cuFFT 12.4 (for the audio.cpp server)",
        kind: AssetKind::Runtime,
        url: "https://files.pythonhosted.org/packages/76/bf/3fea3d1c6262bded26ae00e3106432d63235954965d7785f5051ac146651/nvidia_cufft-12.4.0.43-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl",
        relative_path: "runtime/audiocpp-cuda13-cufft.whl",
        bytes: 161_750_089,
        unzip_into: Some(Build::Cuda13.folder()),
        marker: "libcufft.so.12",
        pick: &["libcufft.so.12"],
        vram_gb: None,
        note: "Part of the CUDA 13 server.",
    }),
    (Build::Cuda12, Asset {
        id: "audiocpp-libcufft11",
        label: "NVIDIA cuFFT 11.4 (for the audio.cpp server)",
        kind: AssetKind::Runtime,
        url: "https://files.pythonhosted.org/packages/95/f4/61e6996dd20481ee834f57a8e9dca28b1869366a135e0d42e2aa8493bdd4/nvidia_cufft_cu12-11.4.1.4-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl",
        relative_path: "runtime/audiocpp-cuda12-cufft.whl",
        bytes: 200_877_592,
        unzip_into: Some(Build::Cuda12.folder()),
        marker: "libcufft.so.11",
        pick: &["libcufft.so.11"],
        vram_gb: None,
        note: "Part of the CUDA 12 server.",
    }),
];

/// Linux: the CUDA libraries a CUDA build of the server loads - its CUDA runtime and cuBLAS from the music engine's
/// folder (`engine_runtime::LINUX_CUDA13` / `LINUX_CUDA12`), its cuFFT beside it.
fn linux_cuda_libraries(build: Build) -> &'static [&'static str] {
    match build {
        Build::Cuda13 => &["libcudart.so.13", "libcublas.so.13", "libcublasLt.so.13", "libcufft.so.12"],
        Build::Cuda12 => &["libcudart.so.12", "libcublas.so.12", "libcublasLt.so.12", "libcufft.so.11"],
        Build::Vulkan | Build::Cpu | Build::Metal => &[],
    }
}

pub(crate) const SOXR_URL: &str = "https://github.com/ShiftMediaProject/soxr/releases/download/0.1.3-2/libsoxr_0.1.3-2_msvc17.zip";

#[cfg(windows)]
const SOXR: Asset = Asset {
    id: "audiocpp-soxr",
    label: "SoX Resampler 0.1.3 for MuLaCover",
    kind: AssetKind::Runtime,
    url: SOXR_URL,
    relative_path: "runtime/libsoxr_0.1.3-2_msvc17.zip",
    bytes: 1_351_421,
    unzip_into: Some("audiocpp-soxr"),
    marker: "soxr.dll",
    pick: &["bin/x64/soxr.dll", "licenses/soxr.txt"],
    vram_gb: None,
    note: "SoX Resampler by Rob Sykes, LGPL-2.1. Runtime for MuLaCover's reference-audio transcription.",
};

/// Every download a build of the server needs, the program first.
pub fn assets(build: Build) -> Vec<&'static Asset> {
    let mut assets: Vec<&'static Asset> = server_asset(build).into_iter().collect();
    #[cfg(windows)]
    match build {
        Build::Cuda13 => assets.push(&CUFFT13),
        Build::Cuda12 => assets.extend(cuda12_assets().iter()),
        Build::Vulkan | Build::Cpu | Build::Metal => {}
    }
    #[cfg(target_os = "linux")]
    assets.extend(LINUX_CUDA.iter().filter(|(of, _)| *of == build).map(|(_, asset)| asset));
    #[cfg(windows)]
    assets.push(&SOXR);
    assets
}

/// The audio.cpp server of the studio: its downloads in `<data>/audiocpp`, its logs in `<data>/logs/audiocpp`.
pub struct Acpp {
    downloader: Downloader,
    pub(super) installs: crate::acpp_install::RuntimeInstalls,
    logs: PathBuf,
    /// cuBLAS 13 of the music engine, which the CUDA 13 build imports.
    cuda13_libraries: OnceLock<PathBuf>,
    music: std::sync::Mutex<Option<Server>>,
    music_keep: std::sync::Mutex<Option<super::KeepDecision>>,
    music_evict: AtomicBool,
    /// Every model the server may carry, by id. One server per build serves them all: a config that names only the
    /// model of the run at hand would restart the server whenever another tool asks for its own.
    known: std::sync::Mutex<Vec<ModelEntry>>,
    /// Runs at work, by build.
    active: std::sync::Mutex<Vec<(Build, usize)>>,
    /// Signalled whenever a run ends: one waiting for its backend to be free looks again.
    ended: std::sync::Condvar,
}

impl Acpp {
    pub fn new(data_root: &Path) -> Self {
        Self {
            downloader: Downloader::in_folder(data_root, "audiocpp"),
            installs: crate::acpp_install::RuntimeInstalls::default(),
            logs: data_root.join("logs").join("audiocpp"),
            cuda13_libraries: OnceLock::new(),
            music: std::sync::Mutex::new(None),
            music_keep: std::sync::Mutex::new(None),
            music_evict: AtomicBool::new(false),
            known: std::sync::Mutex::new(Vec::new()),
            active: std::sync::Mutex::new(Vec::new()),
            ended: std::sync::Condvar::new(),
        }
    }

    /// A model the server may carry, in place of an earlier one of the same id.
    pub fn register(&self, entry: ModelEntry) {
        let mut known = self.known.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        known.retain(|model| model.id != entry.id);
        known.push(entry);
    }

    /// The registered models whose files are on disk now: the server reads each configured model's contract when it
    /// starts, and one missing file would stop all of them. A model folder (MuScriptor's) counts once both of its
    /// files are there, since the folder appears with the first of them.
    fn models_on_disk(&self) -> Vec<ModelEntry> {
        let complete = |path: &Path| path.is_file() || ["config.json", "model.safetensors"].iter().all(|file| path.join(file).is_file());
        let known = self.known.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut models: Vec<ModelEntry> = known.iter().filter(|model| {
            crate::audio_cpp_music::registered_model_ready(model)
                .unwrap_or_else(|| complete(&model.path))
        }).cloned().collect();
        models.sort_by(|a, b| a.id.cmp(&b.id));
        models
    }

    pub fn downloader(&self) -> &Downloader {
        &self.downloader
    }

    /// The folder of the cuBLAS 13 the music engine runs on.
    pub fn set_cuda13_libraries(&self, folder: PathBuf) {
        self.cuda13_libraries.set(folder).ok();
    }

    fn folder(&self, build: Build) -> PathBuf {
        self.downloader.runtime_dir(build.folder())
    }

    /// The server program of a build, where it is or will be once downloaded.
    pub fn exe(&self, build: Build) -> PathBuf {
        std::env::var_os("YUE_AUDIOCPP_SERVER").map(PathBuf::from).unwrap_or_else(|| self.folder(build).join(exe_name()))
    }

    /// The downloads of a build not installed yet.
    pub fn missing(&self, build: Build) -> Vec<&'static Asset> {
        if std::env::var_os("YUE_AUDIOCPP_SERVER").is_some() {
            return Vec::new();
        }
        assets(build).into_iter().filter(|asset| !self.downloader.is_installed(asset)).collect()
    }

    /// Its downloads are here, and the CUDA libraries it imports are where it finds them: the CUDA 13 build takes the
    /// music engine's cuBLAS 13, which the engine runtime downloads.
    pub fn installed(&self, build: Build) -> bool {
        self.missing(build).iter().all(|asset| asset.url == SOXR_URL)
            && (std::env::var_os("YUE_AUDIOCPP_SERVER").is_some() || self.missing_libraries(build).is_empty())
    }

    #[cfg(windows)]
    pub async fn install_soxr(&self) -> Result<()> {
        self.install_soxr_for("audiocpp-soxr").await
    }

    #[cfg(windows)]
    pub async fn install_soxr_for(&self, scope: &str) -> Result<()> {
        self.downloader.install_all(scope, &[&SOXR]).await
    }

    /// The cover frontend requires Soxr's HQ resampler, even with a 24 kHz source.
    pub fn soxr_ready(&self) -> bool {
        #[cfg(windows)]
        return self.downloader.is_installed(&SOXR);
        #[cfg(unix)]
        return ["libsoxr.so.0", "libsoxr.so", "libsoxr.dylib",
            "/opt/homebrew/lib/libsoxr.dylib", "/usr/local/lib/libsoxr.dylib"]
            .into_iter()
            .any(|name| {
                // A successful load and both symbols are what the pinned server checks.
                unsafe {
                    libloading::Library::new(name).is_ok_and(|library| {
                        library.get::<unsafe extern "C" fn()>(b"soxr_oneshot").is_ok()
                            && library.get::<unsafe extern "C" fn()>(b"soxr_quality_spec").is_ok()
                    })
                }
            });
        #[cfg(not(any(windows, unix)))]
        false
    }

    /// The CUDA libraries a CUDA build loads that are in none of the places the loader finds them for the server: beside
    /// the program, the music engine's CUDA libraries (`cuda13_libraries`, on Linux those of both CUDA builds), and
    /// PATH or LD_LIBRARY_PATH, which the server inherits (an installed CUDA Toolkit's own).
    fn missing_libraries(&self, build: Build) -> Vec<&'static str> {
        let beside = self.folder(build);
        let variable = if cfg!(windows) { "PATH" } else { "LD_LIBRARY_PATH" };
        let path: Vec<PathBuf> = std::env::var_os(variable).map(|path| std::env::split_paths(&path).collect()).unwrap_or_default();
        let mut dirs: Vec<&Path> = vec![&beside];
        if let Some(cuda13) = self.cuda13_libraries.get() {
            dirs.push(cuda13);
        }
        dirs.extend(path.iter().map(PathBuf::as_path));
        if cfg!(target_os = "linux") {
            return linux_cuda_libraries(build).iter().copied().filter(|library| !dirs.iter().any(|dir| dir.join(library).is_file())).collect();
        }
        acpp_server::asset::missing_libraries(build, &dirs)
    }

    fn config(&self, build: Build, models: Vec<ModelEntry>) -> ServerConfig {
        ServerConfig {
            exe: self.exe(build),
            backend: build.backend(),
            device: 0,
            threads: std::thread::available_parallelism().map(|count| count.get() as u32).unwrap_or(8).min(16),
            models,
            data_dir: self.logs.join(build.folder()),
            log: false,
        }
    }

    /// The server of this build carrying every registered model on disk, `id` among them: the running one when its
    /// models are these, else a new one in its place. An error, before the program starts, when the program or its
    /// CUDA libraries are missing or `id` is not on disk.
    fn server(&self, build: Build, id: &str) -> Result<Arc<Server>> {
        let config = self.config(build, self.models_on_disk());
        if !config.models.iter().any(|entry| entry.id == id) {
            bail!("{id} is not on disk; download it in Settings - Models");
        }
        self.check_runtime(build, &config)?;
        acpp_server::SERVERS
            .get(&config, READY_WITHIN, &|command| self.prepare(build, command))
            .map_err(|error| anyhow!("{}", describe(&error)))
    }

    fn check_runtime(&self, build: Build, config: &ServerConfig) -> Result<()> {
        if !config.exe.is_file() {
            bail!("audio.cpp's server is not installed: {} is missing; download it in Settings - Models", config.exe.display());
        }
        if std::env::var_os("YUE_AUDIOCPP_SERVER").is_none() {
            let missing = self.missing_libraries(build);
            if !missing.is_empty() {
                bail!("audio.cpp's server is missing {} beside it; download it again in Settings - Models", missing.join(", "));
            }
        }
        Ok(())
    }

    fn prepare(&self, build: Build, command: &mut std::process::Command) {
        let cuda13 = self.cuda13_libraries.get().cloned();
        let beside = self.folder(build);
        // a Linux loader does not look beside the program: the CUDA libraries lie in its folder
        if cfg!(target_os = "linux") {
            let inherited = std::env::var_os("LD_LIBRARY_PATH").unwrap_or_default();
            if let Ok(path) = std::env::join_paths(std::iter::once(beside.clone()).chain(std::env::split_paths(&inherited))) {
                command.env("LD_LIBRARY_PATH", path);
            }
        }
        // cuBLAS 13 lies beside the music engine, which the studio's PATH already names first
        let mut libraries = cuda13.iter().cloned().collect::<Vec<_>>();
        #[cfg(windows)]
        libraries.push(self.downloader.runtime_dir("audiocpp-soxr"));
        if !libraries.is_empty() {
            let existing = std::env::var_os("PATH").unwrap_or_default();
            if let Ok(path) = std::env::join_paths(libraries.into_iter().chain(std::env::split_paths(&existing))) {
                command.env("PATH", path);
            }
        }
    }

    /// Private to generation. Stopping one of these jobs can reap the process
    /// without touching the process that serves separation, MIDI and audio tools.
    pub(super) fn run_music(
        &self, build: Build, model: ModelEntry, body: Value, stop: &AtomicBool,
        keep_weights: bool, on_synthesis: impl FnOnce(),
    ) -> Result<Value> {
        let mut music = self.music.lock().unwrap_or_else(|error| error.into_inner());
        self.music_evict.store(false, Ordering::SeqCst);
        anyhow::ensure!(!stop.load(Ordering::SeqCst), "stopped");
        let id = model.id.clone();
        let mut config = self.config(build, vec![model]);
        config.data_dir.push("music");
        self.check_runtime(build, &config)?;
        if music.as_ref().is_none_or(|server| server.config() != &config || !server.alive()) {
            drop(music.take());
            *music = Some(Server::start(&config, READY_WITHIN, &|command| self.prepare(build, command))?);
        }
        let server = music.as_ref().expect("The music server has started.");
        let reply = if stop.load(Ordering::SeqCst) { Err(AcppError::Cancelled) } else {
            on_synthesis();
            server.run_task(&id, body, stop)
        };
        if matches!(reply, Err(AcppError::Cancelled)) || stop.load(Ordering::SeqCst) {
            // Drop kills and reaps the owned child before the caller releases the engine lease.
            drop(music.take());
            self.set_music_keep(None);
            bail!("stopped");
        }
        let card = on_card(build);
        let free_gib = (matches!(build, Build::Cuda12 | Build::Cuda13) && keep_weights && reply.is_ok()).then(|| {
            crate::resources::nvidia_gpus()
                .and_then(|gpus| gpus.first().map(|gpu| gpu.vram_total_mb.saturating_sub(gpu.vram_used_mb) as f64 / 1024.0))
        }).flatten();
        let mut decision = music_keep_decision(keep_weights && reply.is_ok(), card, free_gib);
        if card && self.music_evict.load(Ordering::SeqCst) {
            decision.keep = false;
            decision.reason = "in_use";
        }
        if !decision.keep && let Err(error) = server.unload(&[&id]) {
            eprintln!("[ERROR] unloading audio.cpp {id}: {error:#}");
            drop(music.take());
        }
        self.set_music_keep(reply.as_ref().ok().map(|_| decision));
        Ok(reply?)
    }

    fn set_music_keep(&self, decision: Option<super::KeepDecision>) {
        *self.music_keep.lock().unwrap_or_else(|error| error.into_inner()) = decision;
    }

    pub(super) fn music_keep(&self) -> Option<super::KeepDecision> {
        self.music_keep.lock().unwrap_or_else(|error| error.into_inner()).clone()
    }

    pub(super) fn evict_idle_card_music(&self) {
        self.music_evict.store(true, Ordering::SeqCst);
        if let Ok(mut music) = self.music.try_lock()
            && music.as_ref().is_some_and(|server| server.config().backend != Build::Cpu.backend())
            && self.music_keep().is_some_and(|decision| decision.keep)
        {
            drop(music.take());
            self.set_music_keep(None);
        }
    }

    pub(super) fn stop_music(&self) {
        let mut music = self.music.lock().unwrap_or_else(|error| error.into_inner());
        drop(music.take());
        self.set_music_keep(None);
    }
    /// `work` on the server of `build` carrying `model`: the one at work when it carries the model, else a new one once
    /// the runs on it have ended; a server under work is never replaced. The run counts from the moment its server is
    /// chosen; `stop`, asked while it waits for the server, ends it with "stopped" first.
    pub fn with_server<T>(&self, build: Build, model: ModelEntry, stop: &(dyn Fn() -> bool + Sync), work: impl FnOnce(&Server) -> Result<T>) -> Result<T> {
        let id = model.id.clone();
        let path = model.path.clone();
        if on_card(build) { self.evict_idle_card_music(); }
        self.register(model);
        let backend = build.backend();
        let server = self.claim(build, stop, |busy| {
            let running = acpp_server::SERVERS.running(backend);
            let seen = running.as_ref().map(|server| Seen { alive: server.alive(), carries: server.config().models.iter().any(|entry| entry.id == id && entry.path == path) });
            match take(seen, busy) {
                Take::Running => Ok(Some(running.expect("a running server was seen"))),
                Take::Wait => Ok(None),
                Take::Start => self.server(build, &id).map(Some),
            }
        })?;
        let _work = Work { acpp: self, build };
        work(&server)
    }

    /// The server `choose` gives for a run of `build`, counted as at work on it. `choose` is asked, with whether a run is
    /// at work on the backend, under the count's lock: `None` waits for a run to end and asks again. `stop`, asked while
    /// the run waits, ends it with "stopped" before it counts or touches a server.
    fn claim<S>(&self, build: Build, stop: &(dyn Fn() -> bool + Sync), mut choose: impl FnMut(bool) -> Result<Option<S>>) -> Result<S> {
        let mut active = self.active.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let server = loop {
            if let Some(server) = choose(busy(&active, build.backend()))? {
                break server;
            }
            if stop() {
                bail!("stopped");
            }
            active = self.ended.wait_timeout(active, Duration::from_millis(100)).unwrap_or_else(|poisoned| poisoned.into_inner()).0;
        };
        begin(&mut active, build);
        Ok(server)
    }
}

fn music_keep_decision(wanted: bool, on_card: bool, free_gib: Option<f64>) -> super::KeepDecision {
    let need_gib = (wanted && on_card).then_some(super::TRACKS_RESERVE_GIB + super::KEEP_HEADROOM_GIB);
    let (keep, reason) = match (wanted, need_gib, free_gib) {
        (false, _, _) => (false, "set"),
        (true, None, _) => (true, "set"),
        (true, Some(need), Some(free)) if free >= need => (true, "fits"),
        (true, Some(_), Some(_)) => (false, "does_not_fit"),
        (true, Some(_), None) => (false, "free_unknown"),
    };
    super::KeepDecision { keep, reason, need_gib, free_gib }
}

#[cfg(test)]
mod packed_residency_tests {
    use super::*;

    #[test]
    fn explicit_residency_needs_measured_card_headroom() {
        assert!(music_keep_decision(true, false, None).keep);
        assert!(music_keep_decision(true, true, Some(12.0)).keep);
        assert_eq!(music_keep_decision(true, true, Some(1.0)).reason, "does_not_fit");
        assert_eq!(music_keep_decision(true, true, None).reason, "free_unknown");
        assert!(!music_keep_decision(false, true, Some(12.0)).keep);
    }
}

/// An error of the server said the way the studio shows it.
pub fn describe(error: &AcppError) -> String {
    match error {
        AcppError::Cancelled => "stopped".into(),
        other => other.to_string(),
    }
}

/// Runs `request` on `model` in the server of `build` (`take`): the one at work when it carries the model, else a new
/// one once the runs on it have ended; a server under work is never replaced. `stop` is asked every tenth of a second,
/// while the run waits for the server too. The run counts from the moment its server is chosen.
pub fn run(acpp: &Acpp, build: Build, model: ModelEntry, request: Value, stop: &(dyn Fn() -> bool + Sync)) -> Result<Value> {
    run_with(acpp, build, model, stop, |server, id, cancel| server.run_task(id, request, cancel))
}

/// [`run`] through the server's stream: the artifacts of each event go to `on_event` as the model produces them; the
/// answer is the same result.
pub fn run_stream(
    acpp: &Acpp,
    build: Build,
    model: ModelEntry,
    request: Value,
    stop: &(dyn Fn() -> bool + Sync),
    on_event: &mut dyn FnMut(&[acpp_server::TaskArtifact]),
) -> Result<Value> {
    run_with(acpp, build, model, stop, |server, id, cancel| server.run_task_stream(id, request, cancel, on_event))
}

fn run_with(
    acpp: &Acpp,
    build: Build,
    model: ModelEntry,
    stop: &(dyn Fn() -> bool + Sync),
    task: impl FnOnce(&Server, &str, &AtomicBool) -> std::result::Result<Value, AcppError>,
) -> Result<Value> {
    let id = model.id.clone();
    acpp.with_server(build, model, stop, |server| {
        let id = id.as_str();
        let cancel = AtomicBool::new(false);
        let finished = AtomicBool::new(false);
        let answer = std::thread::scope(|scope| {
            scope.spawn(|| {
                while !finished.load(Ordering::SeqCst) {
                    if stop() {
                        cancel.store(true, Ordering::SeqCst);
                        return;
                    }
                    std::thread::sleep(Duration::from_millis(100));
                }
            });
            let answer = task(server, id, &cancel);
            finished.store(true, Ordering::SeqCst);
            answer
        });
        match answer {
            Ok(result) => Ok(result),
            Err(AcppError::Cancelled) => bail!("stopped"),
            Err(error) => Err(anyhow!("audio.cpp's {id}: {}", describe(&error))),
        }
    })
}

/// The server running on a backend, as a run about to start sees it.
#[derive(Debug, Clone, Copy)]
struct Seen {
    alive: bool,
    /// It carries the model the run needs.
    carries: bool,
}

/// What a run does with the server of its backend.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Take {
    /// The one running, as it is: another run is at work on it.
    Running,
    /// Wait for the runs on it to end: it lacks the model, and replacing it would break them.
    Wait,
    /// `SERVERS.get`: the running one when its models are today's, else a new one in its place.
    Start,
}

/// A server under work is never replaced: the run takes it as it is when it carries the model, else waits.
fn take(running: Option<Seen>, busy: bool) -> Take {
    match running {
        Some(seen) if seen.alive && busy => {
            if seen.carries {
                Take::Running
            } else {
                Take::Wait
            }
        }
        _ => Take::Start,
    }
}

/// Some run is at work on a server of `backend`: the CUDA builds share one.
fn busy(active: &[(Build, usize)], backend: acpp_server::Backend) -> bool {
    active.iter().any(|(build, runs)| build.backend() == backend && *runs > 0)
}

fn begin(active: &mut Vec<(Build, usize)>, build: Build) {
    match active.iter_mut().find(|(at, _)| *at == build) {
        Some((_, runs)) => *runs += 1,
        None => active.push((build, 1)),
    }
}

/// Counts a run of `build` off; whether its backend is free now.
fn end(active: &mut [(Build, usize)], build: Build) -> bool {
    if let Some((_, runs)) = active.iter_mut().find(|(at, _)| *at == build) {
        *runs = runs.saturating_sub(1);
    }
    !busy(active, build.backend())
}

/// A run at work. When it ends - done, failed, stopped or panicking - it is counted off, and the last one on its
/// backend ends the server: an idle server still holds a gigabyte of the card, which belongs to the music engine
/// between runs, and a stopped run would otherwise go on to its end.
struct Work<'a> {
    acpp: &'a Acpp,
    build: Build,
}

impl Drop for Work<'_> {
    fn drop(&mut self) {
        let mut active = self.acpp.active.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        if end(&mut active, self.build) {
            if let Some(server) = acpp_server::SERVERS.running(self.build.backend()) {
                server.kill();
            }
        }
        self.acpp.ended.notify_all();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_build_this_platform_publishes_has_its_downloads() {
        for build in BUILDS {
            let Some(pinned) = build.server() else { continue };
            let downloads = assets(build);
            assert_eq!(downloads[0].url, pinned.url);
            assert_eq!(downloads[0].unzip_into, Some(build.folder()));
            #[cfg(windows)]
            for library in build.libraries() {
                let picked = downloads.iter().any(|asset| asset.pick.contains(library));
                let from_engine = build == Build::Cuda13 && crate::engine_runtime::CUDA13_LIBRARIES.contains(library);
                assert!(picked || from_engine, "{build:?} imports {library}, which nothing downloads");
            }
        }
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn a_linux_cuda_build_lays_every_library_its_server_loads_beside_it() {
        // the server's cuFFT beside it, its CUDA runtime and cuBLAS in the one folder of the engine's
        for (build, cuda) in [(Build::Cuda13, crate::hardware::CudaBuild::Cuda13), (Build::Cuda12, crate::hardware::CudaBuild::Cuda12)] {
            let downloads = assets(build);
            let shared = crate::engine_runtime::cuda_assets(cuda);
            for library in linux_cuda_libraries(build) {
                let found = downloads.iter().chain(shared.iter()).any(|asset| asset.pick.contains(library));
                assert!(found, "{build:?} loads {library}, which nothing downloads");
            }
            for download in &downloads {
                assert_eq!(download.unzip_into, Some(build.folder()), "{} lands beside the {build:?} server", download.id);
                assert!(crate::pin_sha::sha256(download.url).is_some(), "{} names the SHA-256 of its pin", download.id);
            }
            for library in shared {
                assert!(!downloads.iter().any(|asset| asset.url == library.url), "{} is downloaded once, by the engine runtime", library.id);
                assert!(crate::pin_sha::sha256(library.url).is_some(), "{} names the SHA-256 of its pin", library.id);
            }
        }
    }

    #[test]
    fn a_processor_choice_runs_the_processor_build() {
        if Build::for_this_mac().is_none() {
            assert_eq!(build_for("cpu").unwrap(), Build::Cpu);
            assert!(!on_card(Build::Cpu));
        }
    }

    #[test]
    fn a_server_at_work_is_taken_as_it_is_or_waited_for_never_replaced() {
        let carrying = Seen { alive: true, carries: true };
        let lacking = Seen { alive: true, carries: false };
        assert_eq!(take(Some(carrying), true), Take::Running, "another run's server carries the model");
        assert_eq!(take(Some(lacking), true), Take::Wait, "it lacks the model and another run is at work on it");
        assert_eq!(take(Some(lacking), false), Take::Start, "nobody is at work: replaced as before");
        assert_eq!(take(None, false), Take::Start, "no server yet");
        assert_eq!(take(Some(Seen { alive: false, carries: true }), true), Take::Start, "a server that died serves nobody");
    }

    #[test]
    fn runs_are_counted_by_build_and_a_backend_frees_with_its_last_run() {
        let mut active = Vec::new();
        begin(&mut active, Build::Cuda13);
        begin(&mut active, Build::Cpu);
        begin(&mut active, Build::Cuda13);
        assert!(end(&mut active, Build::Cpu), "the processor's server ends with its own run");
        assert!(busy(&active, Build::Cuda13.backend()), "the CUDA runs keep the card's server");
        assert!(!busy(&active, Build::Cpu.backend()));
        assert!(!end(&mut active, Build::Cuda13), "one CUDA run still works");
        assert!(end(&mut active, Build::Cuda13), "the last CUDA run frees its backend");
        assert!(end(&mut active, Build::Cpu), "counting off below zero stays free");
    }

    #[test]
    fn a_run_stopped_while_it_waits_neither_counts_nor_takes_a_server() {
        let root = tempfile::tempdir().unwrap();
        let acpp = Acpp::new(root.path());
        begin(&mut acpp.active.lock().unwrap(), Build::Cuda13);
        let asked = std::sync::atomic::AtomicUsize::new(0);
        let stop = || asked.load(Ordering::SeqCst) >= 2;
        let outcome = acpp.claim(Build::Cuda13, &stop, |busy| {
            assert!(busy, "another run is at work");
            asked.fetch_add(1, Ordering::SeqCst);
            Ok(None::<()>)
        });
        assert_eq!(outcome.unwrap_err().to_string(), "stopped");
        assert_eq!(asked.load(Ordering::SeqCst), 2, "it looked again after the wait, then stopped");
        assert_eq!(*acpp.active.lock().unwrap(), vec![(Build::Cuda13, 1)], "the stopped run is not counted");
        assert!(acpp.claim(Build::Cpu, &|| true, |_| Ok(Some(()))).is_ok(), "a server at hand is taken before stop is asked");
    }
}
