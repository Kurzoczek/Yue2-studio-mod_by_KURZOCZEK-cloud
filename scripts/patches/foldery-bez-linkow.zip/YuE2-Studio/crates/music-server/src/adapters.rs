//! Adapters: LoRA files the engine merges into its model for one request.
//!
//! Each adapter is a folder under `adapters/` in the studio data: the weight
//! files the engine reads, and `adapter.json`, what the studio knows about them
//! - a name, a trigger word, the strength each slot starts at, where it came
//! from. The engine is started with that folder as its adapter directory and a
//! request names folders, so nothing here parses weights: which parts of the
//! model an adapter touches is the engine's answer, asked of it and remembered.
//!
//! The examples are a catalogue shipped with the studio, every file pinned to a
//! revision. Nothing downloads on its own; a catalogue entry is fetched when the
//! user asks for it, through the same resumable downloader as every other extra.

use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

use anyhow::{bail, Context, Result};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use futures_util::StreamExt;

use std::sync::Arc;

use crate::downloads::{Asset, AssetKind, Downloader};
use music_engine::model::AdapterWeights;

/// The downloader scope the adapters page reads its progress under.
pub const SCOPE: &str = "adapters";

const META: &str = "adapter.json";

/// A name or description, one string or one per interface language.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum Text {
    Plain(String),
    Localized(BTreeMap<String, String>),
}

impl Default for Text {
    fn default() -> Self {
        Text::Plain(String::new())
    }
}

#[derive(Debug, Clone, Deserialize)]
struct CatalogFile {
    url: String,
    file: String,
    bytes: u64,
}

#[derive(Debug, Clone, Deserialize)]
struct CatalogEntry {
    id: String,
    engine: String,
    kind: String,
    #[serde(default)]
    author: Option<String>,
    #[serde(default)]
    page: Option<String>,
    #[serde(default)]
    trigger: Option<String>,
    name: Text,
    description: Text,
    scales: BTreeMap<String, f64>,
    #[serde(default)]
    range: Option<[f64; 2]>,
    /// The DiT width the weights were trained on: `2b` or `xl`.
    #[serde(default)]
    model: Option<String>,
    #[serde(default)]
    likes: u64,
    #[serde(default)]
    downloads: u64,
    files: Vec<CatalogFile>,
}

#[derive(Deserialize)]
struct CatalogFileFormat {
    adapters: Vec<CatalogEntry>,
}

/// A catalogue entry with its downloads, built once. The downloader works on
/// `'static` assets, and the catalogue is fixed for the life of the process.
struct CatalogItem {
    entry: CatalogEntry,
    assets: Vec<&'static Asset>,
}

/// An adapter about to be downloaded: what will be recorded, and its files.
struct Planned {
    meta: AdapterMeta,
    assets: Vec<&'static Asset>,
}

fn catalog() -> &'static [CatalogItem] {
    static CATALOG: OnceLock<Vec<CatalogItem>> = OnceLock::new();
    CATALOG.get_or_init(|| {
        let parsed: CatalogFileFormat = serde_json::from_str(include_str!("../../../config/adapter-catalog.json"))
            .expect("config/adapter-catalog.json is valid");
        parsed
            .adapters
            .into_iter()
            .map(|entry| {
                let assets = entry
                    .files
                    .iter()
                    .map(|file| {
                        let leak = |text: String| -> &'static str { Box::leak(text.into_boxed_str()) };
                        let asset: &'static Asset = Box::leak(Box::new(Asset {
                            id: leak(format!("{}/{}", entry.id, file.file)),
                            label: leak(file.file.clone()),
                            kind: AssetKind::Model,
                            url: leak(file.url.clone()),
                            relative_path: leak(format!("{}/{}", entry.id, file.file)),
                            bytes: file.bytes,
                            unzip_into: None,
                            marker: "",
                            pick: &[],
                            vram_gb: None,
                            note: "",
                        }));
                        asset
                    })
                    .collect();
                CatalogItem { entry, assets }
            })
            .collect()
    })
}

/// Where an installed adapter came from.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "type")]
pub enum Origin {
    Catalog { catalog_id: String },
    Imported,
    /// A checkpoint of a training run.
    Trained {
        #[serde(default)]
        run: String,
        #[serde(default)]
        step: u32,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        training_base: Option<crate::training::TrainingBaseIdentity>,
    },
    /// A file of a Hugging Face repository, pinned to the commit it came from.
    Hub { repo: String, revision: String, file: String },
}

/// What the studio remembers about an installed adapter.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdapterMeta {
    pub id: String,
    pub engine: String,
    pub name: Text,
    #[serde(default)]
    pub description: Text,
    #[serde(default)]
    pub kind: String,
    #[serde(default)]
    pub trigger: Option<String>,
    #[serde(default)]
    pub author: Option<String>,
    #[serde(default)]
    pub page: Option<String>,
    /// The strength each slot starts at when the adapter is picked.
    #[serde(default)]
    pub scales: BTreeMap<String, f64>,
    /// The slider range, when the adapter is only meaningful inside one.
    #[serde(default)]
    pub range: Option<[f64; 2]>,
    /// The DiT width the weights fit, `2b` or `xl`, when it is known.
    #[serde(default)]
    pub model: Option<String>,
    /// The slots the engine found weights for, remembered from its last answer
    /// so the page can show them while the engine is not running.
    #[serde(default)]
    pub slots: Vec<String>,
    pub origin: Origin,
    #[serde(default)]
    pub created_at: String,
}

/// An installed adapter as the interface sees it.
#[derive(Debug, Clone, Serialize)]
pub struct Installed {
    #[serde(flatten)]
    pub meta: AdapterMeta,
    pub bytes: u64,
    /// The engine's complaint about the files, when it has one.
    pub error: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub training_base_matches: Option<bool>,
}

/// A catalogue entry as the interface sees it.
#[derive(Debug, Clone, Serialize)]
pub struct Offered {
    pub id: String,
    pub name: Text,
    pub description: Text,
    pub kind: String,
    pub author: Option<String>,
    pub page: Option<String>,
    pub trigger: Option<String>,
    pub slots: Vec<String>,
    pub bytes: u64,
    pub installed: bool,
    pub model: Option<String>,
    pub likes: u64,
    pub downloads: u64,
}

/// What a partial update may change.
#[derive(Debug, Clone, Default, Deserialize)]
pub struct Patch {
    pub name: Option<String>,
    pub trigger: Option<String>,
    pub scales: Option<BTreeMap<String, f64>>,
}

/// The engine's view of one entry of the adapter directory, from `/props`.
#[derive(Debug, Clone, Default)]
pub struct EngineView {
    pub slots: Vec<String>,
    pub trigger: Option<String>,
    pub error: Option<String>,
}

/// Reads the `adapters` list of an engine `/props` answer, keyed by folder.
/// The slot of each flag is the engine's own name for that half of its model.
pub fn engine_views(props: &Value, slot_ids: &[&str]) -> BTreeMap<String, EngineView> {
    let mut views = BTreeMap::new();
    for item in props.get("adapters").and_then(Value::as_array).into_iter().flatten() {
        let Some(name) = item.get("name").and_then(Value::as_str) else { continue };
        let slots = slot_ids
            .iter()
            .filter(|slot| item.get(**slot).and_then(Value::as_bool).unwrap_or(false))
            .map(|slot| slot.to_string())
            .collect();
        views.insert(
            name.to_string(),
            EngineView {
                slots,
                trigger: item.get("trigger").and_then(Value::as_str).map(str::to_owned),
                error: item.get("error").and_then(Value::as_str).map(str::to_owned),
            },
        );
    }
    views
}

pub struct AdapterLibrary {
    root: crate::downloads::Place,
    engine: String,
    downloader: Downloader,
    /// The catalogue entries of the download running now. Several go as one
    /// set, the way the model screen fetches its components: one progress,
    /// one cancel, the files four at a time.
    installing: std::sync::Mutex<Vec<String>>,
}

impl AdapterLibrary {
    /// The library of one engine's adapters, under the studio data root.
    pub fn new(data_root: &Path, engine: &str) -> Self {
        // wherever the "adapters" download folder is kept, asked each time
        let root = crate::downloads::Place::download(data_root, "adapters", "");
        let runtime = crate::downloads::Place::download(data_root, "adapters", "runtime");
        Self { downloader: Downloader::at_places(root.clone(), runtime), root, engine: engine.to_string(), installing: std::sync::Mutex::new(Vec::new()) }
    }

    pub(crate) fn at(root: PathBuf, engine: &str) -> Self {
        Self { downloader: Downloader::new(root.clone()), root: crate::downloads::Place::Fixed(root), engine: engine.to_string(), installing: std::sync::Mutex::new(Vec::new()) }
    }

    fn installing_now(&self) -> std::sync::MutexGuard<'_, Vec<String>> {
        self.installing.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    pub fn installing(&self) -> Vec<String> {
        self.installing_now().clone()
    }

    pub fn downloader(&self) -> &Downloader {
        &self.downloader
    }

    /// The folder the engine is pointed at.
    pub fn root(&self) -> PathBuf {
        self.root.path()
    }

    fn folder(&self, id: &str) -> Result<PathBuf> {
        if id.is_empty() || id.starts_with('.') || id.contains(['/', '\\', ':']) {
            bail!("not an adapter id: {id}");
        }
        Ok(self.root().join(id))
    }

    /// Reserve an independent folder, cleaned up if the files or metadata cannot be saved.
    fn new_import(&self, name: &str) -> Result<(String, tempfile::TempDir)> {
        fs::create_dir_all(&self.root())?;
        let folder = tempfile::Builder::new().prefix(&format!("{}-", slug(name))).rand_bytes(12).tempdir_in(&self.root())?;
        let id = folder.path().file_name().context("missing adapter folder name")?.to_string_lossy().into_owned();
        Ok((id, folder))
    }

    fn read_meta(&self, id: &str) -> Option<AdapterMeta> {
        let text = fs::read_to_string(self.folder(id).ok()?.join(META)).ok()?;
        serde_json::from_str(&text).ok()
    }

    fn write_meta(&self, meta: &AdapterMeta) -> Result<()> {
        let folder = self.folder(&meta.id)?;
        fs::create_dir_all(&folder)?;
        let temporary = folder.join(format!("{META}.part"));
        fs::write(&temporary, serde_json::to_vec_pretty(meta)?)?;
        fs::rename(&temporary, folder.join(META))?;
        Ok(())
    }

    /// Every adapter of this engine that finished installing, the engine's
    /// view folded in: slots it found are remembered, a complaint is shown.
    pub fn installed(&self, views: Option<&BTreeMap<String, EngineView>>) -> Vec<Installed> {
        let Ok(entries) = fs::read_dir(&self.root()) else { return Vec::new() };
        let mut out = Vec::new();
        for entry in entries.flatten() {
            let Some(id) = entry.file_name().to_str().map(str::to_owned) else { continue };
            let Some(mut meta) = self.read_meta(&id) else { continue };
            if meta.engine != self.engine {
                continue;
            }
            let mut error = None;
            // the original file is merged once by the engine; another precision would be a second copy
            if let Origin::Hub { repo, file, .. } = &meta.origin {
                if crate::model_manager::is_companion_file(repo, file) && file != "nar_lora_joint_v9.safetensors" {
                    error = Some("the decoder companion every render already merges; this copy would merge it a second time".to_string());
                }
            }
            if let Some(view) = views.and_then(|views| views.get(&id)).filter(|_| error.is_none()) {
                error = view.error.clone();
                if error.is_none() && view.slots != meta.slots {
                    meta.slots = view.slots.clone();
                    if meta.trigger.is_none() {
                        meta.trigger = view.trigger.clone();
                    }
                    if let Err(problem) = self.write_meta(&meta) {
                        eprintln!("[ERROR] adapters: could not remember the slots of {id}: {problem}");
                    }
                }
            }
            out.push(Installed { bytes: folder_bytes(&entry.path()), meta, error, training_base_matches: None });
        }
        out.sort_by(|a, b| b.meta.created_at.cmp(&a.meta.created_at));
        out
    }

    pub fn offered(&self) -> Vec<Offered> {
        catalog()
            .iter()
            .filter(|item| item.entry.engine == self.engine)
            .map(|item| Offered {
                id: item.entry.id.clone(),
                name: item.entry.name.clone(),
                description: item.entry.description.clone(),
                kind: item.entry.kind.clone(),
                author: item.entry.author.clone(),
                page: item.entry.page.clone(),
                trigger: item.entry.trigger.clone(),
                slots: item.entry.scales.keys().cloned().collect(),
                bytes: item.entry.files.iter().map(|file| file.bytes).sum(),
                installed: self.read_meta(&item.entry.id).is_some(),
                model: item.entry.model.clone(),
                likes: item.entry.likes,
                downloads: item.entry.downloads,
            })
            .collect()
    }

    /// Starts downloading catalogue entries as one set.
    pub fn begin_install(self: &Arc<Self>, catalog_ids: &[String]) -> Result<()> {
        let mut planned: Vec<Planned> = Vec::new();
        for id in catalog_ids {
            let item = catalog()
                .iter()
                .find(|item| item.entry.id == *id && item.entry.engine == self.engine)
                .with_context(|| format!("no catalogue adapter {id}"))?;
            if !planned.iter().any(|known| known.meta.id == item.entry.id) {
                planned.push(Planned { meta: self.catalog_meta(&item.entry), assets: item.assets.clone() });
            }
        }
        self.start(planned)
    }

    /// Downloads planned adapters as one set, the way the model screen fetches
    /// its components, and records each once its files are there. The record
    /// is written last, so a folder without one is an unfinished download the
    /// list leaves out.
    fn start(self: &Arc<Self>, planned: Vec<Planned>) -> Result<()> {
        if planned.is_empty() {
            bail!("choose at least one adapter to download");
        }
        {
            let mut installing = self.installing_now();
            if !installing.is_empty() {
                bail!("a LoRA download is already running");
            }
            *installing = planned.iter().map(|plan| plan.meta.id.clone()).collect();
        }
        let library = self.clone();
        tokio::spawn(async move {
            let assets: Vec<&'static Asset> = planned.iter().flat_map(|plan| plan.assets.iter().copied()).collect();
            let downloaded = library.downloader.install_all(SCOPE, &assets).await;
            // an adapter whose files all arrived is kept even when another failed
            for plan in &planned {
                if plan.assets.iter().all(|asset| library.downloader.is_installed(asset)) {
                    if let Err(error) = library.drop_replaced_weights(plan) {
                        eprintln!("[ERROR] adapter {} kept the weights of its earlier version: {error:#}", plan.meta.id);
                    }
                    let meta = AdapterMeta { created_at: now(), ..plan.meta.clone() };
                    if let Err(error) = library.write_meta(&meta) {
                        eprintln!("[ERROR] adapter {} did not record: {error:#}", meta.id);
                    }
                }
            }
            if let Err(error) = downloaded {
                eprintln!("[ERROR] LoRA download: {error:#}");
            }
            library.installing_now().clear();
            crate::mcp::announce("lora_installed");
        });
        Ok(())
    }

    /// The engine reads every weight file in an adapter's folder, and two of
    /// them on one tensor refuse the load; an entry whose files changed leaves
    /// only its own.
    fn drop_replaced_weights(&self, plan: &Planned) -> Result<()> {
        let folder = self.folder(&plan.meta.id)?;
        let own: Vec<&str> = plan.assets.iter().filter_map(|asset| asset.relative_path.rsplit('/').next()).collect();
        for entry in std::fs::read_dir(&folder).with_context(|| format!("read {}", folder.display()))? {
            let path = entry?.path();
            let name = path.file_name().and_then(|name| name.to_str()).unwrap_or_default();
            if name.ends_with(".safetensors") && !own.contains(&name) {
                std::fs::remove_file(&path).with_context(|| format!("remove {}", path.display()))?;
            }
        }
        Ok(())
    }

    fn catalog_meta(&self, entry: &CatalogEntry) -> AdapterMeta {
        AdapterMeta {
            id: entry.id.clone(),
            engine: self.engine.clone(),
            name: entry.name.clone(),
            description: entry.description.clone(),
            kind: entry.kind.clone(),
            trigger: entry.trigger.clone(),
            author: entry.author.clone(),
            page: entry.page.clone(),
            scales: entry.scales.clone(),
            range: entry.range,
            model: entry.model.clone(),
            slots: entry.scales.keys().cloned().collect(),
            origin: Origin::Catalog { catalog_id: entry.id.clone() },
            created_at: String::new(),
        }
    }

    /// Records a trained checkpoint as an adapter, copying its files from the
    /// run so the run can be removed without losing it.
    pub fn import_trained(&self, name: &str, trigger: Option<String>, model: Option<String>, files: &[PathBuf], origin: Origin) -> Result<AdapterMeta> {
        if files.is_empty() {
            bail!("the checkpoint has no adapter files");
        }
        let (id, reserved) = self.new_import(name)?;
        let folder = reserved.path();
        for file in files {
            let name = file.file_name().context("an adapter file without a name")?;
            fs::copy(file, folder.join(name)).with_context(|| format!("copy {}", file.display()))?;
        }
        let meta = AdapterMeta {
            id,
            engine: self.engine.clone(),
            name: Text::Plain(name.trim().to_string()),
            description: Text::default(),
            kind: "trained".into(),
            trigger: trigger.filter(|trigger| !trigger.trim().is_empty()),
            author: None,
            page: None,
            scales: BTreeMap::new(),
            range: None,
            model,
            slots: Vec::new(),
            origin,
            created_at: now(),
        };
        self.write_meta(&meta)?;
        reserved.keep();
        Ok(meta)
    }

    /// Stores uploaded weight files as a new adapter. An `adapter_config.json`
    /// travels with them, since that is where a PEFT export keeps its alpha;
    /// a `lora.json` beside them may name the trigger word.
    pub fn import(&self, name: &str, files: Vec<(String, Vec<u8>)>, origin: Origin) -> Result<AdapterMeta> {
        let weights: Vec<&(String, Vec<u8>)> = files.iter().filter(|(file, _)| file.ends_with(".safetensors")).collect();
        if weights.is_empty() {
            bail!("an adapter needs at least one .safetensors file");
        }
        let (id, reserved) = self.new_import(name)?;
        let folder = reserved.path();
        let mut trigger = None;
        for (file, bytes) in &files {
            let file_name = Path::new(file).file_name().and_then(|value| value.to_str()).context("upload without a name")?;
            match file_name {
                "lora.json" => {
                    trigger = serde_json::from_slice::<Value>(bytes)
                        .ok()
                        .and_then(|value| value.get("trigger").and_then(Value::as_str).map(str::to_owned));
                }
                "adapter_config.json" => fs::write(folder.join(file_name), bytes)?,
                name if name.ends_with(".safetensors") => fs::write(folder.join(name), bytes)?,
                _ => {}
            }
        }
        let meta = AdapterMeta {
            id,
            engine: self.engine.clone(),
            name: Text::Plain(name.trim().to_string()),
            description: Text::default(),
            kind: "other".into(),
            trigger,
            author: None,
            page: None,
            scales: BTreeMap::new(),
            range: None,
            model: None,
            slots: Vec::new(),
            origin,
            created_at: now(),
        };
        self.write_meta(&meta)?;
        reserved.keep();
        Ok(meta)
    }

    /// Recognize the same linked files without re-reading weights. For independent
    /// copies, matching size and contents distinguish them from a different checkpoint.
    pub fn imported_from(&self, files: &[PathBuf]) -> Option<AdapterMeta> {
        let same = |a: &Path, b: &Path| {
            if same_file::is_same_file(a, b).unwrap_or(false) { return true; }
            let (Ok(left), Ok(right)) = (fs::metadata(a), fs::metadata(b)) else { return false };
            if left.len() != right.len() { return false; }
            matches!((crate::install_record::sha256_of(a), crate::install_record::sha256_of(b)),
                     (Ok(left), Ok(right)) if left == right)
        };
        let weights: Vec<&PathBuf> = files.iter().filter(|file| file.file_name().is_some_and(|name| name != "lora.json")).collect();
        if weights.is_empty() { return None; }
        let entries = fs::read_dir(&self.root()).ok()?;
        entries.flatten().find_map(|entry| {
            let id = entry.file_name().to_str()?.to_owned();
            let meta = self.read_meta(&id).filter(|meta| meta.engine == self.engine)?;
            let components = fs::read_dir(entry.path()).ok()?.flatten().filter(|file| {
                let path = file.path();
                path.extension().is_some_and(|ext| ext == "safetensors") || file.file_name() == "adapter_config.json"
            }).count();
            if components != weights.len() { return None; }
            weights.iter().all(|file| file.file_name().is_some_and(|name| same(file, &entry.path().join(name)))).then_some(meta)
        })
    }

    /// Installs a LoRA from files on this computer without a second copy: each
    /// file is hard-linked into the adapter's folder, and copied only where the
    /// drive cannot link it. Says whether a copy was taken.
    pub fn import_linked(&self, name: &str, files: &[PathBuf], origin: Origin) -> Result<(AdapterMeta, bool)> {
        if !files.iter().any(|file| file.extension().is_some_and(|extension| extension == "safetensors")) {
            bail!("an adapter needs at least one .safetensors file");
        }
        let (id, reserved) = self.new_import(name)?;
        let folder = reserved.path();
        let mut copied = false;
        let mut trigger = None;
        for file in files {
            let file_name = file.file_name().and_then(|value| value.to_str()).context("a file without a name")?;
            if file_name == "lora.json" {
                trigger = fs::read(file).ok().and_then(|bytes| serde_json::from_slice::<Value>(&bytes).ok()).and_then(|value| value.get("trigger").and_then(Value::as_str).map(str::to_owned));
                continue;
            }
            let target = folder.join(file_name);
            if fs::hard_link(file, &target).is_err() {
                // A second source with the same basename must never overwrite the first hard link.
                let mut destination = fs::File::create_new(&target)?;
                std::io::copy(&mut fs::File::open(file)?, &mut destination)
                    .with_context(|| format!("copy {}", file.display()))?;
                copied = true;
            }
        }
        let meta = AdapterMeta {
            id,
            engine: self.engine.clone(),
            name: Text::Plain(name.trim().to_string()),
            description: Text::default(),
            kind: "other".into(),
            trigger,
            author: None,
            page: None,
            scales: BTreeMap::new(),
            range: None,
            model: None,
            slots: Vec::new(),
            origin,
            created_at: now(),
        };
        self.write_meta(&meta)?;
        reserved.keep();
        Ok((meta, copied))
    }

    pub fn update(&self, id: &str, patch: Patch) -> Result<AdapterMeta> {
        let mut meta = self.read_meta(id).with_context(|| format!("no adapter {id}"))?;
        if let Some(name) = patch.name.map(|name| name.trim().to_string()).filter(|name| !name.is_empty()) {
            meta.name = Text::Plain(name);
        }
        if let Some(trigger) = patch.trigger {
            let trigger = trigger.trim().to_string();
            meta.trigger = (!trigger.is_empty()).then_some(trigger);
        }
        if let Some(scales) = patch.scales {
            meta.scales = scales;
        }
        self.write_meta(&meta)?;
        Ok(meta)
    }

    /// Removes an adapter's folder. Songs made with it keep their audio; only
    /// an exact re-render of them needs it back.
    pub fn remove(&self, id: &str) -> Result<()> {
        let folder = self.folder(id)?;
        if self.read_meta(id).is_none() {
            bail!("no adapter {id}");
        }
        fs::remove_dir_all(&folder).with_context(|| format!("remove {}", folder.display()))
    }

    /// The word that switches an installed adapter on, when it has one.
    pub fn trigger_of(&self, id: &str) -> Option<String> {
        self.read_meta(id).and_then(|meta| meta.trigger).filter(|trigger| !trigger.trim().is_empty())
    }

    pub(super) fn training_base(&self, id: &str) -> Option<crate::training::TrainingBaseIdentity> {
        match self.read_meta(id)?.origin {
            Origin::Trained { training_base, .. } => training_base,
            _ => None,
        }
    }

    /// Whether the adapter came out of the studio's own trainer, which keeps
    /// the decoder companion frozen under every LoRA it trains: such a LoRA
    /// sounds as trained only over the companion.
    pub fn trained_over_companion(&self, id: &str) -> bool {
        self.read_meta(id).is_some_and(|meta| matches!(meta.origin, Origin::Trained { .. }))
    }

    /// Whether the adapter was trained with its trigger inside HOT-Step's style
    /// sentence, as its weights record (`style_template: upstream`).
    pub fn trained_in_sentence(&self, id: &str) -> bool {
        let Ok(entries) = self.folder(id).and_then(|folder| Ok(fs::read_dir(folder)?)) else {
            return false;
        };
        entries
            .flatten()
            .map(|entry| entry.path())
            .filter(|path| path.extension().is_some_and(|extension| extension.eq_ignore_ascii_case("safetensors")))
            .any(|path| {
                local_header(&path).is_ok_and(|header| header.get("__metadata__").and_then(|meta| meta.get("style_template")).and_then(Value::as_str) == Some("upstream"))
            })
    }

    pub fn exists(&self, id: &str) -> bool {
        self.read_meta(id).is_some_and(|meta| meta.engine == self.engine)
    }

    /// The strengths an adapter starts at when a request gives none, as the
    /// create page picks them: its own, else full on every slot it touches
    /// (every slot while the engine has not said which).
    pub fn starting_scales(&self, id: &str, all_slots: &[&str]) -> BTreeMap<String, f64> {
        let Some(meta) = self.read_meta(id) else { return BTreeMap::new() };
        let touched: Vec<String> = if meta.slots.is_empty() { all_slots.iter().map(|slot| slot.to_string()).collect() } else { meta.slots.clone() };
        touched.into_iter().map(|slot| {
            let scale = meta.scales.get(&slot).copied().unwrap_or(1.0);
            (slot, scale)
        }).collect()
    }
}

/// The Hugging Face tags that mark an engine's adapters, from the catalogue
/// file. A repository matches when it carries every tag of one set: trainers
/// tag the same model differently, and the site only ANDs its filters.
#[derive(Debug, Clone, Default, Deserialize)]
struct HubConfig {
    #[serde(default)]
    tags: Vec<String>,
    /// Further tag sets, searched besides `tags`.
    #[serde(default)]
    also: Vec<Vec<String>>,
    /// Words searched in repository names, for the many adapters published
    /// with no tag at all; what they find is kept only when it looks like an
    /// adapter and the typed words are in its name.
    #[serde(default)]
    search: Vec<String>,
}

impl HubConfig {
    fn tag_sets(&self) -> impl Iterator<Item = &Vec<String>> {
        std::iter::once(&self.tags).chain(&self.also).filter(|set| !set.is_empty())
    }
}

fn hub_config(engine: &str) -> Option<&'static HubConfig> {
    #[derive(Deserialize)]
    struct HubSection {
        #[serde(default)]
        hub: BTreeMap<String, HubConfig>,
    }
    static HUB: OnceLock<BTreeMap<String, HubConfig>> = OnceLock::new();
    HUB.get_or_init(|| {
        serde_json::from_str::<HubSection>(include_str!("../../../config/adapter-catalog.json"))
            .expect("config/adapter-catalog.json is valid")
            .hub
    })
    .get(engine)
}

const HUB: &str = "https://huggingface.co";

/// Whether a repository found by name holds an adapter rather than a model:
/// its tags or its name say LoRA, LoKr, PEFT or a slider.
fn looks_like_adapter(repo: &str, tags: &[&str]) -> bool {
    let name = repo.to_lowercase();
    ["lora", "lokr", "loha", "lycoris", "slider"].iter().any(|word| name.contains(word))
        || tags.iter().any(|tag| matches!(tag.to_lowercase().as_str(), "lora" | "lokr" | "peft" | "lycoris") || tag.starts_with("base_model:adapter:"))
}

/// A repository of adapters on Hugging Face, as a search lists it.
#[derive(Debug, Clone, Serialize)]
pub struct HubRepo {
    pub repo: String,
    pub author: String,
    pub likes: u64,
    pub downloads: u64,
    pub updated: Option<String>,
    pub tags: Vec<String>,
}

/// One weight file of a repository, and the adapter it becomes.
#[derive(Debug, Clone, Serialize)]
pub struct HubFile {
    pub path: String,
    pub bytes: u64,
    pub adapter_id: String,
    pub installed: bool,
    /// The decoder companion every render already merges, in some precision.
    pub built_in: bool,
    #[serde(flatten)]
    pub weights: AdapterWeights,
}

/// The header of a safetensors file on the Hub, fetched by range: eight bytes
/// of length, then the JSON, never the weights. One read of the start covers
/// an adapter's header; a longer one takes a second.
async fn hub_header(http: &reqwest::Client, url: &str) -> Result<serde_json::Map<String, Value>> {
    const FIRST: u64 = 256 << 10;
    let url = crate::net::model_url(url);
    let url = url.as_str();
    let answer = http.get(url).header(reqwest::header::RANGE, format!("bytes=0-{}", FIRST - 1)).send().await?.error_for_status()?;
    // a server that ignores the range would send the whole weight file; a whole
    // file no longer than the range is the same bytes
    let whole_small = answer.status() == reqwest::StatusCode::OK && answer.content_length().is_some_and(|bytes| bytes <= FIRST);
    if answer.status() != reqwest::StatusCode::PARTIAL_CONTENT && !whole_small {
        bail!("the server answered {} to a range request", answer.status());
    }
    let start = answer.bytes().await?;
    match header_in(&start)? {
        HeaderRead::Whole(header) => Ok(header),
        HeaderRead::Longer(length) => {
            let body = http.get(url).header(reqwest::header::RANGE, format!("bytes=8-{}", 7 + length)).send().await?.error_for_status()?.bytes().await?;
            Ok(serde_json::from_slice(&body)?)
        }
    }
}

/// What the start of a safetensors file says of its header.
#[derive(Debug)]
enum HeaderRead {
    Whole(serde_json::Map<String, Value>),
    /// The header is this many bytes and runs past what was read.
    Longer(u64),
}

fn header_in(start: &[u8]) -> Result<HeaderRead> {
    let length = u64::from_le_bytes(start.get(..8).context("a safetensors file shorter than its header")?.try_into()?);
    if length > 64 << 20 {
        bail!("a safetensors header of {length} bytes");
    }
    Ok(match start.get(8..8 + length as usize) {
        Some(header) => HeaderRead::Whole(serde_json::from_slice(header)?),
        None => HeaderRead::Longer(length),
    })
}

/// The header of a safetensors file on disk.
pub(super) fn local_header(path: &Path) -> Result<serde_json::Map<String, Value>> {
    use std::io::Read;
    let mut file = fs::File::open(path)?;
    let mut length = [0u8; 8];
    file.read_exact(&mut length)?;
    let length = u64::from_le_bytes(length);
    if length > 64 << 20 {
        bail!("a safetensors header of {length} bytes");
    }
    let mut header = vec![0u8; length as usize];
    file.read_exact(&mut header)?;
    Ok(serde_json::from_slice(&header)?)
}

/// Spaces, tabs and line breaks run together as the trainer's squash does; other
/// whitespace is the caption's own.
fn squash(text: &str) -> String {
    text.split([' ', '\t', '\r', '\n']).filter(|word| !word.is_empty()).collect::<Vec<_>>().join(" ")
}

fn strip_opener<'a>(style: &'a str, trigger: &str) -> Option<&'a str> {
    [format!("{trigger}, in the style of {trigger}."), format!("{trigger},")]
        .iter()
        .find_map(|opener| style.get(..opener.len()).filter(|head| head.eq_ignore_ascii_case(opener)).map(|_| &style[opener.len()..]))
        .or_else(|| style.eq_ignore_ascii_case(trigger).then_some(""))
}

/// Whether the style already opens with the trigger, as `<trigger>, ` or in the trained sentence.
pub fn opens_with(style: &str, trigger: &str) -> bool {
    let trigger = trigger.trim();
    !trigger.is_empty() && strip_opener(&squash(style), trigger).is_some()
}

/// The style as HOT-Step's trainers write it into every training row of an adapter
/// with a trigger: `<trigger>, in the style of <trigger>. <style>`, the trigger alone
/// for an empty style. A style that already opens with the trigger is not wrapped twice.
pub fn upstream_style(style: &str, trigger: &str) -> String {
    let trigger = trigger.trim();
    let style = squash(style);
    if trigger.is_empty() {
        return style;
    }
    let rest = squash(strip_opener(&style, trigger).unwrap_or(&style));
    if rest.is_empty() {
        trigger.to_string()
    } else {
        format!("{trigger}, in the style of {trigger}. {rest}")
    }
}

/// A repository's adapter files at one commit.
#[derive(Debug, Clone, Serialize)]
pub struct HubListing {
    pub repo: String,
    pub revision: String,
    pub page: String,
    pub files: Vec<HubFile>,
    /// Every file of the commit with its size, for the configs that travel along.
    #[serde(skip)]
    all: BTreeMap<String, u64>,
}

/// `owner/name` of a repository, from a bare id or any huggingface.co link to
/// it or to one of its files; the file path comes back when the link names one.
pub fn hub_reference(text: &str) -> Option<(String, Option<String>)> {
    let text = text.trim().trim_end_matches('/');
    let rest = text
        .strip_prefix("https://huggingface.co/")
        .or_else(|| text.strip_prefix("http://huggingface.co/"))
        .or_else(|| text.strip_prefix("huggingface.co/"))
        .unwrap_or(text);
    let rest = rest.split(['?', '#']).next()?;
    let parts: Vec<&str> = rest.split('/').collect();
    if parts.len() < 2 || matches!(parts[0], "datasets" | "spaces") {
        return None;
    }
    let valid = |part: &str| !part.is_empty() && !part.starts_with('.') && part.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.'));
    if !valid(parts[0]) || !valid(parts[1]) {
        return None;
    }
    let file = match parts.get(2) {
        Some(&"resolve") | Some(&"blob") if parts.len() > 4 => Some(parts[4..].join("/")),
        _ => None,
    };
    Some((format!("{}/{}", parts[0], parts[1]), file))
}

/// A stable adapter id for a file of a repository: readable, and unique even
/// where two long names share their start.
fn hub_adapter_id(repo: &str, path: &str) -> String {
    let stem = Path::new(path).file_stem().and_then(|stem| stem.to_str()).unwrap_or("adapter");
    let mut hash: u32 = 0x811c9dc5;
    for byte in format!("{repo}/{path}").bytes() {
        hash = (hash ^ byte as u32).wrapping_mul(0x0100_0193);
    }
    format!("hf-{}-{hash:08x}", slug(stem))
}

impl AdapterLibrary {
    /// Adapters for this engine on Hugging Face, the most liked first and
    /// the most downloaded among equals; the query narrows them by name.
    pub async fn hub_search(&self, http: &reqwest::Client, query: &str) -> Result<Vec<HubRepo>> {
        let config = hub_config(&self.engine).context("this engine has no adapters on Hugging Face")?;
        let known: Vec<&String> = config.tag_sets().flatten().collect();
        let query = query.trim();
        let words: Vec<String> = query.to_lowercase().split_whitespace().map(str::to_owned).collect();
        let url = |tags: &[String], search: &str| -> Result<reqwest::Url> {
            let mut url = reqwest::Url::parse(&crate::net::model_url(&format!("{HUB}/api/models")))?;
            {
                let mut pairs = url.query_pairs_mut();
                for tag in tags {
                    pairs.append_pair("filter", tag);
                }
                if !search.is_empty() {
                    pairs.append_pair("search", search);
                }
                pairs.append_pair("sort", "likes").append_pair("direction", "-1").append_pair("limit", "1000");
                for field in ["likes", "downloads", "lastModified", "tags"] {
                    pairs.append_pair("expand[]", field);
                }
            }
            Ok(url)
        };
        // (url, found by a name search rather than by tags)
        let mut requests: Vec<(reqwest::Url, bool)> = Vec::new();
        for set in config.tag_sets() {
            requests.push((url(set, query)?, false));
        }
        for term in &config.search {
            requests.push((url(&[], term)?, true));
        }
        let answers = futures_util::future::join_all(requests.iter().map(|(url, _)| async move {
            let found: Vec<Value> = http.get(url.clone()).send().await?.error_for_status()?.json().await?;
            anyhow::Ok(found)
        }))
        .await;
        let mut repos: Vec<HubRepo> = Vec::new();
        for ((_, by_name), answer) in requests.iter().zip(answers) {
            for model in answer? {
                let Some(repo) = model.get("id").and_then(Value::as_str).map(str::to_owned) else { continue };
                if repos.iter().any(|known| known.repo == repo) {
                    continue;
                }
                let tags: Vec<&str> = model.get("tags").and_then(Value::as_array).into_iter().flatten().filter_map(Value::as_str).collect();
                if *by_name && !(looks_like_adapter(&repo, &tags) && words.iter().all(|word| repo.to_lowercase().contains(word))) {
                    continue;
                }
                let skip = |tag: &str| known.iter().any(|known| known.as_str() == tag) || tag.contains(':');
                repos.push(HubRepo {
                    author: repo.split('/').next().unwrap_or_default().to_string(),
                    likes: model.get("likes").and_then(Value::as_u64).unwrap_or(0),
                    downloads: model.get("downloads").and_then(Value::as_u64).unwrap_or(0),
                    updated: model.get("lastModified").and_then(Value::as_str).map(str::to_owned),
                    tags: tags.iter().filter(|tag| !skip(tag)).take(6).map(|tag| tag.to_string()).collect(),
                    repo,
                });
            }
        }
        repos.sort_by(|a, b| b.likes.cmp(&a.likes).then(b.downloads.cmp(&a.downloads)));
        Ok(repos)
    }

    /// The weight files of a repository at its current commit.
    pub async fn hub_files(&self, http: &reqwest::Client, repo: &str) -> Result<HubListing> {
        let (repo, _) = hub_reference(repo).with_context(|| format!("not a Hugging Face repository: {repo}"))?;
        let info: Value = http.get(crate::net::model_url(&format!("{HUB}/api/models/{repo}"))).send().await?.error_for_status()?.json().await?;
        let revision = info.get("sha").and_then(Value::as_str).context("the repository names no commit")?.to_string();
        let tree: Vec<Value> = http
            .get(crate::net::model_url(&format!("{HUB}/api/models/{repo}/tree/{revision}?recursive=true")))
            .send()
            .await?
            .error_for_status()?
            .json()
            .await?;
        let mut all = BTreeMap::new();
        for item in &tree {
            if item.get("type").and_then(Value::as_str) != Some("file") {
                continue;
            }
            let Some(path) = item.get("path").and_then(Value::as_str) else { continue };
            let bytes = item.pointer("/lfs/size").or_else(|| item.get("size")).and_then(Value::as_u64).unwrap_or(0);
            all.insert(path.to_string(), bytes);
        }
        let weights: Vec<(&String, &u64)> = all.iter().filter(|(path, _)| path.ends_with(".safetensors")).collect();
        let urls: Vec<String> = weights.iter().map(|(path, _)| format!("{HUB}/{repo}/resolve/{revision}/{path}")).collect();
        let kinds: Vec<AdapterWeights> = futures_util::stream::iter(urls.into_iter().map(|url| {
            let http = http.clone();
            async move {
                match hub_header(&http, &url).await {
                    Ok(header) => music_engine::model::describe_adapter(&header),
                    Err(error) => AdapterWeights { problem: Some(format!("unreadable header: {error:#}")), ..AdapterWeights::default() },
                }
            }
        }))
        .buffered(6)
        .collect()
        .await;
        let files = weights
            .into_iter()
            .zip(kinds)
            .map(|((path, bytes), weights)| {
                let adapter_id = hub_adapter_id(&repo, path);
                HubFile {
                    installed: self.read_meta(&adapter_id).is_some(),
                    built_in: crate::model_manager::is_companion_file(&repo, path),
                    path: path.clone(),
                    bytes: *bytes,
                    adapter_id,
                    weights,
                }
            })
            .collect();
        Ok(HubListing { page: format!("{HUB}/{repo}"), repo, revision, files, all })
    }

    /// Downloads files of a repository as one set, each its own adapter; an
    /// `adapter_config.json` beside a file goes with it, since that is where
    /// a PEFT export keeps its alpha.
    pub async fn begin_hub_install(self: &Arc<Self>, http: &reqwest::Client, repo: &str, paths: &[String]) -> Result<()> {
        let listing = self.hub_files(http, repo).await?;
        let leak = |text: String| -> &'static str { Box::leak(text.into_boxed_str()) };
        // one asset per file the user fetches; leaked like the catalogue's,
        // because the shared downloader works on 'static assets
        let asset = |id: &str, path: &str, bytes: u64| -> &'static Asset {
            let file = Path::new(path).file_name().and_then(|name| name.to_str()).unwrap_or("adapter.safetensors");
            Box::leak(Box::new(Asset {
                id: leak(format!("{id}/{file}")),
                label: leak(file.to_string()),
                kind: AssetKind::Model,
                url: leak(format!("{HUB}/{}/resolve/{}/{path}", listing.repo, listing.revision)),
                relative_path: leak(format!("{id}/{file}")),
                bytes,
                unzip_into: None,
                marker: "",
                pick: &[],
                vram_gb: None,
                note: "",
            }))
        };
        let mut planned = Vec::new();
        for path in paths {
            let file = listing.files.iter().find(|file| file.path == *path).with_context(|| format!("{} has no file {path}", listing.repo))?;
            if file.built_in {
                bail!("{path} is the decoder companion every render already merges; a second copy would merge it twice");
            }
            let mut assets = vec![asset(&file.adapter_id, &file.path, file.bytes)];
            let folder = Path::new(&file.path).parent().and_then(|parent| parent.to_str()).unwrap_or("");
            let config = if folder.is_empty() { "adapter_config.json".to_string() } else { format!("{folder}/adapter_config.json") };
            if let Some(bytes) = listing.all.get(&config) {
                assets.push(asset(&file.adapter_id, &config, *bytes));
            }
            let stem = Path::new(&file.path).file_stem().and_then(|stem| stem.to_str()).unwrap_or("adapter");
            planned.push(Planned {
                meta: AdapterMeta {
                    id: file.adapter_id.clone(),
                    engine: self.engine.clone(),
                    name: Text::Plain(stem.replace(['_', '-'], " ")),
                    description: Text::Plain(format!("{} · {}", listing.repo, file.path)),
                    kind: "other".into(),
                    trigger: None,
                    author: listing.repo.split('/').next().map(str::to_owned),
                    page: Some(listing.page.clone()),
                    scales: BTreeMap::new(),
                    range: None,
                    model: file.weights.model.clone(),
                    slots: Vec::new(),
                    origin: Origin::Hub { repo: listing.repo.clone(), revision: listing.revision.clone(), file: file.path.clone() },
                    created_at: String::new(),
                },
                assets,
            });
        }
        self.start(planned)
    }
}

fn folder_bytes(folder: &Path) -> u64 {
    fs::read_dir(folder)
        .map(|entries| entries.flatten().filter_map(|entry| entry.metadata().ok()).map(|meta| meta.len()).sum())
        .unwrap_or(0)
}

fn slug(name: &str) -> String {
    let slug: String = name
        .trim()
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() { c.to_ascii_lowercase() } else { '-' })
        .collect();
    let slug = slug.split('-').filter(|part| !part.is_empty()).collect::<Vec<_>>().join("-");
    if slug.is_empty() { "adapter".into() } else { slug.chars().take(40).collect() }
}

/// The LoRAs in a folder and its subfolders, `depth` levels down: a folder with
/// an `adapter_config.json` is one LoRA with its weights and configs, anywhere
/// else every `.safetensors` is one LoRA named after its file.
pub fn found_in(folder: &Path, depth: usize) -> Vec<(String, Vec<PathBuf>)> {
    let Ok(entries) = fs::read_dir(folder) else { return Vec::new() };
    let mut files = Vec::new();
    let mut folders = Vec::new();
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            folders.push(path);
        } else {
            files.push(path);
        }
    }
    files.sort();
    folders.sort();
    let named = |path: &Path| path.file_name().and_then(|name| name.to_str()).map(str::to_owned).unwrap_or_default();
    let mut found = Vec::new();
    if files.iter().any(|file| named(file) == "adapter_config.json") {
        let kept: Vec<PathBuf> = files.iter().filter(|file| matches!(named(file).as_str(), "adapter_config.json" | "lora.json") || named(file).ends_with(".safetensors")).cloned().collect();
        if kept.iter().any(|file| named(file).ends_with(".safetensors")) {
            found.push((named(folder), kept));
        }
    } else {
        let config = files.iter().find(|file| named(file) == "lora.json").cloned();
        for file in files.iter().filter(|file| named(file).ends_with(".safetensors")) {
            let stem = file.file_stem().and_then(|stem| stem.to_str()).unwrap_or_default().to_owned();
            found.push((stem, std::iter::once(file.clone()).chain(config.clone()).collect()));
        }
    }
    if depth > 0 {
        for child in folders {
            found.extend(found_in(&child, depth - 1));
        }
    }
    found
}

fn now() -> String {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0).to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_header_is_read_from_the_start_or_asked_for_whole() {
        let json = br#"{"x.lora_A.weight":{"dtype":"F32","shape":[8,64],"data_offsets":[0,2048]}}"#;
        let mut start = (json.len() as u64).to_le_bytes().to_vec();
        start.extend_from_slice(json);
        start.extend_from_slice(&[0; 16]);
        assert!(matches!(header_in(&start).unwrap(), HeaderRead::Whole(header) if header.contains_key("x.lora_A.weight")));
        assert!(matches!(header_in(&start[..20]).unwrap(), HeaderRead::Longer(length) if length == json.len() as u64));
        assert!(header_in(&(65u64 << 20).to_le_bytes()).is_err(), "an oversized header is refused");
        assert!(header_in(&[1, 2, 3]).is_err(), "a file shorter than the length prefix is refused");
    }

    #[test]
    fn hub_links_name_the_repository_and_the_file() {
        assert_eq!(hub_reference("monsterovich/yue2-steps-from-hell"), Some(("monsterovich/yue2-steps-from-hell".into(), None)));
        assert_eq!(
            hub_reference("https://huggingface.co/becausereasons/yue2-mltnt-militant-reggae/tree/main"),
            Some(("becausereasons/yue2-mltnt-militant-reggae".into(), None))
        );
        assert_eq!(
            hub_reference("https://huggingface.co/monsterovich/yue2-steps-from-hell/resolve/main/adapter-ar-195/lora.safetensors?download=true"),
            Some(("monsterovich/yue2-steps-from-hell".into(), Some("adapter-ar-195/lora.safetensors".into())))
        );
        assert_eq!(hub_reference("https://huggingface.co/datasets/a/b"), None);
        assert_eq!(hub_reference("not a link"), None);
        assert_eq!(hub_reference("../etc"), None);
    }

    #[test]
    fn hub_adapter_ids_are_stable_and_tell_same_named_files_apart() {
        let ar = hub_adapter_id("monsterovich/yue2-steps-from-hell", "adapter-ar-195/lora.safetensors");
        let nar = hub_adapter_id("monsterovich/yue2-steps-from-hell", "adapter-nar-194/lora.safetensors");
        assert_ne!(ar, nar);
        assert_eq!(ar, hub_adapter_id("monsterovich/yue2-steps-from-hell", "adapter-ar-195/lora.safetensors"));
        assert!(ar.starts_with("hf-lora-"));
    }


    #[test]
    fn a_folder_of_loras_is_taken_without_a_copy() {
        let root = std::env::temp_dir().join(format!("adapters-{}", uuid::Uuid::now_v7()));
        let kept = root.join("comfyui").join("loras");
        let peft = kept.join("bossa").join("checkpoint");
        fs::create_dir_all(&peft).unwrap();
        fs::write(kept.join("metal.safetensors"), b"weights").unwrap();
        fs::write(kept.join("notes.txt"), b"not a lora").unwrap();
        fs::write(peft.join("adapter_config.json"), b"{}").unwrap();
        fs::write(peft.join("adapter_model.safetensors"), b"peft weights").unwrap();
        let found = found_in(&kept, 2);
        let names: Vec<&str> = found.iter().map(|(name, _)| name.as_str()).collect();
        assert_eq!(names, ["metal", "checkpoint"], "a loose file is one LoRA, a folder with adapter_config.json is one");
        assert_eq!(found[1].1.len(), 2, "the PEFT folder brings its config with its weights");
        assert!(found_in(&kept, 0).iter().all(|(name, _)| name == "metal"), "subfolders are searched only as deep as asked");

        let library = AdapterLibrary::new(&root.join("data"), "yue2");
        let (meta, copied) = library.import_linked("metal", &found[0].1, Origin::Imported).unwrap();
        assert!(!copied, "the same drive takes a hard link");
        let linked = root.join("data").join("adapters").join(&meta.id).join("metal.safetensors");
        assert_eq!(fs::read(&linked).unwrap(), b"weights");
        fs::write(kept.join("metal.safetensors"), b"WEIGHTS").unwrap();
        assert_eq!(fs::read(&linked).unwrap(), b"WEIGHTS", "a link, not a copy: both names are one file");
        assert_eq!(library.imported_from(&found[0].1).map(|known| known.id), Some(meta.id), "the same folder taken again finds what it gave");
        assert!(library.imported_from(&found[1].1).is_none());
        fs::remove_dir_all(&root).ok();
    }

    fn library(label: &str) -> AdapterLibrary {
        let root = std::env::temp_dir().join(format!("adapters-test-{label}-{}", uuid::Uuid::now_v7().simple()));
        AdapterLibrary::new(&root, "yue2-cpp")
    }

    #[test]
    fn the_catalogue_is_complete_and_pinned() {
        let entries = catalog();
        assert!(entries.len() > 10);
        for item in entries {
            let entry = &item.entry;
            assert!(!entry.files.is_empty(), "{} has no files", entry.id);
            assert!(!entry.scales.is_empty(), "{} starts at no strength", entry.id);
            for file in &entry.files {
                assert!(file.url.contains("/resolve/") && !file.url.contains("/resolve/main/"), "{} is not pinned", file.url);
                assert!(file.bytes > 0);
                assert!(file.file.ends_with(".safetensors") || file.file == "adapter_config.json", "{} is not an adapter file", file.file);
            }
            assert!(entry.files.iter().any(|file| file.file.ends_with(".safetensors")), "{} has no weights", entry.id);
            // a model with several sizes names the one each adapter fits
            let families = music_engine::model::MODEL_FAMILIES;
            assert!(families.is_empty() || families.iter().any(|(name, _)| entry.model.as_deref() == Some(*name)), "{} names no model size", entry.id);
            if let Text::Localized(names) = &entry.name {
                for lang in ["en", "ru", "zh", "ja", "ko", "pt"] {
                    assert!(names.contains_key(lang), "{} has no {lang} name", entry.id);
                }
            }
            // a curated entry is described in every interface language
            let Text::Localized(descriptions) = &entry.description else { panic!("{} is not described per language", entry.id) };
            for lang in ["en", "ru", "zh", "ja", "ko", "pt"] {
                assert!(descriptions.get(lang).is_some_and(|text| !text.trim().is_empty()), "{} has no {lang} description", entry.id);
            }
        }
        let mut ids: Vec<&str> = entries.iter().map(|item| item.entry.id.as_str()).collect();
        ids.sort();
        ids.dedup();
        assert_eq!(ids.len(), entries.len(), "catalogue ids repeat");
    }

    #[test]
    fn two_imports_named_alike_keep_independent_weights() {
        let root = tempfile::tempdir().unwrap();
        let library = AdapterLibrary::new(root.path(), "yue2");
        let upload = |bytes| library.import("voice", vec![("voice.safetensors".into(), vec![bytes])], Origin::Imported).unwrap();
        let a = upload(1);
        let b = upload(2);
        assert_ne!(a.id, b.id);
        assert_eq!(fs::read(library.root().join(a.id).join("voice.safetensors")).unwrap(), [1]);
        assert_eq!(fs::read(library.root().join(b.id).join("voice.safetensors")).unwrap(), [2]);
    }

    #[test]
    fn same_size_and_timestamp_do_not_merge_different_checkpoint_weights() {
        let root = tempfile::tempdir().unwrap();
        let library = AdapterLibrary::new(root.path(), "yue2");
        let a = root.path().join("voice.safetensors");
        let folder = root.path().join("other");
        fs::create_dir(&folder).unwrap();
        let b = folder.join("voice.safetensors");
        fs::write(&a, [1]).unwrap();
        fs::write(&b, [2]).unwrap();
        let stamp = a.metadata().unwrap().modified().unwrap();
        fs::File::options().write(true).open(&b).unwrap().set_modified(stamp).unwrap();
        library.import_linked("voice", std::slice::from_ref(&a), Origin::Imported).unwrap();
        assert!(library.imported_from(std::slice::from_ref(&b)).is_none());
        assert!(library.import_linked("collision", &[a.clone(), b.clone()], Origin::Imported).is_err());
        assert_eq!(fs::read(&a).unwrap(), [1]);
        assert_eq!(fs::read(&b).unwrap(), [2]);
        assert_eq!(fs::read_dir(library.root()).unwrap().count(), 1);
    }

    #[test]
    fn an_import_is_listed_patched_and_removed() {
        let library = library("import");
        let meta = library
            .import(
                "My Voice!",
                vec![
                    ("voice.safetensors".into(), b"weights".to_vec()),
                    ("lora.json".into(), br#"{"trigger":"sv_me"}"#.to_vec()),
                    ("notes.txt".into(), b"ignored".to_vec()),
                ],
                Origin::Imported,
            )
            .unwrap();
        assert!(meta.id.starts_with("my-voice-"));
        assert_eq!(meta.trigger.as_deref(), Some("sv_me"));
        assert!(library.root().join(&meta.id).join("voice.safetensors").is_file());
        assert!(!library.root().join(&meta.id).join("notes.txt").exists());

        let mut views = BTreeMap::new();
        views.insert(meta.id.clone(), EngineView { slots: vec!["ar".into()], trigger: None, error: None });
        let listed = library.installed(Some(&views));
        assert_eq!(listed.len(), 1);
        assert_eq!(listed[0].meta.slots, vec!["ar".to_string()]);
        // remembered for when the engine is not there to ask
        assert_eq!(library.installed(None)[0].meta.slots, vec!["ar".to_string()]);

        let patched = library.update(&meta.id, Patch { name: Some("Voice".into()), trigger: Some(String::new()), scales: None }).unwrap();
        assert!(matches!(patched.name, Text::Plain(ref name) if name == "Voice"));
        assert_eq!(patched.trigger, None);

        library.remove(&meta.id).unwrap();
        assert!(library.installed(None).is_empty());
        let _ = fs::remove_dir_all(library.root().parent().unwrap());
    }

    #[test]
    fn a_catalogue_update_leaves_only_the_new_weights() {
        let library = library("update");
        let item = catalog().iter().find(|item| item.entry.id == "yue2-slider-metal").expect("the metal slider is catalogued");
        let plan = Planned { meta: library.catalog_meta(&item.entry), assets: item.assets.clone() };
        let folder = library.root().join("yue2-slider-metal");
        fs::create_dir_all(&folder).unwrap();
        let new_file = item.assets[0].relative_path.rsplit('/').next().unwrap();
        fs::write(folder.join("metal_distilled_refined_rank8.safetensors"), b"old").unwrap();
        fs::write(folder.join(new_file), b"new").unwrap();
        fs::write(folder.join("adapter.json"), b"{}").unwrap();

        library.drop_replaced_weights(&plan).unwrap();

        assert!(!folder.join("metal_distilled_refined_rank8.safetensors").exists());
        assert!(folder.join(new_file).is_file());
        assert!(folder.join("adapter.json").is_file());
        let _ = fs::remove_dir_all(library.root().parent().unwrap());
    }

    #[test]
    fn an_import_without_weights_is_refused_and_ids_cannot_escape() {
        let library = library("refuse");
        assert!(library.import("x", vec![("a.txt".into(), vec![1])], Origin::Imported).is_err());
        assert!(library.folder("../escape").is_err());
        assert!(library.folder("..").is_err());
        assert!(library.remove("missing").is_err());
    }

    #[test]
    fn engine_views_read_the_props_list() {
        let props = serde_json::json!({ "adapters": [
            { "name": "a", "ok": true, "ar": true, "nar": false, "trigger": "t" },
            { "name": "b", "ok": false, "ar": false, "nar": false, "error": "no key" },
        ]});
        let views = engine_views(&props, &["ar", "nar"]);
        assert_eq!(views["a"].slots, vec!["ar".to_string()]);
        assert_eq!(views["a"].trigger.as_deref(), Some("t"));
        assert_eq!(views["b"].error.as_deref(), Some("no key"));
    }

    #[test]
    fn a_trained_trigger_is_sent_inside_the_trained_sentence_once() {
        let sentence = "nrmn, in the style of nrmn. synth pop, male vocal";
        assert_eq!(upstream_style("nrmn, synth pop, male vocal", "nrmn"), sentence);
        assert_eq!(upstream_style("synth pop,  male\nvocal", "nrmn"), sentence);
        assert_eq!(upstream_style(sentence, "nrmn"), sentence);
        assert_eq!(upstream_style("NRMN, In The Style Of NRMN. synth pop, male vocal", "nrmn"), sentence);
        assert_eq!(upstream_style("nrmn, ", "nrmn"), "nrmn");
        assert_eq!(upstream_style("", "nrmn"), "nrmn");
        assert_eq!(upstream_style("synth pop", " "), "synth pop");
        assert_eq!(upstream_style("феофан, рок", "феофан"), "феофан, in the style of феофан. рок");
        assert!(opens_with("nrmn, synth pop", "nrmn") && opens_with(sentence, "nrmn") && !opens_with("synth pop, nrmn", "nrmn"));
    }

    #[test]
    fn the_trained_sentence_is_read_from_the_weights() {
        let library = library("sentence");
        let folder = library.root().join("trained");
        fs::create_dir_all(&folder).unwrap();
        let header = br#"{"__metadata__":{"trigger":"nrmn","style_template":"upstream"}}"#;
        let mut bytes = (header.len() as u64).to_le_bytes().to_vec();
        bytes.extend_from_slice(header);
        fs::write(folder.join("native-nar.safetensors"), bytes).unwrap();
        assert!(library.trained_in_sentence("trained"));
        assert!(!library.trained_in_sentence("missing"));
    }
}
