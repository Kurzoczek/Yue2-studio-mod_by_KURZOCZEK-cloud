//! The downloadable half of the optional writing assistant.
//!
//! YuE2 needs no text model to generate, so nothing here is required and nothing is
//! fetched on its own: the user picks a model, sees its size, and starts the
//! download. Once a model and the llama.cpp runtime are on disk, Studio runs
//! `llama-server` as a sidecar and talks to it over the same OpenAI-compatible
//! API it would use for a server the user runs themselves.
//!
//! The sizes below are for showing a weight before anything has been fetched.
//! They are not a rule: what a file weighs is whatever its server says today,
//! and that is what the download is checked against - see `sizes`. Treating the
//! compiled-in figure as the truth made three of these models impossible to
//! install after their publisher re-uploaded them.

use std::fs;
use std::net::TcpListener;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::Arc;
use std::time::{Duration, Instant};

use anyhow::{anyhow, bail, Context, Result};
use serde::{Deserialize, Serialize};
use tokio::sync::Mutex;

/// What a downloadable asset is for.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AssetKind {
    /// A GGUF text model.
    Model,
    /// The llama.cpp binaries, delivered as a zip.
    Runtime,
}

#[derive(Debug, Clone, Copy)]
pub struct Asset {
    pub id: &'static str,
    pub label: &'static str,
    pub kind: AssetKind,
    pub url: &'static str,
    /// Where the file lands, relative to the assistant root.
    pub relative_path: &'static str,
    /// About what it weighs, for showing a size before anything is fetched.
    /// The real one comes from the server; see `sizes`.
    pub bytes: u64,
    /// Extracted into this runtime sub-directory when set. The CUDA build and
    /// the CPU fallback stay apart, and the CUDA libraries land next to the
    /// binary that links against them.
    pub unzip_into: Option<&'static str>,
    /// A file name prefix that proves this asset is unpacked. Without it the
    /// CUDA libraries would look installed as soon as the CUDA binaries were,
    /// because both land in the same directory.
    pub marker: &'static str,
    /// Roughly how much VRAM the model wants; informational only.
    pub vram_gb: Option<u32>,
    pub note: &'static str,
}

pub const ASSETS: &[Asset] = &[
    Asset {
        id: "gemma-4-e4b-q4_0",
        label: "Gemma 4 E4B IT (QAT q4_0)",
        kind: AssetKind::Model,
        url: "https://huggingface.co/google/gemma-4-E4B-it-qat-q4_0-gguf/resolve/4b4a2c1d584be7264f87aac328a1bc739ce81b6c/gemma-4-E4B_q4_0-it.gguf",
        relative_path: "models/gemma-4-E4B_q4_0-it.gguf",
        bytes: 5_154_941_280,
        unzip_into: None,
        marker: "",
        vram_gb: Some(6),
        note: "The lighter of the two: quantisation-aware training keeps it usable at q4_0.",
    },
    Asset {
        id: "gemma-4-12b-q4_0",
        label: "Gemma 4 12B IT (QAT q4_0)",
        kind: AssetKind::Model,
        url: "https://huggingface.co/google/gemma-4-12B-it-qat-q4_0-gguf/resolve/29d097773436b69ff9feafd636ab4cf873786537/gemma-4-12b-it-qat-q4_0.gguf",
        relative_path: "models/gemma-4-12b-it-qat-q4_0.gguf",
        bytes: 6_975_879_296,
        unzip_into: None,
        marker: "",
        vram_gb: Some(10),
        note: "Writes noticeably better captions; wants a card that is not already full of the music engine.",
    },
    Asset {
        id: "gemma-4-12b-q5_k_m",
        label: "Gemma 4 12B IT (Q5_K_M)",
        kind: AssetKind::Model,
        url: "https://huggingface.co/unsloth/gemma-4-12b-it-GGUF/resolve/fc034cfff751157913579611efad8462ac1be606/gemma-4-12b-it-Q5_K_M.gguf",
        relative_path: "models/gemma-4-12b-it-Q5_K_M.gguf",
        bytes: 8_413_576_000,
        unzip_into: None,
        marker: "",
        vram_gb: Some(11),
        note: "More accurate than q4_0, and it wants a card with room to spare.",
    },
    Asset {
        id: "gemma-4-12b-q6_k",
        label: "Gemma 4 12B IT (Q6_K)",
        kind: AssetKind::Model,
        url: "https://huggingface.co/unsloth/gemma-4-12b-it-GGUF/resolve/fc034cfff751157913579611efad8462ac1be606/gemma-4-12b-it-Q6_K.gguf",
        relative_path: "models/gemma-4-12b-it-Q6_K.gguf",
        bytes: 9_786_022_720,
        unzip_into: None,
        marker: "",
        vram_gb: Some(12),
        note: "Closer again to the full model.",
    },
    Asset {
        id: "gemma-4-12b-q8_0",
        label: "Gemma 4 12B IT (Q8_0)",
        kind: AssetKind::Model,
        url: "https://huggingface.co/unsloth/gemma-4-12b-it-GGUF/resolve/fc034cfff751157913579611efad8462ac1be606/gemma-4-12b-it-Q8_0.gguf",
        relative_path: "models/gemma-4-12b-it-Q8_0.gguf",
        bytes: 12_669_647_680,
        unzip_into: None,
        marker: "",
        vram_gb: Some(15),
        note: "As close to the original as a quantisation gets. For a card that has nothing else to do.",
    },
    #[cfg(windows)]
    Asset {
        id: "llama-cuda",
        label: "llama.cpp runtime (CUDA 13.5)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-cuda-13.5-x64.zip",
        relative_path: "runtime/llama-cuda.zip",
        bytes: 229_295_176,
        unzip_into: Some("cuda"),
        marker: "llama-server",
        vram_gb: None,
        note: "Needs the CUDA runtime companion below.",
    },
    #[cfg(windows)]
    Asset {
        id: "llama-cuda-runtime",
        label: "CUDA runtime for llama.cpp",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/cudart-llama-bin-win-cuda-13.5-x64.zip",
        relative_path: "runtime/cudart.zip",
        bytes: 426_314_199,
        unzip_into: Some("cuda"),
        marker: "cudart64",
        vram_gb: None,
        note: "The CUDA libraries llama.cpp links against.",
    },
    // CUDA 13 runs Turing (GTX 16, RTX 20) and newer on driver 580 or later;
    // an older card or driver takes llama.cpp's CUDA 12.4 build instead
    #[cfg(windows)]
    Asset {
        id: "llama-cuda12",
        label: "llama.cpp runtime (CUDA 12.4)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-cuda-12.4-x64.zip",
        relative_path: "runtime/llama-cuda12.zip",
        bytes: 364_747_106,
        unzip_into: Some("cuda12"),
        marker: "llama-server",
        vram_gb: None,
        note: "For cards and drivers CUDA 13 does not run: GTX 900 and 10, Tesla V100, drivers before 580. Needs the CUDA runtime companion below.",
    },
    #[cfg(windows)]
    Asset {
        id: "llama-cuda12-runtime",
        label: "CUDA 12 runtime for llama.cpp",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b11236/cudart-llama-bin-win-cuda-12.4-x64.zip",
        relative_path: "runtime/cudart12.zip",
        bytes: 391_443_627,
        unzip_into: Some("cuda12"),
        marker: "cudart64",
        vram_gb: None,
        note: "The CUDA 12 libraries llama.cpp links against.",
    },
    // Every other card - AMD, Intel, an NVIDIA card CUDA does not run on -
    // takes llama.cpp's Vulkan build through the card's own driver
    #[cfg(windows)]
    Asset {
        id: "llama-vulkan",
        label: "llama.cpp runtime (Vulkan)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-vulkan-x64.zip",
        relative_path: "runtime/llama-vulkan.zip",
        bytes: 38_690_012,
        unzip_into: Some("vulkan"),
        marker: "llama-server",
        vram_gb: None,
        note: "For AMD and Intel cards, and NVIDIA cards CUDA does not run on: the card through Vulkan.",
    },
    #[cfg(windows)]
    Asset {
        id: "llama-cpu",
        label: "llama.cpp runtime (CPU)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-win-cpu-x64.zip",
        relative_path: "runtime/llama-cpu.zip",
        bytes: 24_876_692,
        unzip_into: Some("cpu"),
        marker: "llama-server",
        vram_gb: None,
        note: "For machines without a graphics card, or for choosing the processor. Slow, but it works.",
    },
    #[cfg(target_os = "linux")]
    Asset {
        id: "llama-cuda",
        label: "llama.cpp runtime (CUDA 13.5)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-ubuntu-cuda-13.5-x64.tar.gz",
        relative_path: "runtime/llama-cuda.tar.gz",
        bytes: 228_129_368,
        unzip_into: Some("cuda"),
        marker: "llama-server",
        vram_gb: None,
        note: "Needs the CUDA runtime companion below.",
    },
    #[cfg(target_os = "linux")]
    Asset {
        id: "llama-cuda-runtime",
        label: "CUDA runtime for llama.cpp",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/cudart-llama-b12556-bin-ubuntu-cuda-13.5-x64.tar.gz",
        relative_path: "runtime/cudart.tar.gz",
        bytes: 444_077_889,
        unzip_into: Some("cuda"),
        marker: "libcudart",
        vram_gb: None,
        note: "The CUDA libraries llama.cpp links against.",
    },
    #[cfg(target_os = "linux")]
    Asset {
        id: "llama-cuda12",
        label: "llama.cpp runtime (CUDA 12.8)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-ubuntu-cuda-12.8-x64.tar.gz",
        relative_path: "runtime/llama-cuda12.tar.gz",
        bytes: 223_234_282,
        unzip_into: Some("cuda12"),
        marker: "llama-server",
        vram_gb: None,
        note: "For cards and drivers CUDA 13 does not run: GTX 900 and 10, Tesla V100, drivers before 580. Needs the CUDA runtime companion below.",
    },
    #[cfg(target_os = "linux")]
    Asset {
        id: "llama-cuda12-runtime",
        label: "CUDA 12 runtime for llama.cpp",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/cudart-llama-b12556-bin-ubuntu-cuda-12.8-x64.tar.gz",
        relative_path: "runtime/cudart12.tar.gz",
        bytes: 594_376_772,
        unzip_into: Some("cuda12"),
        marker: "libcudart",
        vram_gb: None,
        note: "The CUDA 12 libraries llama.cpp links against.",
    },
    #[cfg(target_os = "linux")]
    Asset {
        id: "llama-vulkan",
        label: "llama.cpp runtime (Vulkan)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-ubuntu-vulkan-x64.tar.gz",
        relative_path: "runtime/llama-vulkan.tar.gz",
        bytes: 36_721_000,
        unzip_into: Some("vulkan"),
        marker: "llama-server",
        vram_gb: None,
        note: "For AMD and Intel cards, and NVIDIA cards CUDA does not run on: the card through Vulkan.",
    },
    #[cfg(target_os = "linux")]
    Asset {
        id: "llama-cpu",
        label: "llama.cpp runtime (CPU)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-ubuntu-x64.tar.gz",
        relative_path: "runtime/llama-cpu.tar.gz",
        bytes: 23_057_457,
        unzip_into: Some("cpu"),
        marker: "llama-server",
        vram_gb: None,
        note: "For machines without a graphics card, or for choosing the processor. Slow, but it works.",
    },
    #[cfg(target_os = "macos")]
    Asset {
        id: "llama-cpu",
        label: "llama.cpp runtime (Metal)",
        kind: AssetKind::Runtime,
        url: "https://github.com/ggml-org/llama.cpp/releases/download/b12556/llama-b12556-bin-macos-arm64.tar.gz",
        relative_path: "runtime/llama-cpu.tar.gz",
        bytes: 16_449_908,
        unzip_into: Some("cpu"),
        marker: "llama-server",
        vram_gb: None,
        note: "Runs on the Mac's own graphics through Metal, in the memory it shares with the processor.",
    },
];

/// The llama.cpp build this machine's card runs: CUDA 13 on Turing and newer
/// with driver 580 or later, CUDA 12 on anything older CUDA still runs,
/// Vulkan on every other card; none without a card, and none on a Mac, whose
/// one build runs on its graphics through Metal by itself. On a Linux whose
/// glibc is older than the upstream CUDA builds need, the card runs Vulkan.
pub fn card_flavour() -> Option<&'static str> {
    if cfg!(target_os = "macos") {
        return None;
    }
    let hardware = crate::hardware::hardware();
    let card = match hardware.cuda {
        Some(crate::hardware::CudaBuild::Cuda12) => Some("cuda12"),
        Some(_) => Some("cuda"),
        None if hardware.gpu_name.is_some() => Some("vulkan"),
        None => None,
    };
    flavour_for(card, glibc_version())
}

/// The oldest glibc the upstream llama.cpp CUDA builds for Linux start on (b12248 needs GLIBC_2.38 and GLIBCXX_3.4.32).
pub const LLAMA_CUDA_GLIBC: (u32, u32) = (2, 38);

fn flavour_for(card: Option<&'static str>, glibc: Option<(u32, u32)>) -> Option<&'static str> {
    match (card, glibc) {
        (Some("cuda" | "cuda12"), Some(version)) if version < LLAMA_CUDA_GLIBC => Some("vulkan"),
        _ => card,
    }
}

/// Why the assistant does not run the card's CUDA build - this Linux's glibc and the one the CUDA build needs - for
/// Settings; None when it does.
pub fn llama_note() -> Option<serde_json::Value> {
    let glibc = glibc_version().filter(|version| *version < LLAMA_CUDA_GLIBC)?;
    crate::hardware::hardware().cuda?;
    Some(serde_json::json!({
        "glibc": format!("{}.{}", glibc.0, glibc.1),
        "need": format!("{}.{}", LLAMA_CUDA_GLIBC.0, LLAMA_CUDA_GLIBC.1),
    }))
}

/// The C library version of this Linux (`gnu_get_libc_version`); None on other systems.
pub fn glibc_version() -> Option<(u32, u32)> {
    #[cfg(all(target_os = "linux", target_env = "gnu"))]
    {
        let text = unsafe { std::ffi::CStr::from_ptr(libc::gnu_get_libc_version()) };
        parse_glibc(text.to_str().ok()?)
    }
    #[cfg(not(all(target_os = "linux", target_env = "gnu")))]
    {
        None
    }
}

#[cfg(any(all(target_os = "linux", target_env = "gnu"), test))]
fn parse_glibc(text: &str) -> Option<(u32, u32)> {
    let mut parts = text.trim().split('.');
    let major = parts.next()?.parse().ok()?;
    let minor = parts.next()?.chars().take_while(char::is_ascii_digit).collect::<String>().parse().ok()?;
    Some((major, minor))
}

pub fn asset(id: &str) -> Option<&'static Asset> {
    ASSETS.iter().find(|asset| asset.id == id)
}

#[derive(Debug, Clone, Serialize)]
pub struct AssetStatus {
    pub id: &'static str,
    pub label: &'static str,
    pub kind: AssetKind,
    pub bytes: u64,
    pub vram_gb: Option<u32>,
    pub note: &'static str,
    pub installed: bool,
    /// Bytes already on disk, so a resumed download reports honestly.
    pub downloaded_bytes: u64,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct RuntimeStatus {
    pub root: String,
    /// True when llama-server and at least one model are present.
    pub ready: bool,
    pub server_path: Option<String>,
    pub installed_models: Vec<String>,
    pub running_model: Option<String>,
    pub loading_model: Option<String>,
    pub base_url: Option<String>,
    pub assets: Vec<AssetStatus>,
    pub active_download: Option<DownloadProgress>,
}

#[derive(Debug, Clone, Serialize)]
pub struct DownloadProgress {
    pub asset_id: String,
    pub downloaded_bytes: u64,
    pub total_bytes: u64,
    pub done: bool,
    pub error: Option<String>,
}

/// Owns the downloads and the sidecar process.
pub struct AssistantRuntime {
    /// Wherever the "assistant" download folder is kept (Debian build), asked each time.
    place: crate::downloads::Place,
    http: reqwest::Client,
    state: Arc<Mutex<RuntimeState>>,
    /// Raised to stop the download. What arrived stays on disk, so this is a
    /// pause as much as a cancel.
    cancel: Arc<std::sync::atomic::AtomicBool>,
}

#[derive(Default)]
struct RuntimeState {
    download: Option<DownloadProgress>,
    server: Option<RunningServer>,
    generation: u64,
}

struct RunningServer {
    child: Child,
    model_path: PathBuf,
    binary: PathBuf,
    context_size: u32,
    reasoning: String,
    ready: bool,
    model_id: String,
    base_url: String,
}

impl RunningServer {
    /// A sidecar that has exited is not a running server. Without this the
    /// status kept claiming a model was loaded after llama-server had died,
    /// and the next request failed with a bare connection error.
    fn is_alive(&mut self) -> bool {
        !matches!(self.child.try_wait(), Ok(Some(_)) | Err(_))
    }
}

impl Drop for RunningServer {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

impl AssistantRuntime {
    fn root(&self) -> PathBuf {
        self.place.path()
    }

    pub fn new(data_root: &Path) -> Self {
        Self {
            place: crate::downloads::Place::download(data_root, "assistant", ""),
            http: crate::net::download_client(),
            state: Arc::new(Mutex::new(RuntimeState::default())),
            cancel: Arc::new(std::sync::atomic::AtomicBool::new(false)),
        }
    }

    pub(crate) fn path_of(&self, asset: &Asset) -> PathBuf {
        self.root().join(asset.relative_path)
    }

    pub fn log_path(&self) -> PathBuf {
        self.root().join("llama-server.log")
    }

    /// The tail of the sidecar log, for error messages that would otherwise
    /// say only "connection refused".
    pub fn log_tail(&self) -> String {
        let Ok(text) = fs::read_to_string(self.log_path()) else {
            return String::new();
        };
        let lines: Vec<&str> = text.lines().rev().take(12).collect();
        lines.into_iter().rev().collect::<Vec<_>>().join("
")
    }

    /// What llama-server's log says about where the model went: the device it
    /// chose, the layers offloaded to it and the weights on each buffer.
    pub fn device_lines(&self) -> std::io::Result<Vec<String>> {
        const MARKERS: [&str; 3] = ["using device", "offloaded", "model buffer size"];
        let text = fs::read_to_string(self.log_path())?;
        Ok(text.lines().filter(|line| MARKERS.iter().any(|marker| line.contains(marker))).map(|line| line.trim().to_string()).collect())
    }

    /// The extracted llama-server, wherever the zip happened to put it.
    pub fn server_binary(&self) -> Option<PathBuf> {
        self.server_binary_for(None)
    }

    /// The binary for a chosen device, or whichever is installed.
    ///
    /// The card build and the processor build sit in their own directories, so
    /// this is also what decides which of the two a download has to fetch: the
    /// choice is the setting, not a guess made after the fact.
    pub fn server_binary_for(&self, device: Option<&str>) -> Option<PathBuf> {
        let runtime = self.root().join("runtime");
        let name = if cfg!(windows) { "llama-server.exe" } else { "llama-server" };
        let card = card_flavour();
        let order: Vec<&str> = match device {
            Some("cuda") => card.into_iter().collect(),
            Some("cpu") => vec!["cpu"],
            _ => card.into_iter().chain(["cpu"]).collect(),
        };
        for flavour in order {
            let candidate = runtime.join(flavour).join(name);
            if candidate.is_file() {
                return Some(candidate);
            }
        }
        let direct = runtime.join(name);
        direct.is_file().then_some(direct)
    }

    pub fn installed_models(&self) -> Vec<&'static Asset> {
        ASSETS
            .iter()
            .filter(|asset| asset.kind == AssetKind::Model && self.is_installed(asset))
            .collect()
    }

    /// Installed when its files are there and, for a runtime, its record names
    /// today's pin (`install_record`); a runtime from before records counts as
    /// in `take_over`. A model counts by its file at the pinned size: its address
    /// can move to another commit of the same weights without them being fetched again.
    pub fn is_installed(&self, asset: &Asset) -> bool {
        if !self.present(asset) {
            return false;
        }
        if asset.kind == AssetKind::Model {
            // the pin names a commit, so its size is exact: a file of another size is another build
            return fs::metadata(self.path_of(asset)).is_ok_and(|meta| meta.len() == asset.bytes);
        }
        let record = self.record_of(asset);
        match crate::install_record::matches(&record, asset.url, &self.root()) {
            Some(current) => current,
            None => self.take_over(asset, &record),
        }
    }

    /// What an earlier release left of `asset` for today's pin to replace, as `Downloader::earlier` says it.
    pub fn earlier(&self, asset: &Asset) -> Option<Option<String>> {
        if asset.kind == AssetKind::Model || self.is_installed(asset) {
            return None;
        }
        if let Some(record) = crate::install_record::read(&self.record_of(asset)) {
            if record.url != asset.url {
                return Some(Some(record.url));
            }
        }
        self.present(asset).then_some(None)
    }

    fn record_of(&self, asset: &Asset) -> PathBuf {
        crate::install_record::record_path(&self.path_of(asset))
    }

    /// A download from before records existed: a model by its presence, a
    /// runtime only when the key file its pin names has the pinned size.
    fn take_over(&self, asset: &Asset, record: &Path) -> bool {
        if asset.kind == AssetKind::Model {
            return true;
        }
        let key = match asset.unzip_into {
            Some(flavour) => crate::install_record::key_file(asset.url).map(|(file, size)| (self.root().join("runtime").join(flavour).join(file), size)),
            None => Some((self.path_of(asset), asset.bytes)),
        };
        let Some((path, _)) = key.filter(|(path, size)| fs::metadata(path).is_ok_and(|meta| meta.len() == *size)) else {
            return false;
        };
        if let Err(error) = crate::install_record::write(record, asset.url, "", &[path], &self.root()) {
            eprintln!("[ERROR] {}: the record of the download already on disk was not written: {error:#}", asset.label);
        }
        true
    }

    /// Fetched, checked, then what an earlier pin put down goes, and today's is extracted and recorded: the record
    /// makes it count as today's pin.
    fn finish(asset: &Asset, downloaded: &Path, target: &Path, root: &Path) -> Result<()> {
        let sha256 = crate::pin_sha::check(asset.url, downloaded)?;
        if downloaded != target {
            fs::rename(downloaded, target).with_context(|| format!("publish {}", target.display()))?;
        }
        Self::record_install(asset, target, target, root, &sha256, false)
    }

    fn record_install(asset: &Asset, source: &Path, target: &Path, root: &Path, sha256: &str, keep_archive: bool) -> Result<()> {
        let record = crate::install_record::record_path(target);
        crate::downloads::replace_earlier(&record, root, source)?;
        let files = match asset.unzip_into {
            Some(flavour) if keep_archive => crate::downloads::unpack_archive(source, &root.join("runtime").join(flavour))?,
            Some(flavour) => crate::downloads::extract_archive(source, &root.join("runtime").join(flavour))?,
            None => vec![target.to_path_buf()],
        };
        crate::downloads::make_programs_executable(asset.marker, &files)?;
        crate::install_record::write(&record, asset.url, sha256, &files, root)
    }

    /// The files of the asset are on disk, whichever pin put them there.
    fn present(&self, asset: &Asset) -> bool {
        if let Some(flavour) = asset.unzip_into {
            // A runtime counts as installed once its own directory has content:
            // the CUDA libraries carry no llama-server of their own.
            let directory = self.root().join("runtime").join(flavour);
            let marker = asset.marker;
            return fs::read_dir(&directory)
                .map(|entries| {
                    entries.flatten().any(|entry| {
                        entry.file_name().to_string_lossy().to_ascii_lowercase().starts_with(marker)
                    })
                })
                .unwrap_or(false);
        }
        // A file is installed when it is there. It gets there by one route
        // only - downloaded into `.part`, checked against what the server said
        // it was sending, and renamed - so its presence is the proof, and a
        // stale figure in the catalogue can no longer declare a perfectly good
        // model missing.
        fs::metadata(self.path_of(asset)).map(|meta| meta.len() > 0).unwrap_or(false)
    }

    pub fn partial_bytes(&self, asset: &Asset) -> u64 {
        let part = self.path_of(asset).with_extension("part");
        fs::metadata(part).map(|meta| meta.len()).unwrap_or(0)
    }

    pub async fn status(&self) -> RuntimeStatus {
        // What these weigh is the servers' business, not a constant compiled in
        // here; the answers arrive in time for the next poll.
        crate::sizes::ask(&self.http, ASSETS.iter().map(|asset| asset.url.to_string()).collect());
        let mut state = self.state.lock().await;
        if state.server.as_mut().is_some_and(|server| !server.is_alive()) {
            state.server = None;
        }
        let models = self.installed_models();
        let server_path = self.server_binary();
        RuntimeStatus {
            root: self.root().display().to_string(),
            ready: server_path.is_some() && !models.is_empty(),
            server_path: server_path.map(|path| path.display().to_string()),
            installed_models: models.iter().map(|asset| asset.id.to_string()).collect(),
            running_model: state.server.as_ref().filter(|server| server.ready).map(|server| server.model_id.clone()),
            loading_model: state.server.as_ref().filter(|server| !server.ready).map(|server| server.model_id.clone()),
            base_url: state.server.as_ref().filter(|server| server.ready).map(|server| server.base_url.clone()),
            assets: ASSETS
                .iter()
                .map(|asset| AssetStatus {
                    id: asset.id,
                    label: asset.label,
                    kind: asset.kind,
                    bytes: crate::sizes::or_listed(asset.url, asset.bytes),
                    vram_gb: asset.vram_gb,
                    note: asset.note,
                    installed: self.is_installed(asset),
                    downloaded_bytes: if self.is_installed(asset) { crate::sizes::or_listed(asset.url, asset.bytes) } else { self.partial_bytes(asset) },
                })
                .collect(),
            active_download: state.download.clone(),
        }
    }

    /// Installs a whole set - the runtime, its libraries, the model - as one
    /// download, and waits for it.
    ///
    /// Asking for them one at a time did not work and could not: `install`
    /// returns as soon as it has spawned, so the second call found the first
    /// still running and was refused. The caller's loop then stopped at its
    /// first file. That is why the runtime appeared and the model never did -
    /// the panel reported "installed" for the group and "not installed" for the
    /// set in the same breath, because both were true.
    /// Deletes an installed asset and returns the disk it freed.
    ///
    /// The runtime is a directory of unpacked binaries, a model is one file,
    /// and a half-finished download is a `.part` next to it - all three go.
    pub fn remove(&self, id: &str) -> Result<u64> {
        let asset = asset(id).ok_or_else(|| anyhow!("unknown assistant asset: {id}"))?;
        let mut freed = 0u64;
        if let Some(flavour) = asset.unzip_into {
            let directory = self.root().join("runtime").join(flavour);
            if let Ok(entries) = fs::read_dir(&directory) {
                for entry in entries.flatten() {
                    if let Ok(meta) = entry.metadata() {
                        if meta.is_file() {
                            freed += meta.len();
                        }
                    }
                }
            }
            match fs::remove_dir_all(&directory) {
                Ok(()) => {}
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(error).with_context(|| format!("remove {}", directory.display())),
            }
        }
        for path in [self.path_of(asset), self.path_of(asset).with_extension("part"), self.record_of(asset)] {
            if let Ok(meta) = fs::metadata(&path) {
                freed += meta.len();
                fs::remove_file(&path).with_context(|| format!("remove {}", path.display()))?;
            }
            fs::remove_file(crate::chunked::manifest_path(&path)).ok();
        }
        Ok(freed)
    }

    /// Stops whatever is downloading.
    pub fn cancel(&self) {
        self.cancel.store(true, std::sync::atomic::Ordering::Relaxed);
    }

    pub async fn install_all(&self, ids: &[String]) -> Result<()> {
        let mut assets: Vec<&'static Asset> = Vec::new();
        for id in ids {
            assets.push(asset(id).ok_or_else(|| anyhow!("unknown assistant asset: {id}"))?);
        }
        self.install_set(assets, None).await
    }

    pub(crate) async fn install_local_archive(&self, asset: &'static Asset, source: &Path) -> Result<()> {
        anyhow::ensure!(asset.unzip_into.is_some() && crate::pin_sha::sha256(asset.url).is_some(), "assistant runtime has no pinned archive");
        self.install_set(vec![asset], Some(source)).await
    }

    async fn install_set(&self, assets: Vec<&'static Asset>, source: Option<&Path>) -> Result<()> {
        let pending: Vec<&'static Asset> = assets.into_iter().filter(|asset| !self.is_installed(asset)).collect();
        if pending.is_empty() {
            return Ok(());
        }

        let total: u64 = pending.iter().map(|asset| asset.bytes).sum();
        let _activity = {
            let mut state = self.state.lock().await;
            if state.download.as_ref().is_some_and(|progress| !progress.done && progress.error.is_none()) {
                bail!("another assistant download is already running");
            }
            self.cancel.store(false, std::sync::atomic::Ordering::Relaxed);
            state.download = Some(DownloadProgress {
                asset_id: if pending.len() == 1 { pending[0].id.to_string() } else { crate::downloads::SET.to_string() },
                downloaded_bytes: 0,
                total_bytes: total,
                done: false,
                error: None,
            });
            crate::chunked::track_download()
        };

        // Sequential on purpose: the model is most of the set, and the two
        // runtime files are small enough that fetching them at the same time
        // buys nothing but a harder figure to report.
        let mut base = 0u64;
        let mut failure = None;
        for asset in &pending {
            let target = self.path_of(asset);
            let outcome = if let Some(source) = source {
                let (root, source, asset) = (self.root(), source.to_owned(), *asset);
                tokio::task::spawn_blocking(move || {
                    let sha = crate::pin_sha::check(asset.url, &source)?;
                    Self::record_install(asset, &source, &target, &root, &sha, true)
                }).await.map_err(anyhow::Error::from).and_then(|outcome| outcome)
            } else {
                match download_asset(&self.http, asset, &target, &self.state, base, self.cancel.clone()).await {
                    Ok(downloaded) => finish_apart(asset, downloaded, &target, &self.root()).await,
                    Err(error) => Err(error),
                }
            };
            if let Err(error) = outcome {
                failure = Some(error);
                break;
            }
            base += asset.bytes;
            if let Some(progress) = self.state.lock().await.download.as_mut() {
                progress.downloaded_bytes = base;
            }
        }

        let outcome = match failure {
            Some(error) => Err(error),
            None => Ok(()),
        };
        if let Some(progress) = self.state.lock().await.download.as_mut() {
            progress.done = true;
            progress.error = outcome.as_ref().err().map(|error| error.to_string());
            if outcome.is_ok() {
                progress.downloaded_bytes = total;
            }
        }
        outcome
    }

    /// Starts one download in the background. Only one runs at a time, and an
    /// interrupted file resumes from what is already on disk.
    pub async fn install(&self, id: &str) -> Result<()> {
        let asset = asset(id).ok_or_else(|| anyhow!("unknown assistant asset: {id}"))?;
        let activity = {
            let mut state = self.state.lock().await;
            if state.download.as_ref().is_some_and(|progress| !progress.done && progress.error.is_none()) {
                bail!("another assistant download is already running");
            }
            self.cancel.store(false, std::sync::atomic::Ordering::Relaxed);
            state.download = Some(DownloadProgress {
                asset_id: asset.id.to_string(),
                downloaded_bytes: self.partial_bytes(asset),
                total_bytes: asset.bytes,
                done: false,
                error: None,
            });
            crate::chunked::track_download()
        };

        let target = self.path_of(asset);
        let http = self.http.clone();
        let state = self.state.clone();
        let root = self.root();
        let cancel = self.cancel.clone();
        tokio::spawn(async move {
            let _activity = activity;
            let outcome = match download_asset(&http, asset, &target, &state, 0, cancel).await {
                Ok(downloaded) => finish_apart(asset, downloaded, &target, &root).await,
                Err(error) => Err(error),
            };
            if let Some(progress) = state.lock().await.download.as_mut() {
                progress.done = true;
                progress.error = outcome.err().map(|error| error.to_string());
            }
        });
        Ok(())
    }

    /// Starts the sidecar on a GGUF that is already on this machine. Models
    /// downloaded by other tools are perfectly good here, so there is no reason
    /// to fetch a second copy of one.
    pub async fn start_path(&self, model_path: &Path, context_size: u32, reasoning: Option<&str>) -> Result<String> {
        if !model_path.is_file() {
            bail!("{} is not a file", model_path.display());
        }
        let mut magic = [0u8; 4];
        {
            use std::io::Read;
            let mut file = fs::File::open(model_path).with_context(|| format!("open {}", model_path.display()))?;
            file.read_exact(&mut magic).with_context(|| format!("read {}", model_path.display()))?;
        }
        if &magic != b"GGUF" {
            bail!("{} is not a GGUF file", model_path.display());
        }
        let label = model_path
            .file_name()
            .map(|name| name.to_string_lossy().to_string())
            .unwrap_or_else(|| model_path.display().to_string());
        self.spawn(model_path.to_path_buf(), label, context_size, reasoning).await
    }

    /// Starts the sidecar for one installed model and returns its base URL.
    pub async fn start(&self, model_id: &str, context_size: u32, reasoning: Option<&str>) -> Result<String> {
        let asset = asset(model_id).ok_or_else(|| anyhow!("unknown assistant model: {model_id}"))?;
        if asset.kind != AssetKind::Model {
            bail!("{model_id} is not a model");
        }
        if !self.is_installed(asset) {
            bail!("{} is not downloaded yet", asset.label);
        }
        self.spawn(self.path_of(asset), model_id.to_string(), context_size, reasoning).await
    }

    async fn spawn(&self, model_path: PathBuf, model_id: String, context_size: u32, reasoning: Option<&str>) -> Result<String> {
        let binary = self
            .server_binary()
            .ok_or_else(|| anyhow!("the llama.cpp runtime is not installed yet"))?;

        let reasoning = reasoning.unwrap_or("").trim();
        let mut state = self.state.lock().await;
        if let Some(server) = state.server.as_mut() {
            if server.model_path == model_path && server.binary == binary && server.context_size == context_size
                && server.reasoning == reasoning && server.is_alive()
            {
                let base_url = server.base_url.clone();
                if server.ready { return Ok(base_url); }
                let generation = state.generation;
                drop(state);
                return self.wait_ready(base_url, generation).await;
            }
        }
        state.server = None;

        let port = free_port()?;
        music_core::process::runtime_beside(&binary);
        let mut command = Command::new(&binary);
        if let Some(path) = music_core::process::own_libraries_first(&binary) {
            command.env("LD_LIBRARY_PATH", path);
        }
        dub_core::proc::outside_appimage(&mut command);
        command
            .arg("--model")
            .arg(&model_path)
            .arg("--host")
            .arg("127.0.0.1")
            .arg("--port")
            .arg(port.to_string())
            .arg("--ctx-size")
            .arg(context_size.to_string())
            // no -ngl: llama-server's --fit places the layers, and an explicit count puts them on the card even
            // where they do not fit, and the load aborts
            // Without the model's own chat template llama-server answers with an
            // empty message for Gemma, which reads as "the assistant returned
            // nothing" downstream.
            .arg("--jinja")
            // Thinking lands in `reasoning_content`, which is where the reader
            // looks; without this some templates inline it into the answer.
            .arg("--reasoning-format")
            .arg("deepseek")
            // verbosity 4 is where llama.cpp names the device and the layers it offloaded
            .arg("--log-verbosity")
            .arg("4")
            .arg("--log-colors")
            .arg("off")
            .stdin(Stdio::null())
            .stdout(Stdio::null());
        // llama-server explains its own failures - a model it cannot load, a
        // card it cannot fit on - and those explanations only exist on stderr.
        match fs::File::create(self.log_path()) {
            Ok(log) => { command.stderr(Stdio::from(log)); }
            Err(_) => { command.stderr(Stdio::null()); }
        }
        // The same setting the cloud path sends as `reasoning.effort`, in the
        // terms this server understands: whether to think at all, and for how
        // many tokens.
        match reasoning {
            "" | "off" | "none" => {
                command.arg("--reasoning").arg("off");
            }
            effort => {
                let budget = match effort {
                    "minimal" => "256",
                    "low" => "512",
                    "medium" => "1024",
                    "high" => "4096",
                    _ => "-1",
                };
                command.arg("--reasoning").arg("on").arg("--reasoning-budget").arg(budget);
            }
        }
        #[cfg(windows)]
        hide_console(&mut command);

        // Through `spawn_dying_with_parent`: a studio killed rather than closed
        // must not leave a `llama-server` holding the card.
        let child = music_core::process::spawn_dying_with_parent(command)
            .with_context(|| format!("start llama-server {}", binary.display()))?;
        music_core::process::adopt(&child);
        let base_url = format!("http://127.0.0.1:{port}/v1");
        state.generation += 1;
        let generation = state.generation;
        state.server = Some(RunningServer {
            child, model_path, binary, context_size, reasoning: reasoning.to_owned(), ready: false, model_id, base_url: base_url.clone(),
        });
        drop(state);
        self.wait_ready(base_url, generation).await
    }

    async fn wait_ready(&self, base_url: String, generation: u64) -> Result<String> {

        // Loading several gigabytes into VRAM is not instant.
        let health = format!("{}/health", base_url.trim_end_matches("/v1"));
        let deadline = Instant::now() + Duration::from_secs(300);
        while Instant::now() < deadline {
            let healthy = self.http.get(&health).timeout(Duration::from_secs(2)).send().await.is_ok_and(|response| response.status().is_success());
            let mut state = self.state.lock().await;
            if state.generation != generation { bail!("the writing assistant model changed while it was loading"); }
            let Some(server) = state.server.as_mut() else { bail!("the writing assistant was stopped while it was loading"); };
            if !server.is_alive() {
                state.server = None;
                bail!("llama-server exited before it became ready:\n{}", self.log_tail());
            }
            if healthy {
                server.ready = true;
                drop(state);
                match self.device_lines() {
                    Ok(lines) => lines.iter().for_each(|line| eprintln!("[assistant] {line}")),
                    Err(error) => eprintln!("[ERROR] the assistant's log {} could not be read: {error}", self.log_path().display()),
                }
                return Ok(base_url);
            }
            drop(state);
            tokio::time::sleep(Duration::from_millis(400)).await;
        }
        let mut state = self.state.lock().await;
        if state.generation == generation && state.server.as_ref().is_some_and(|server| !server.ready) { state.server = None; }
        bail!("llama-server did not become ready in time")
    }

    pub async fn stop(&self) {
        self.state.lock().await.server = None;
    }

    /// The base URL of the running sidecar, if any.
    pub async fn base_url(&self) -> Option<String> {
        let mut state = self.state.lock().await;
        if state.server.as_mut().is_some_and(|server| !server.is_alive()) {
            state.server = None;
        }
        state.server.as_ref().map(|server| server.base_url.clone())
    }
}

/// `base` is what the rest of the set has already fetched, so a set of three
/// files reports one rising figure instead of three that start again at nought.
///
/// The fetching itself is `chunked`: four connections over ranges, retried
/// piece by piece, resumable down to the last sixteen megabytes. A seven
/// gigabyte model over one connection was the studio waiting on a single TCP
/// stream for no reason.
async fn wait_for_cancel(cancel: &std::sync::atomic::AtomicBool) {
    while !cancel.load(std::sync::atomic::Ordering::Relaxed) {
        tokio::time::sleep(std::time::Duration::from_millis(100)).await;
    }
}

async fn download_asset(
    http: &reqwest::Client,
    asset: &Asset,
    target: &Path,
    state: &Arc<Mutex<RuntimeState>>,
    base: u64,
    cancel: Arc<std::sync::atomic::AtomicBool>,
) -> Result<PathBuf> {
    if cancel.load(std::sync::atomic::Ordering::Relaxed) { bail!("cancelled"); }
    if let Some(parent) = target.parent() {
        fs::create_dir_all(parent).with_context(|| format!("create {}", parent.display()))?;
    }
    // a model counts here as `is_installed` counts it, by the pin's exact size: a file of another size is replaced
    let pinned_size = fs::metadata(target).is_ok_and(|meta| meta.len() == asset.bytes);
    let todays = match asset.kind {
        AssetKind::Model => pinned_size,
        _ => pinned_size && crate::downloads::holds_todays(false, asset.url, target).await,
    };
    if todays {
        return Ok(target.to_path_buf());
    }

    let url = crate::net::model_url(asset.url);
    let (plan, url) = tokio::select! {
        biased;
        () = wait_for_cancel(&cancel) => bail!("cancelled"),
        result = crate::chunked::probe(http, &url) => result?,
    };
    if plan.total > 0 {
        crate::sizes::learn(asset.url, plan.total);
    }

    let part = target.with_extension("part");
    let written = Arc::new(std::sync::atomic::AtomicU64::new(0));
    let reporter = {
        let (written, state) = (written.clone(), state.clone());
        tokio::spawn(async move {
            loop {
                let value = written.load(std::sync::atomic::Ordering::Relaxed);
                if let Some(progress) = state.lock().await.download.as_mut() {
                    progress.downloaded_bytes = base + value;
                }
                tokio::time::sleep(std::time::Duration::from_millis(300)).await;
            }
        })
    };
    let outcome = crate::chunked::fetch(http, &url, &part, plan, written.clone(), cancel).await;
    reporter.abort();
    outcome?;
    if let Some(progress) = state.lock().await.download.as_mut() {
        progress.downloaded_bytes = base + written.load(std::sync::atomic::Ordering::Relaxed);
    }

    let size = fs::metadata(&part)?.len();
    if plan.total > 0 && size != plan.total {
        bail!("{} has {size} bytes, the server said {}", asset.label, plan.total);
    }
    Ok(part)
}

/// `AssistantRuntime::finish` off the async workers: it hashes the whole download, gigabytes for a model.
async fn finish_apart(asset: &'static Asset, downloaded: PathBuf, target: &Path, root: &Path) -> Result<()> {
    let (target, root) = (target.to_path_buf(), root.to_path_buf());
    tokio::task::spawn_blocking(move || AssistantRuntime::finish(asset, &downloaded, &target, &root)).await.map_err(|error| anyhow!("the download's check stopped: {error}"))?
}

fn free_port() -> Result<u16> {
    let listener = TcpListener::bind("127.0.0.1:0").context("reserve a port for llama-server")?;
    Ok(listener.local_addr()?.port())
}

#[cfg(windows)]
fn hide_console(command: &mut Command) {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    command.creation_flags(CREATE_NO_WINDOW);
    // The assistant is a second multi-gigabyte process holding VRAM; the job
    // object `adopt` assigns is what kills it with the studio on Windows.
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_cuda_card_runs_vulkan_where_glibc_is_older_than_the_cuda_build_needs() {
        assert_eq!(parse_glibc("2.35"), Some((2, 35)));
        assert_eq!(parse_glibc("2.39\n"), Some((2, 39)));
        assert_eq!(parse_glibc("2.38-ubuntu"), Some((2, 38)));
        assert_eq!(parse_glibc("x"), None);
        for card in ["cuda", "cuda12"] {
            assert_eq!(flavour_for(Some(card), Some((2, 35))), Some("vulkan"));
            assert_eq!(flavour_for(Some(card), Some((2, 38))), Some(card));
            assert_eq!(flavour_for(Some(card), None), Some(card));
        }
        assert_eq!(flavour_for(None, Some((2, 35))), None);
        assert_eq!(flavour_for(Some("vulkan"), Some((2, 35))), Some("vulkan"));
    }

    #[test]
    fn rejecting_a_corrupt_assistant_download_preserves_the_previous_file() {
        let root = tempfile::tempdir().unwrap();
        let model = ASSETS.iter().find(|asset| asset.kind == AssetKind::Model).unwrap();
        let target = root.path().join(model.relative_path);
        fs::create_dir_all(target.parent().unwrap()).unwrap();
        fs::write(&target, b"previous model").unwrap();
        let part = target.with_extension("part");
        fs::write(&part, b"invalid replacement").unwrap();

        let error = AssistantRuntime::finish(model, &part, &target, root.path()).unwrap_err();
        assert!(error.to_string().contains("SHA-256"));
        assert_eq!(fs::read(&target).unwrap(), b"previous model");
        assert!(!part.exists());
    }

    #[tokio::test]
    async fn a_pending_assistant_probe_keeps_the_studio_busy_and_responds_to_cancel() {
        let directory = tempfile::tempdir().unwrap();
        let proxy = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut runtime = AssistantRuntime::new(directory.path());
        runtime.http = reqwest::Client::builder()
            .proxy(reqwest::Proxy::all(format!("http://{}", proxy.local_addr().unwrap())).unwrap())
            .build().unwrap();

        runtime.install("llama-cpu").await.unwrap();
        let (_connection, _) = tokio::time::timeout(Duration::from_secs(3), proxy.accept())
            .await.unwrap().unwrap();
        assert!(!runtime.status().await.active_download.unwrap().done);
        assert!(crate::chunked::downloading());
        runtime.cancel();
        tokio::time::timeout(Duration::from_secs(3), async {
            loop {
                let status = runtime.status().await.active_download.unwrap();
                if status.done {
                    assert_eq!(status.error.as_deref(), Some("cancelled"));
                    break;
                }
                tokio::time::sleep(Duration::from_millis(10)).await;
            }
        }).await.unwrap();
    }

    #[tokio::test]
    async fn a_failed_assistant_archive_install_reaches_its_ended_state() {
        let directory = tempfile::tempdir().unwrap();
        let runtime = AssistantRuntime::new(directory.path());
        let source = directory.path().join("missing.tar.gz");
        let asset = asset("llama-cpu").unwrap();

        assert!(runtime.install_set(vec![asset], Some(&source)).await.is_err());
        let ended = runtime.status().await.active_download.unwrap();
        assert!(ended.done);
        assert!(ended.error.is_some());
    }

    /// llama.cpp is pinned to one build so a working setup keeps working.
    const LLAMA_BUILD: &str = "b12556";
    /// The Windows CUDA 12.4 runtime carries no build number in its name and is the
    /// byte-identical to the b12556 asset: it stays at the build that first shipped
    /// it, so an update of llama.cpp does not fetch 390 MB of the same files.
    #[cfg(windows)]
    const CUDART12_BUILD: &str = "b11236";

    #[test]
    fn every_asset_has_a_size_and_a_distinct_id() {
        for entry in ASSETS {
            assert!(entry.bytes > 0, "{} has no size", entry.id);
            assert_eq!(ASSETS.iter().filter(|other| other.id == entry.id).count(), 1);
            assert!(entry.url.starts_with("https://"), "{} is not fetched over https", entry.id);
        }
        assert!(ASSETS.iter().any(|entry| entry.kind == AssetKind::Model));
        assert!(ASSETS.iter().any(|entry| entry.kind == AssetKind::Runtime));
    }

    /// A model is fetched from a pinned revision: the repository's latest files can be other builds under the same name.
    #[test]
    fn every_model_is_pinned_to_a_revision() {
        for entry in ASSETS.iter().filter(|entry| entry.kind == AssetKind::Model) {
            assert!(entry.url.contains("/resolve/") && !entry.url.contains("/resolve/main/"), "{} is not pinned", entry.url);
        }
    }

    /// A 3.7.0 install keeps an earlier llama.cpp without a record: it is not taken for today's pin and is fetched
    /// again; the same folder with today's build is taken and its record written.
    #[cfg(windows)]
    #[test]
    fn a_3_7_0_llama_without_a_record_is_fetched_again() {
        let temp = std::env::temp_dir().join(format!("assistant-runtime-{}", uuid::Uuid::now_v7()));
        let runtime = AssistantRuntime::new(&temp);
        let server = asset("llama-cpu").expect("the processor build");
        let (key, pinned) = crate::install_record::key_file(server.url).expect("the pin names its key file");
        let directory = runtime.root().join("runtime").join(server.unzip_into.unwrap());
        fs::create_dir_all(&directory).unwrap();
        fs::write(directory.join("llama-server.exe"), b"server").unwrap();
        let library = fs::File::create(directory.join(key)).unwrap();
        library.set_len(pinned + 4096).unwrap();
        assert!(!runtime.is_installed(server), "an earlier build's library is another size");
        library.set_len(pinned).unwrap();
        drop(library);
        assert!(runtime.is_installed(server), "today's build without a record is taken");
        assert!(runtime.record_of(server).is_file(), "and its record is written");
        fs::remove_dir_all(temp).unwrap();
    }

    #[test]
    fn the_runtime_is_pinned_to_one_llama_cpp_build() {
        for entry in ASSETS.iter().filter(|entry| entry.kind == AssetKind::Runtime) {
            #[cfg(windows)]
            let build = if entry.url.contains("/cudart-llama-bin-win-cuda-12.4-") { CUDART12_BUILD } else { LLAMA_BUILD };
            #[cfg(not(windows))]
            let build = LLAMA_BUILD;
            assert!(entry.url.contains(&format!("/download/{build}/")), "{} is not pinned", entry.id);
            assert!(crate::pin_sha::sha256(entry.url).is_some(), "{} has no pinned digest", entry.id);
            assert!(entry.unzip_into.is_some(), "{} has nowhere to extract to", entry.id);
            assert!(!entry.marker.is_empty(), "{} has no proof of extraction", entry.id);
        }
    }

    #[test]
    fn a_partially_downloaded_model_is_not_installed() {
        let temp = std::env::temp_dir().join(format!("assistant-runtime-{}", uuid::Uuid::now_v7()));
        let runtime = AssistantRuntime::new(&temp);
        let model = asset("gemma-4-e4b-q4_0").expect("catalog entry");
        let path = runtime.path_of(model);
        fs::create_dir_all(path.parent().unwrap()).unwrap();
        fs::write(path.with_extension("part"), b"not the whole model").unwrap();

        assert!(!runtime.is_installed(model));
        assert_eq!(runtime.partial_bytes(model), 19);
        fs::remove_dir_all(&temp).ok();
    }
}
