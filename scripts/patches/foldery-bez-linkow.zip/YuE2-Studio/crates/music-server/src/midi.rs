//! Audio to MIDI: MuScriptor (Kyutai & Mirelo, arXiv:2607.08168) run by
//! audio.cpp's server, which reads a size's safetensors folder as it is.
//!
//! Nothing of it comes with the studio. The server is audio.cpp's release,
//! and the weights come from an open mirror of the gated official repositories
//! (the same files, byte for byte); both are fetched the first time a track is
//! turned into MIDI, or from the tools page before that. The code is MIT; the
//! weights are CC BY-NC 4.0, which the tools page says.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, OnceLock};

use serde::{Deserialize, Serialize};

use crate::downloads::{Asset, AssetKind, Downloader};

/// One size of the model.
#[derive(Debug, Clone, Copy, Serialize)]
pub struct Size {
    pub id: &'static str,
    pub params: &'static str,
    /// The mirror's revision the files were measured at.
    #[serde(skip)]
    revision: &'static str,
    #[serde(skip)]
    config_bytes: u64,
    pub bytes: u64,
}

pub const SIZES: [Size; 3] = [
    Size { id: "small", params: "103M", revision: "31a8f75d6a8b5383fd71ad1371dc1620389ab722", config_bytes: 124, bytes: 411_888_600 },
    Size { id: "medium", params: "307M", revision: "27246ba68bd4d8f98bdec10a6edf8d7cf42a8826", config_bytes: 126, bytes: 1_228_144_472 },
    Size { id: "large", params: "1.4B", revision: "87f4bf981f56f90fb5043153b3f54af3c3053da9", config_bytes: 125, bytes: 5_465_642_136 },
];

/// What a track is transcribed with when nobody chose: the middle size hears
/// most of what the large one does for a quarter of the download.
pub const DEFAULT_SIZE: &str = "medium";

pub fn size(id: &str) -> Option<&'static Size> {
    SIZES.iter().find(|size| size.id == id)
}

fn leak(text: String) -> &'static str {
    Box::leak(text.into_boxed_str())
}

/// A size's two files, from the open mirror at a fixed revision.
pub(crate) fn weight_assets(size: &'static Size) -> &'static [Asset] {
    static ASSETS: OnceLock<HashMap<&'static str, Vec<Asset>>> = OnceLock::new();
    ASSETS.get_or_init(|| {
        SIZES
            .iter()
            .map(|size| {
                let file = |name: &str, bytes: u64| Asset {
                    id: leak(format!("muscriptor-{}-{}", size.id, name.split('.').next().unwrap_or(name))),
                    label: leak(format!("MuScriptor {} ({})", size.id, size.params)),
                    kind: AssetKind::Model,
                    url: leak(format!("https://huggingface.co/cocktailpeanut/muscriptor-{}/resolve/{}/{name}", size.id, size.revision)),
                    relative_path: leak(format!("models/muscriptor-{}/{name}", size.id)),
                    bytes,
                    unzip_into: None,
                    marker: "",
                    pick: &[],
                    vram_gb: None,
                    note: "CC BY-NC 4.0: for non-commercial use.",
                };
                (size.id, vec![file("config.json", size.config_bytes), file("model.safetensors", size.bytes)])
            })
            .collect()
    })[size.id]
        .as_slice()
}

/// The model sizes on disk, and audio.cpp's server that runs them.
pub struct Transcriber {
    downloader: Downloader,
    acpp: Arc<crate::acpp::Acpp>,
}

impl Transcriber {
    pub fn new(data_root: &Path, acpp: Arc<crate::acpp::Acpp>) -> Self {
        Self { downloader: Downloader::in_folder(data_root, "midi"), acpp }
    }

    pub fn downloader(&self) -> &Downloader {
        &self.downloader
    }

    /// audio.cpp's server of this build is installed.
    pub fn server_installed(&self, build: acpp_server::asset::Build) -> bool {
        self.acpp.installed(build)
    }

    pub fn model_dir(&self, size: &Size) -> PathBuf {
        self.downloader.root().join("models").join(format!("muscriptor-{}", size.id))
    }

    pub fn model_installed(&self, size: &'static Size) -> bool {
        weight_assets(size).iter().all(|asset| self.downloader.is_installed(asset))
    }

    /// The weights of a size not downloaded yet.
    pub fn missing(&self, size: &'static Size) -> Vec<&'static Asset> {
        weight_assets(size).iter().filter(|asset| !self.downloader.is_installed(asset)).collect()
    }

    /// The weights of a size still to download.
    pub fn missing_bytes(&self, size: &'static Size) -> u64 {
        self.missing(size).iter().map(|asset| asset.bytes.saturating_sub(self.downloader.partial_bytes(asset))).sum()
    }

    /// Deletes a size's weights; the transcriber stays.
    pub fn remove(&self, size: &'static Size) -> anyhow::Result<u64> {
        let mut freed = 0;
        for asset in weight_assets(size) {
            freed += self.downloader.remove(asset)?;
        }
        Ok(freed)
    }

    /// Where a file handed in by path is written: the studio's own folder.
    pub fn loose_output(&self, source: &Path) -> PathBuf {
        let stem = source.file_stem().map(|stem| stem.to_string_lossy().into_owned()).unwrap_or_else(|| "audio".into());
        self.downloader.root().join("files").join(format!("{stem}.mid"))
    }

    pub fn work_dir(&self) -> PathBuf {
        self.downloader.root().join("work")
    }
}

/// One note in seconds, as the transcriber heard it or the MIDI editor holds it; the transcriber gives no velocity.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Note {
    pub pitch: u8,
    pub start: f64,
    pub end: f64,
    pub instrument: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub velocity: Option<u8>,
}

/// A transcription at work, or the last one.
#[derive(Debug, Clone, Serialize)]
pub struct Run {
    /// The library track, or none for a file named by its path.
    pub song_id: Option<String>,
    pub title: String,
    pub size: &'static str,
    /// preparing, downloading, reading, transcribing, done.
    pub stage: &'static str,
    pub chunks_done: u32,
    pub chunks_total: u32,
    pub notes: usize,
    /// When this track's run began, in milliseconds since the Unix epoch.
    pub started_ms: u64,
    pub done: bool,
    pub error: Option<String>,
    /// The MIDI file on this computer, once written.
    pub file: Option<String>,
    /// The set this track belongs to, when several were asked for at once.
    pub batch: Option<Batch>,
}

/// Several library tracks turned into MIDI one after another.
#[derive(Debug, Clone, Serialize)]
pub struct Batch {
    /// How many of the set are finished, made or failed.
    pub done: usize,
    pub total: usize,
    /// The tracks still waiting, in order.
    pub queued: Vec<String>,
    /// Each track that failed, by its title, with the reason.
    pub failed: Vec<String>,
}

impl Run {
    pub fn progress(&self) -> f64 {
        if self.done && self.error.is_none() {
            1.0
        } else if self.chunks_total == 0 {
            0.0
        } else {
            f64::from(self.chunks_done) / f64::from(self.chunks_total)
        }
    }
}

/// What a song's MIDI says about itself, kept beside the .mid.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Sidecar {
    pub size: String,
    pub made_at: String,
    pub instruments: Vec<String>,
    pub notes: Vec<Note>,
}

/// Collects the transcriber's events into notes.
#[derive(Default)]
pub struct Events {
    pub notes: Vec<Note>,
    open: HashMap<i64, usize>,
    pub finished: bool,
}

impl Events {
    /// Takes the event JSON audio.cpp's MuScriptor answers with (`text`): `start` events with a pitch, a time, an
    /// index and an instrument, and `end` events naming the start they close. An event of another type is passed over.
    pub fn take_all(&mut self, text: &str) -> Result<(), String> {
        let events: Vec<serde_json::Value> = serde_json::from_str(text).map_err(|error| format!("the transcriber's events are not JSON: {error}"))?;
        for event in &events {
            self.take(event);
        }
        self.finished = true;
        Ok(())
    }

    /// One event of the transcriber, as `take_all` reads each of its list.
    fn take(&mut self, event: &serde_json::Value) {
        match event["type"].as_str() {
            Some("start") => {
                let start = event["start_time"].as_f64().unwrap_or(0.0);
                self.notes.push(Note {
                    pitch: event["pitch"].as_u64().unwrap_or(0).min(127) as u8,
                    start,
                    end: start,
                    instrument: event["instrument"].as_str().unwrap_or("unknown").to_string(),
                    velocity: None,
                });
                if let Some(index) = event["index"].as_i64() {
                    self.open.insert(index, self.notes.len() - 1);
                }
            }
            Some("end") => {
                if let (Some(index), Some(time)) = (event["start_event_index"].as_i64(), event["end_time"].as_f64()) {
                    if let Some(at) = self.open.remove(&index) {
                        self.notes[at].end = time.max(self.notes[at].start);
                    }
                }
            }
            _ => {}
        }
    }

    /// One event as the server streams it while the transcriber works (the payload of an artifact, the JSON of one
    /// event): a note's start or end goes into the notes, as in `take_all`; a `progress` event gives the chunks done
    /// and the chunks in all.
    pub fn take_streamed(&mut self, payload: &[u8]) -> Result<Option<(usize, usize)>, String> {
        let event: serde_json::Value = serde_json::from_slice(payload).map_err(|error| format!("a streamed event is not JSON: {error}"))?;
        if event["type"].as_str() == Some("progress") {
            let count = |field: &str| event[field].as_u64().map(|value| value as usize);
            return Ok(count("completed").zip(count("total")));
        }
        self.take(&event);
        Ok(None)
    }

    pub fn instruments(&self) -> Vec<String> {
        let mut names: Vec<String> = self.notes.iter().map(|note| note.instrument.clone()).collect();
        names.sort();
        names.dedup();
        names
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_transcribers_events_become_notes() {
        let mut events = Events::default();
        events
            .take_all(
                r#"[{"type":"start","pitch":60,"start_time":0.5,"index":0,"instrument":"acoustic_piano"},
                    {"type":"start","pitch":36,"start_time":0.5,"index":1,"instrument":"drums"},
                    {"type":"end","end_time":0.52,"start_event_index":1},
                    {"type":"end","end_time":1.25,"start_event_index":0}]"#,
            )
            .unwrap();
        assert_eq!(events.notes.len(), 2);
        assert_eq!((events.notes[0].pitch, events.notes[0].start, events.notes[0].end), (60, 0.5, 1.25));
        assert_eq!(events.notes[1].instrument, "drums");
        assert!(events.finished);
        assert_eq!(events.instruments(), ["acoustic_piano", "drums"]);
        assert!(Events::default().take_all("[ace-midi] a log line").is_err());
    }

/// The events the server streams while it works give the notes the final answer gives, and its progress the chunks.
    #[test]
    fn the_streamed_events_give_the_notes_of_the_answer() {
        let events = [
            r#"{"type":"start","pitch":65,"start_time":0.32,"index":0,"instrument":"acoustic_piano"}"#,
            r#"{"type":"start","pitch":36,"start_time":0.5,"index":1,"instrument":"drums"}"#,
            r#"{"type":"progress","completed":1,"total":6}"#,
            r#"{"type":"end","end_time":0.52,"start_event_index":1}"#,
            r#"{"type":"end","end_time":1.25,"start_event_index":0}"#,
        ];
        let mut streamed = Events::default();
        let mut progress = Vec::new();
        for event in events {
            if let Some(chunks) = streamed.take_streamed(event.as_bytes()).unwrap() {
                progress.push(chunks);
            }
        }
        assert_eq!(progress, [(1, 6)]);
        let mut answered = Events::default();
        answered.take_all(&format!("[{}]", events.join(","))).unwrap();
        let pairs = |events: &Events| events.notes.iter().map(|note| (note.pitch, note.start, note.end, note.instrument.clone())).collect::<Vec<_>>();
        assert_eq!(pairs(&streamed), pairs(&answered));
        assert_eq!(pairs(&streamed)[0], (65, 0.32, 1.25, "acoustic_piano".to_string()));
        assert!(streamed.take_streamed(b"not json").is_err());
    }

    #[test]
    fn every_size_has_its_two_files_on_the_mirror() {
        for size in &SIZES {
            let assets = weight_assets(size);
            assert_eq!(assets.len(), 2);
            assert!(assets.iter().all(|asset| asset.url.contains(size.revision) && asset.url.contains("cocktailpeanut/muscriptor-")));
        }
        assert!(size(DEFAULT_SIZE).is_some());
    }
}
